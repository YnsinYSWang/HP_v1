﻿using System;
using System.IO.Ports;

namespace USB_RelayCameraTest
{
    public class cls_baseSerialPort
    {
        private SerialPort m_SerialPort;

        #region ---------------定義事件----------------------------
        public delegate void EventRecvCallback(byte[] byteArrayRecv);
        public event EventRecvCallback eventRecvValue;
        #endregion-----------------------------------------------------
        #region ---------------事件觸發函式----------------------------
        private void OnRecvData(byte[] byteArrayRecv)
        {
            if (eventRecvValue != null)
            {
                eventRecvValue.Invoke(byteArrayRecv);
            }
        }
        #endregion------------------------------------------------------

        public cls_baseSerialPort()
        {
            this.m_SerialPort = new SerialPort();
            this.m_SerialPort.PortName = "COM9";
            this.m_SerialPort.BaudRate = 9600;
            this.m_SerialPort.Parity = Parity.None;
            this.m_SerialPort.DataBits = 8;
            this.m_SerialPort.StopBits = StopBits.One;
            this.m_SerialPort.ReadTimeout = 3000;
            this.m_SerialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
        }

        public cls_baseSerialPort(SerialPort spSerailPort)
        {
            m_SerialPort = spSerailPort;
            this.m_SerialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
        }

        private void DataReceivedHandler(Object sender, SerialDataReceivedEventArgs e)
        {
            SerialPort temp_SerialPort = (SerialPort)sender;
            if (temp_SerialPort.BytesToRead > 0)
            {
                byte[] buffer = new Byte[1024];
                int length = temp_SerialPort.Read(buffer, 0, buffer.Length);
                Array.Resize(ref buffer, length);
                OnRecvData(buffer);
            }
        }

        public bool Open()
        {
            if (this.m_SerialPort != null &&
                !this.m_SerialPort.IsOpen)
            {
                try
                {
                    this.m_SerialPort.Open();
                }
                catch (Exception ex)
                {
                    //this.m_InfoManager.Error(ex.ToString());
                    Console.WriteLine(string.Format("[Base Serialport] Open Serailport Err.{0}",ex.Message));
                    return false;
                }
            }
            else
            {
                // the serial port is open.
            }

            return true;
        }

        public void Close()
        {
            //

            if (this.m_SerialPort != null &&
                this.m_SerialPort.IsOpen)
            {
                try
                {
                    this.m_SerialPort.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(string.Format("[Base Serialport] Close Serailport Err.{0}", ex.Message));
                }
            }

        }

        public void Send(byte[] bytearrayData)
        {
            if (this.m_SerialPort != null &&
                this.m_SerialPort.IsOpen)
            {
                //this.m_SerialPort.WriteLine(o_Msg);
                this.m_SerialPort.Write(bytearrayData, 0, bytearrayData.Length);
                //this.loopCnt++;


                //if (this.m_Stopwatch.ElapsedMilliseconds > 100)
                //{
                //  //  this.m_InfoManager.Error("[gap sensor] get cnt : " + this.loopCnt);
                //  //  this.loopCnt = 0;
                //    this.m_Stopwatch.Restart();
                //}
            }
        }

        public void Send(string strMsg)
        {
            if (this.m_SerialPort != null &&this.m_SerialPort.IsOpen)
            {
                this.m_SerialPort.Write(strMsg);
            }
        }


    }
}
