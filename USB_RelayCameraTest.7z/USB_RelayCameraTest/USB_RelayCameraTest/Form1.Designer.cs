﻿namespace USB_RelayCameraTest
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOpen = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnOnRelay = new System.Windows.Forms.Button();
            this.btnRelayOff = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(12, 12);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(90, 45);
            this.btnOpen.TabIndex = 0;
            this.btnOpen.Text = "Open";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(13, 63);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(89, 45);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnOnRelay
            // 
            this.btnOnRelay.Location = new System.Drawing.Point(186, 18);
            this.btnOnRelay.Name = "btnOnRelay";
            this.btnOnRelay.Size = new System.Drawing.Size(75, 39);
            this.btnOnRelay.TabIndex = 2;
            this.btnOnRelay.Text = "On";
            this.btnOnRelay.UseVisualStyleBackColor = true;
            this.btnOnRelay.Click += new System.EventHandler(this.btnOnRelay_Click);
            // 
            // btnRelayOff
            // 
            this.btnRelayOff.Location = new System.Drawing.Point(186, 69);
            this.btnRelayOff.Name = "btnRelayOff";
            this.btnRelayOff.Size = new System.Drawing.Size(75, 39);
            this.btnRelayOff.TabIndex = 3;
            this.btnRelayOff.Text = "Off";
            this.btnRelayOff.UseVisualStyleBackColor = true;
            this.btnRelayOff.Click += new System.EventHandler(this.btnRelayOff_Click);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(320, 18);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(658, 511);
            this.panel1.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1268, 598);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnRelayOff);
            this.Controls.Add(this.btnOnRelay);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnOpen);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnOnRelay;
        private System.Windows.Forms.Button btnRelayOff;
        private System.Windows.Forms.Panel panel1;
    }
}

