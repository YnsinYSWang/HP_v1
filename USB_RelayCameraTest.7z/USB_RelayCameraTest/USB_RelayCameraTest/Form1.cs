﻿using ETCDLL02;
using System;
using System.Diagnostics;
using System.Drawing;
using System.Timers;
using System.Windows.Forms;

namespace USB_RelayCameraTest
{


	public partial class Form1 : Form
    {
        private UC_ImgUI m_ImgView = null;
        private cls_CameraManagement m_CAM = null;
        private System.Timers.Timer m_Refresh = null;

        private delegate void UpdateImageToUI(Bitmap pic, Control ctl);

        private void RefreshImageToUI(Bitmap image, Control ctl)
        {
            if (InvokeRequired)
            {
                var um = new UpdateImageToUI(RefreshImageToUI);
                Invoke(um, image, ctl);
            }
            else
            {
                UC_ImgUI box = (UC_ImgUI)ctl;
                box.SetImage(image);
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            m_ImgView = new UC_ImgUI();
            panel1.Controls.Add(m_ImgView);
            m_ImgView.Dock = DockStyle.Fill;

            m_CAM = new cls_CameraManagement();
            m_Refresh = new System.Timers.Timer();
            m_Refresh.Elapsed += m_Refresh_Elapsed;
            m_Refresh.Interval = 200;
            m_Refresh.Enabled = false;
        }
        private Bitmap m_SrcImage = null;
        private bool m_GrabeFlag = false;
        private Stopwatch _swTimeGrabCost = new Stopwatch();
        private uint m_GrabeFailCnt = 0;
        private void m_Refresh_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (m_GrabeFlag) { return; }
            m_GrabeFlag = true;
            try
            {
                bool bGetImageRtn = true;
                m_CAM._CamRealGrab[0] = true;
                m_CAM.ctlUsbCamera[0].StartGrabe();
                _swTimeGrabCost.Restart();
                while (m_CAM._CamRealGrab[0])
                {
                    if (_swTimeGrabCost.ElapsedMilliseconds > 1000)
                    {
                        bGetImageRtn = false;
                        break;
                    }
                    System.Threading.Thread.Sleep(50);
                }
                _swTimeGrabCost.Stop();
                m_CAM.ctlUsbCamera[0].StopGrabe();
                //if (bGetImageRtn == false)
                //{
                //    if (m_GrabeFailCnt > 5)
                //    {
                //        m_CAM._CamResetEn[0] = true;
                //        m_CAM.runResetCam();
                //        m_GrabeFlag = false;
                //        return;
                //    }
                //    m_GrabeFailCnt += 1;
                //    m_GrabeFlag = false;
                //    return;
                //}
                m_GrabeFailCnt = 0;
                if (m_CAM._CamRealGrab[0] == false & m_CAM._CamGrabErr[0] == false & bGetImageRtn == true)
                {
                    if (m_SrcImage != null)
                    {
                        m_SrcImage.Dispose();
                        m_SrcImage = null;
                    }

                    Bitmap temp = m_CAM.GetBitmap(0);
                    m_SrcImage = temp.Clone(new Rectangle(0, 0, temp.Width, temp.Height), temp.PixelFormat);
                    RefreshImageToUI(m_SrcImage, m_ImgView);
                    temp.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(string.Format("[CAM Grabe] {0}", ex.Message));
            }
            m_GrabeFlag = false;
        }

        private void event_RecValue(byte[] byteArrayRecv)
        {
            Console.WriteLine(string.Format("[Recv] {0}", byteArrayRecv.ToString()));
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            m_CAM.ctlUsbCamera[0].Stop();
            m_CAM.CamDisp();
        }

        private void btnRelayOff_Click(object sender, EventArgs e)
        {
            m_Refresh.Enabled = false;
        }

        private void btnOnRelay_Click(object sender, EventArgs e)
        {
            m_Refresh.Enabled = true;
        }





    }
}
