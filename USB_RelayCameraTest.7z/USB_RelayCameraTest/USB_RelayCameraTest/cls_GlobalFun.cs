﻿using System;
using System.Collections;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace USB_RelayCameraTest
{
    public class cls_GlobalFun
    {
        public static bool FileExist(string FileName)
        {
            return System.IO.File.Exists(FileName);
        }

        public static void SerializeToFile<T>(T obj, string filePath)
        {
            var xmlSer = new XmlSerializer(typeof(T));
            var sw = new StreamWriter(filePath, false, Encoding.UTF8);
            var namespaces = new XmlSerializerNamespaces();   // 移除XML命名空間
            namespaces.Add(string.Empty, string.Empty);
            try
            {
                xmlSer.Serialize(sw, obj, namespaces); // , namespaces
            }
            catch (Exception ex)
            {
                throw new Exception("[SerializeToFile] 資料儲存失敗, ErrMessage:" + ex.Message);
            }
            finally
            {
                sw.Close();
                sw.Dispose();
            }
        }

        public static T DeserializeByFile<T>(string FilePath)
        {
            var reader = new StreamReader(FilePath);
            var xmlSerialize = new XmlSerializer(typeof(T)); // 以objType建立XML序列化元件
            try
            {
                var obj = xmlSerialize.Deserialize(reader);
                return (T)obj;
            }
            catch (Exception ex)
            {
                throw new Exception("[Deserialize] 檔案載入失敗, ErrMessage:" + ex.Message);
            }
            finally
            {
                reader.Close();
            }
        }

    
        public static bool CalcStageAngle(double LX, double LY, double RX, double RY, ref double StageAngle)
        {
            try
            {
                double dX = RX - LX;
                double dY = RY - LY;
                double delta_theta = -1 * Math.Round(Math.Atan(dY / dX) * 180d / Math.PI, 3);
                if (delta_theta < -10 | delta_theta > 10d)
                {
                    MessageBox.Show("calc andle Err");
                    StageAngle = 0d;
                    return false;
                }

                StageAngle = delta_theta;
                return true;
            }
            catch (Exception ex)
            {
                StageAngle = 0d;
                return false;
            }
        }

        public static bool CalcP2PDistance(double P1_X, double P1_Y, double P2_X, double P2_Y, ref double P2P_Distance)
        {
            double dX = P2_X - P1_X;
            double dY = P2_Y - P1_Y;
            double dDist = 0d;
            try
            {
                dDist = Math.Round(Math.Sqrt(Math.Pow(dX, 2d) + Math.Pow(dY, 2d)), 3);
                P2P_Distance = dDist;
                return true;
            }
            catch (Exception ex)
            {
                P2P_Distance = 0d;
                return false;
            }
        }

        public static bool CalcRotaOffset(double dSrcX, double dSrcY, double dRotaCX, double dRotaCY, double dAngle, ref double dTargetX, ref double dTargetY)
        {
            double SX = dSrcX;
            double SY = dSrcY;
            double CX = dRotaCX;
            double CY = dRotaCY;
            double RotaAngle = dAngle;
            double TX = 0d;
            double TY = 0d;
            try
            {
                double AngleRad = RotaAngle / 180d * Math.PI;
                TX = (SX - CX) * Math.Cos(AngleRad) - (SY - CY) * Math.Sin(AngleRad) + CX;
                TY = (SX - CX) * Math.Sin(AngleRad) + (SY - CY) * Math.Cos(AngleRad) + CY;
                dTargetX = TX;
                dTargetY = TY;
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}