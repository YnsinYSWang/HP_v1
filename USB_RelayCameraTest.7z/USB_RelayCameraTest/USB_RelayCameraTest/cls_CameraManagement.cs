﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;
using AForgUSBCamCTL;
using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Structure;

namespace USB_RelayCameraTest
{
    struct CamDevice
    {
        public string m_devName;
        public int m_devID;
        public Guid m_identifier;

        public CamDevice(int ID, string Name, Guid Identity)
        {
            Identity = new Guid();
            m_devID = ID;
            m_devName = Name;
            m_identifier = Identity;
        }

        public override string ToString()
        {
            return string.Format("[ {0} ] {1} : {2}", m_devID, m_devName, m_identifier);
        }
    }

    public class cls_ConfigCameraParameter
    {
        public class ConfigCamera
        {
            [XmlElement("CameraCount")]
            public int CameraCount { get; set; }
            [XmlElement("ConfigCameraParameter")]
            public List<ConfigCameraParameter> ConfigCameraParameter { get; set; }
        }

        public class ConfigCameraParameter
        {
            [XmlElement("VID")]
            public string VID;
            [XmlElement("PID")]
            public string PID;
            [XmlElement("CameraID")]
            public string CameraID;
            [XmlElement("CameraSize")]
            public Size CameraSize;
            [XmlElement("IsFlipHorizontal")]
            public bool IsFlipHorizontal;
            [XmlElement("IsFlipVertical")]
            public bool IsFlipVertical;
            [XmlElement("IsConversionRemap")]
            public bool IsConversionRemap;
            [XmlElement("IsOutputRota")]
            public bool IsOutputRota;
            [XmlElement("RotaAngle")]
            public double RotaAngle;
        }
    }

    public class cls_CameraManagement
    {
        private string ConfigPath = Application.StartupPath + @"\Init\ConfigCameraParameter.xml";
        public cls_ConfigCameraParameter.ConfigCamera ConfigCameraParameter;
        public bool bInitCameraStatus = false;
        public CameraInterface[] ctlUsbCamera = null;
        // ------------------

        public event eventErrorMsg01EventHandler eventErrorMsg01;

        public delegate void eventErrorMsg01EventHandler(int iCameraNo, string strErrorMsg);

        public event eventErrorMsg02EventHandler eventErrorMsg02;

        public delegate void eventErrorMsg02EventHandler(int iCameraNo, string strErrorMsg);

        // ----全錯誤訊息由此方送
        public event eventErrorMsgEventHandler eventErrorMsg;

        public delegate void eventErrorMsgEventHandler(int iCameraNo, string strErrorMsg);

        private int _iImageWidth = 0;
        private int _iImageHeight = 0;
        public int _CameraTotal = 0;
        // 修改全部Camera圖片都由此Class管理
        private Bitmap[] _CamImage;
        public bool[] _CamRealGrab;
        public bool[] _CamGrabFlag;
        public bool[] _CamGrabErr;
        private bool[] _CamGrabEventFlag;
        public bool[] _CamGrabTaskFlag;
        public bool[] _CamCopyImage;
        public bool[] _CamAutoGrabFlag;
        public bool[] _CamResetEn = new bool[] { false, false };
        public bool _bMapParaLoad = false;
        //private Matrix<float> mapx;
        //private Matrix<float> mapy;
        private List<CamDevice> _ltAllCamDevice = new List<CamDevice>();
        private System.Timers.Timer _tmr_EnCam;
        Mutex m_mutex = new Mutex();
        public Bitmap GetBitmap(int index)
        {
            if (_CamImage[index] == null)
                return null;
            m_mutex.WaitOne();
            Bitmap bitmap = _CamImage[index].Clone(new Rectangle(0, 0, _CamImage[index].Width, _CamImage[index].Height), _CamImage[index].PixelFormat);
            m_mutex.ReleaseMutex();
            return bitmap;
        }
        #region ---Properties----
        public bool ReTryStatus
        {
            get
            {
                return _tmr_EnCam.Enabled;
            }
        }

        public bool ReTryBuzy
        {
            get
            {
                return _CamResetFlag;
            }
        }

        public bool CamRStatus
        {
            get
            {
                return ctlUsbCamera[0].LiveStatus & !_CamResetFlag;
            }
        }

        public bool CamLStatus
        {
            get
            {
                return ctlUsbCamera[1].LiveStatus & !_CamResetFlag;
            }
        }

        public bool CamRFirstStatus
        {
            get
            {
                return ctlUsbCamera[0].IsGrabFirstImage;
            }
        }

        public bool CamLFirstStatus
        {
            get
            {
                return ctlUsbCamera[1].IsGrabFirstImage;
            }
        }
        #endregion
        private cls_baseSerialPort m_RelayCTL = null;

        public cls_CameraManagement()
        {
            m_RelayCTL = new cls_baseSerialPort();
            m_RelayCTL.Open();
            bInitCameraStatus = false;
            ConfigCameraParameter = cls_GlobalFun.DeserializeByFile<cls_ConfigCameraParameter.ConfigCamera>(ConfigPath);
            int iCameraCount = ConfigCameraParameter.CameraCount; // ConfigCameraParameter.CameraCount


            _tmr_EnCam = new System.Timers.Timer();
            _tmr_EnCam.Interval = 500d;
            _tmr_EnCam.Elapsed += _tmrRunProcess_Elapsed;
            _tmr_EnCam.Enabled = false;
            _iImageWidth = ConfigCameraParameter.ConfigCameraParameter[0].CameraSize.Width;
            _iImageHeight = ConfigCameraParameter.ConfigCameraParameter[0].CameraSize.Height;
            _CamImage = new Bitmap[1];
            _CamRealGrab = new bool[1];
            _CamGrabFlag = new bool[1];
            _CamGrabEventFlag = new bool[1];
            _CamGrabErr = new bool[1];
            _CamGrabTaskFlag = new bool[1];
            _CamCopyImage = new bool[1];
            _CamAutoGrabFlag = new bool[1];
            ctlUsbCamera = new cls_CamAForgBase[1];

            _CamImage[0] = new Bitmap(_iImageWidth, _iImageHeight, PixelFormat.Format8bppIndexed);
            _CamRealGrab[0] = false;
            _CamGrabFlag[0] = false;
            _CamGrabEventFlag[0] = false;
            _CamGrabErr[0] = false;
            _CamResetEn[0] = true;
            ctlUsbCamera[0] = new cls_CamAForgBase();

            var colorPalette = _CamImage[0].Palette;
            for (int i = 0; i <= 256 - 1; i++)
                colorPalette.Entries[i] = Color.FromArgb(i, i, i);
            for (int iIndex = 0; iIndex < _CamImage.Length; iIndex++)
            {
                _CamImage[iIndex].Palette = colorPalette;
            }

            runResetCam();
            _CameraTotal = 1;
            bInitCameraStatus = true;
        }

        private void OpenCamRelay()
        {
            byte[] tmpSend = new byte[] { 0xA0, 0x01, 0x00, 0xA1 };
            m_RelayCTL.Send(tmpSend);

        }

        private void CloseCamRelay()
        {
            byte[] tmpSend = new byte[] { 0xA0, 0x01, 0x01, 0xA2 };
            m_RelayCTL.Send(tmpSend);
        }

        private bool[] _EvenGrabeFlag = new bool[] { false, false };
        // ----新方法測試 by AForg------
        private void CameraGrabImageEvent(int iCamNo, Bitmap SrcImg)
        {
            if (_EvenGrabeFlag[iCamNo] == true)
                return;
            _EvenGrabeFlag[iCamNo] = true;
            // Console.WriteLine(String.Format("{0} Trigger Image.", Now.ToString("HH:mm:ss_fff")))
            Bitmap outputBitmap = null;
            Bitmap tmpRemap = null;
            Bitmap tmpRote = null;
            Bitmap tmpColor = null;
            try
            {
                if (_CamGrabEventFlag[iCamNo] == true)
                    return;
                _CamGrabEventFlag[iCamNo] = true;
                _CamGrabErr[iCamNo] = false;
                
                tmpColor = tfColorImage(ref SrcImg);
                m_mutex.WaitOne();
                outputBitmap = tmpColor;
                Bitmap tmpBitmap = outputBitmap.Clone(new Rectangle(0, 0, outputBitmap.Width, outputBitmap.Height), outputBitmap.PixelFormat);
                UpdateBitmapFrame(tmpBitmap, ref _CamImage[iCamNo]);
                bool RTN = CopyBitmapData(tmpBitmap, _CamImage[iCamNo]);
                tmpBitmap.Dispose();
                m_mutex.ReleaseMutex();
                if (RTN == false)
                    throw new Exception(string.Format("[{0}] Camera Copy Image Error.", iCamNo));
                if (outputBitmap != null)
                    outputBitmap.Dispose();
                if (tmpRote != null)
                    tmpRote.Dispose();
                if (tmpRemap != null)
                    tmpRemap.Dispose();
                if (tmpColor != null)
                    tmpColor.Dispose();
                _CamGrabFlag[iCamNo] = false;
                _CamGrabEventFlag[iCamNo] = false;
                _CamGrabErr[iCamNo] = false;
                _CamRealGrab[iCamNo] = false;
            }

            // Console.WriteLine(String.Format("-----------------{0} Cam[{1}] Grabe", Now, iCamNo))
            catch (Exception ex)
            {
                if (outputBitmap != null)
                    outputBitmap.Dispose();
                if (tmpRote != null)
                    tmpRote.Dispose();
                if (tmpRemap != null)
                    tmpRemap.Dispose();
                if (tmpColor != null)
                    tmpColor.Dispose();
                _CamGrabFlag[iCamNo] = false;
                _CamGrabEventFlag[iCamNo] = false;
                _CamGrabErr[iCamNo] = true;
                _CamRealGrab[iCamNo] = false;
            }
            _EvenGrabeFlag[iCamNo] = false;
        }
        public void CamDisp()
        {
            m_RelayCTL.Close();
        }

        public void UpdateBitmapFrame(Bitmap SrcBitmap, ref Bitmap TragetBitmpa)
        {
            try
            {
                if (TragetBitmpa == null)
                {
                    TragetBitmpa = SrcBitmap.Clone(new Rectangle(0, 0, SrcBitmap.Width, SrcBitmap.Height), SrcBitmap.PixelFormat);
                    //TragetBitmpa = new Bitmap(SrcBitmap.Width, SrcBitmap.Height, SrcBitmap.PixelFormat);
                    //TragetBitmpa.Palette = SrcBitmap.Palette;
                    Console.WriteLine(string.Format("Target Image為空，啟動新建Target Image."));
                }
                int t_width;
                int s_width;
                int t_height;
                int s_height;

                try
                {
                    t_width = TragetBitmpa.Width;
                    s_width = SrcBitmap.Width;
                    t_height = TragetBitmpa.Height;
                    s_height = SrcBitmap.Height;
                }
                catch (Exception)
                {
                    return;
                }

                if ((t_width != s_width) || (t_height != s_height) || TragetBitmpa.PixelFormat != SrcBitmap.PixelFormat)
                {
                    TragetBitmpa = SrcBitmap.Clone(new Rectangle(0, 0, SrcBitmap.Width, SrcBitmap.Height), SrcBitmap.PixelFormat);
                    //TragetBitmpa = new Bitmap(SrcBitmap.Width, SrcBitmap.Height, SrcBitmap.PixelFormat);    
                    //TragetBitmpa.Palette = SrcBitmap.Palette;
                    Console.WriteLine(string.Format("Src與Target不同， 啟動重建Target Image."));
                }
            }
            catch (Exception ex)
            {
            }

        }

        public void runResetCam()
        {
            _tmr_EnCam.Enabled = true;
        }

        public bool CopyBitmapData(Bitmap SrcBitmap, Bitmap TargetBitmap)
        {
            bool RTN = false;
            try
            {
                var SrcData = SrcBitmap.LockBits(new Rectangle(0, 0, SrcBitmap.Width, SrcBitmap.Height), ImageLockMode.ReadOnly, SrcBitmap.PixelFormat);
                int iLength = SrcData.Stride * SrcData.Height;
                var tmpManageData = new byte[iLength];
                Marshal.Copy(SrcData.Scan0, tmpManageData, 0, iLength);
                SrcBitmap.UnlockBits(SrcData);
                var TargetData = TargetBitmap.LockBits(new Rectangle(0, 0, TargetBitmap.Width, TargetBitmap.Height), ImageLockMode.ReadWrite, TargetBitmap.PixelFormat);
                iLength = TargetData.Stride * TargetData.Height;
                Marshal.Copy(tmpManageData, 0, TargetData.Scan0, iLength);
                TargetBitmap.UnlockBits(TargetData);
                RTN = true;
            }
            catch (Exception ex)
            {
                RTN = false;
            }

            return RTN;
        }

        public Bitmap tfColorImage(ref Bitmap src_img, int iCamNo = 0)
        {

                try
                {
                    var tmpInputImage = new Image<Gray, byte>(src_img);
                    Bitmap result = tmpInputImage.ToBitmap();
                    tmpInputImage.Dispose();
                  
                    return result;
                }
                catch (Exception ex)
                {
                    return null;
                }
            
        }
  
        private bool _CamResetFlag = false;

        private void _tmrRunProcess_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            _tmr_EnCam.Enabled = false;
            if (_CamResetFlag == true)
                return;
            _CamResetFlag = true;
            if (ctlUsbCamera[0].IsFindCam == true)
            {
                if (ctlUsbCamera[0].IsFindCam == true)
                {
                    ctlUsbCamera[0].Stop();
                }
                Thread.Sleep(500);
            }

            CloseCamRelay();
            Thread.Sleep(1000);
            OpenCamRelay();
            Thread.Sleep(5000);

            var RestRtn = new bool[] { false };
            for (int iIndex = 0; iIndex < 1; iIndex += 1)
            {
                if (_CamResetEn[iIndex] == true)
                {
                    if (ctlUsbCamera[iIndex] !=null)
                    {
                        if (ctlUsbCamera[iIndex].IsFindCam == true)
                        {
                            ctlUsbCamera[iIndex].eventGrabeImage -= CameraGrabImageEvent;
                            ctlUsbCamera[iIndex].StopGrabe();
                            Thread.Sleep(200);                            
                        }
                    }

                    var ConfigCamera = ConfigCameraParameter.ConfigCameraParameter[iIndex];
                    RestRtn[iIndex] = ctlUsbCamera[iIndex].initCam(iIndex, ConfigCamera.PID, new Size(ConfigCamera.CameraSize.Width, ConfigCamera.CameraSize.Height));
                    if (RestRtn[iIndex] == true)
                    {
                        ctlUsbCamera[iIndex].eventGrabeImage += CameraGrabImageEvent;
                    }
                }

                Thread.Sleep(200);
            }

            for (int iIndex = 0; iIndex < 1; iIndex += 1)
            {
                if (RestRtn[iIndex] == true)
                {
                    ctlUsbCamera[iIndex].Start();
                    Thread.Sleep(200);
                }
            }
            Thread.Sleep(1000);
            for (int iIndex = 0; iIndex < 1; iIndex += 1)
            {
                if (RestRtn[iIndex] == true)
                {
                    _CamResetEn[iIndex] = false;
                }
            }

            _CamResetFlag = false;
        }
    }
}