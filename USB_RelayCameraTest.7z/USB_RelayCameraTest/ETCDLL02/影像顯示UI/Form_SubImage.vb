﻿Public Class Form_SubImage


    Private UC As UC_ImgUI

    Private Sub Form_SubImage_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        UC = New UC_ImgUI
        Me.Controls.Add(UC)
        UC.Dock = DockStyle.Fill
    End Sub

    Public Sub UpLoad(ByVal img As Bitmap)
        UC.UpLoadImage(img)
    End Sub
End Class