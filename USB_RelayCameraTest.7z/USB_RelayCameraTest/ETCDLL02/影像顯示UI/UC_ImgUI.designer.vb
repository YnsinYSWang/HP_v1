﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UC_ImgUI
    Inherits System.Windows.Forms.UserControl

    'UserControl1 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(UC_ImgUI))
        Me.Panel_Main = New System.Windows.Forms.Panel()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripMenuItem9 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SizeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.GetSelectColorRangeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.GrabSelectAreaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem10 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.EraseImageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripStatusLabel5 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.Btn_LoadImage = New System.Windows.Forms.ToolStripButton()
        Me.Btn_ImageSaveAs = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.Btn_ImageFill = New System.Windows.Forms.ToolStripButton()
        Me.Btn_FitSize = New System.Windows.Forms.ToolStripButton()
        Me.Btn_RealSize = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.Btn_SizeUp = New System.Windows.Forms.ToolStripButton()
        Me.Btn_SizeDown = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator()
        Me.Btc_CenterLine = New System.Windows.Forms.ToolStripButton()
        Me.Btn_CuserLine = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator()
        Me.Btn_CalColorRange = New System.Windows.Forms.ToolStripButton()
        Me.Btn_GrabRecImage = New System.Windows.Forms.ToolStripButton()
        Me.Btn_GetMinifiedImage = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator13 = New System.Windows.Forms.ToolStripSeparator()
        Me.Btn_ClearImage = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator14 = New System.Windows.Forms.ToolStripSeparator()
        Me.lbl04 = New System.Windows.Forms.ToolStripLabel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lbl07 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lbl06 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lbl05 = New System.Windows.Forms.Label()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel_Main
        '
        Me.Panel_Main.AutoScroll = True
        Me.Panel_Main.ContextMenuStrip = Me.ContextMenuStrip1
        Me.Panel_Main.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel_Main.Location = New System.Drawing.Point(0, 0)
        Me.Panel_Main.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel_Main.Name = "Panel_Main"
        Me.Panel_Main.Size = New System.Drawing.Size(820, 500)
        Me.Panel_Main.TabIndex = 0
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator6, Me.ToolStripMenuItem6, Me.ToolStripMenuItem1, Me.ToolStripSeparator1, Me.ToolStripMenuItem9, Me.ToolStripSeparator2, Me.ToolStripMenuItem8, Me.ToolStripMenuItem4, Me.ToolStripMenuItem3, Me.ToolStripSeparator4, Me.ToolStripMenuItem7, Me.SizeToolStripMenuItem, Me.ToolStripSeparator3, Me.ToolStripMenuItem5, Me.ToolStripMenuItem2, Me.ToolStripSeparator5, Me.GetSelectColorRangeToolStripMenuItem, Me.ToolStripSeparator7, Me.GrabSelectAreaToolStripMenuItem, Me.ToolStripMenuItem10, Me.ToolStripSeparator8, Me.EraseImageToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(225, 360)
        Me.ContextMenuStrip1.Text = "ClearImage"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(221, 6)
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Image = CType(resources.GetObject("ToolStripMenuItem6.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(224, 22)
        Me.ToolStripMenuItem6.Text = "Load Image"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Image = CType(resources.GetObject("ToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(224, 22)
        Me.ToolStripMenuItem1.Text = "Image Save As"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(221, 6)
        '
        'ToolStripMenuItem9
        '
        Me.ToolStripMenuItem9.Image = CType(resources.GetObject("ToolStripMenuItem9.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem9.Name = "ToolStripMenuItem9"
        Me.ToolStripMenuItem9.Size = New System.Drawing.Size(224, 22)
        Me.ToolStripMenuItem9.Text = "Raise Coordinate event"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(221, 6)
        '
        'ToolStripMenuItem8
        '
        Me.ToolStripMenuItem8.Image = CType(resources.GetObject("ToolStripMenuItem8.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem8.Name = "ToolStripMenuItem8"
        Me.ToolStripMenuItem8.Size = New System.Drawing.Size(224, 22)
        Me.ToolStripMenuItem8.Text = "Size mode - Fill to window"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Image = CType(resources.GetObject("ToolStripMenuItem4.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(224, 22)
        Me.ToolStripMenuItem4.Text = "Size mode - Fit to window"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Image = CType(resources.GetObject("ToolStripMenuItem3.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(224, 22)
        Me.ToolStripMenuItem3.Text = "Size mode - Real size"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(221, 6)
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.Image = CType(resources.GetObject("ToolStripMenuItem7.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(224, 22)
        Me.ToolStripMenuItem7.Text = "Size Up"
        '
        'SizeToolStripMenuItem
        '
        Me.SizeToolStripMenuItem.Image = CType(resources.GetObject("SizeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SizeToolStripMenuItem.Name = "SizeToolStripMenuItem"
        Me.SizeToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.SizeToolStripMenuItem.Text = "Size Down"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(221, 6)
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.Image = CType(resources.GetObject("ToolStripMenuItem5.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(224, 22)
        Me.ToolStripMenuItem5.Text = "Center Line Hide / Show"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Image = CType(resources.GetObject("ToolStripMenuItem2.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(224, 22)
        Me.ToolStripMenuItem2.Text = "Cusor Line Hide/Show"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(221, 6)
        '
        'GetSelectColorRangeToolStripMenuItem
        '
        Me.GetSelectColorRangeToolStripMenuItem.Image = CType(resources.GetObject("GetSelectColorRangeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GetSelectColorRangeToolStripMenuItem.Name = "GetSelectColorRangeToolStripMenuItem"
        Me.GetSelectColorRangeToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.GetSelectColorRangeToolStripMenuItem.Text = "Get Select Color Range"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(221, 6)
        '
        'GrabSelectAreaToolStripMenuItem
        '
        Me.GrabSelectAreaToolStripMenuItem.Image = CType(resources.GetObject("GrabSelectAreaToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GrabSelectAreaToolStripMenuItem.Name = "GrabSelectAreaToolStripMenuItem"
        Me.GrabSelectAreaToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.GrabSelectAreaToolStripMenuItem.Text = "Grab Select Area"
        '
        'ToolStripMenuItem10
        '
        Me.ToolStripMenuItem10.Image = CType(resources.GetObject("ToolStripMenuItem10.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem10.Name = "ToolStripMenuItem10"
        Me.ToolStripMenuItem10.Size = New System.Drawing.Size(224, 22)
        Me.ToolStripMenuItem10.Text = "Get Shrinking Image"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(221, 6)
        '
        'EraseImageToolStripMenuItem
        '
        Me.EraseImageToolStripMenuItem.Image = CType(resources.GetObject("EraseImageToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EraseImageToolStripMenuItem.Name = "EraseImageToolStripMenuItem"
        Me.EraseImageToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.EraseImageToolStripMenuItem.Text = "Erase Image"
        '
        'ToolStripStatusLabel5
        '
        Me.ToolStripStatusLabel5.Name = "ToolStripStatusLabel5"
        Me.ToolStripStatusLabel5.Size = New System.Drawing.Size(0, 17)
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ToolStrip1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Btn_LoadImage, Me.Btn_ImageSaveAs, Me.ToolStripSeparator9, Me.Btn_ImageFill, Me.Btn_FitSize, Me.Btn_RealSize, Me.ToolStripSeparator10, Me.Btn_SizeUp, Me.Btn_SizeDown, Me.ToolStripSeparator11, Me.Btc_CenterLine, Me.Btn_CuserLine, Me.ToolStripSeparator12, Me.Btn_CalColorRange, Me.Btn_GrabRecImage, Me.Btn_GetMinifiedImage, Me.ToolStripSeparator13, Me.Btn_ClearImage, Me.ToolStripSeparator14, Me.lbl04})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 500)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(820, 25)
        Me.ToolStrip1.TabIndex = 5
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'Btn_LoadImage
        '
        Me.Btn_LoadImage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.Btn_LoadImage.Image = CType(resources.GetObject("Btn_LoadImage.Image"), System.Drawing.Image)
        Me.Btn_LoadImage.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Btn_LoadImage.Name = "Btn_LoadImage"
        Me.Btn_LoadImage.Size = New System.Drawing.Size(23, 22)
        Me.Btn_LoadImage.Text = "LoadImage"
        Me.Btn_LoadImage.ToolTipText = "LoadImage"
        Me.Btn_LoadImage.Visible = False
        '
        'Btn_ImageSaveAs
        '
        Me.Btn_ImageSaveAs.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.Btn_ImageSaveAs.Image = CType(resources.GetObject("Btn_ImageSaveAs.Image"), System.Drawing.Image)
        Me.Btn_ImageSaveAs.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Btn_ImageSaveAs.Name = "Btn_ImageSaveAs"
        Me.Btn_ImageSaveAs.Size = New System.Drawing.Size(23, 22)
        Me.Btn_ImageSaveAs.Text = "ImageSaveAs"
        Me.Btn_ImageSaveAs.ToolTipText = "ImageSaveAs"
        Me.Btn_ImageSaveAs.Visible = False
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(6, 25)
        Me.ToolStripSeparator9.Visible = False
        '
        'Btn_ImageFill
        '
        Me.Btn_ImageFill.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.Btn_ImageFill.Image = CType(resources.GetObject("Btn_ImageFill.Image"), System.Drawing.Image)
        Me.Btn_ImageFill.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Btn_ImageFill.Name = "Btn_ImageFill"
        Me.Btn_ImageFill.Size = New System.Drawing.Size(23, 22)
        Me.Btn_ImageFill.Text = "ImageFillType=Fill"
        Me.Btn_ImageFill.ToolTipText = "ImageFillType=Fill"
        Me.Btn_ImageFill.Visible = False
        '
        'Btn_FitSize
        '
        Me.Btn_FitSize.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.Btn_FitSize.Image = CType(resources.GetObject("Btn_FitSize.Image"), System.Drawing.Image)
        Me.Btn_FitSize.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Btn_FitSize.Name = "Btn_FitSize"
        Me.Btn_FitSize.Size = New System.Drawing.Size(23, 22)
        Me.Btn_FitSize.Text = "ImageFillType=Fit"
        Me.Btn_FitSize.Visible = False
        '
        'Btn_RealSize
        '
        Me.Btn_RealSize.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.Btn_RealSize.Image = CType(resources.GetObject("Btn_RealSize.Image"), System.Drawing.Image)
        Me.Btn_RealSize.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Btn_RealSize.Name = "Btn_RealSize"
        Me.Btn_RealSize.Size = New System.Drawing.Size(23, 22)
        Me.Btn_RealSize.Text = "ImageFillType=RealSize"
        Me.Btn_RealSize.Visible = False
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(6, 25)
        Me.ToolStripSeparator10.Visible = False
        '
        'Btn_SizeUp
        '
        Me.Btn_SizeUp.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.Btn_SizeUp.Image = CType(resources.GetObject("Btn_SizeUp.Image"), System.Drawing.Image)
        Me.Btn_SizeUp.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Btn_SizeUp.Name = "Btn_SizeUp"
        Me.Btn_SizeUp.Size = New System.Drawing.Size(23, 22)
        Me.Btn_SizeUp.Text = "SizeUp"
        Me.Btn_SizeUp.Visible = False
        '
        'Btn_SizeDown
        '
        Me.Btn_SizeDown.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.Btn_SizeDown.Image = CType(resources.GetObject("Btn_SizeDown.Image"), System.Drawing.Image)
        Me.Btn_SizeDown.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Btn_SizeDown.Name = "Btn_SizeDown"
        Me.Btn_SizeDown.Size = New System.Drawing.Size(23, 22)
        Me.Btn_SizeDown.Text = "SizeDown"
        Me.Btn_SizeDown.ToolTipText = "SizeDown"
        Me.Btn_SizeDown.Visible = False
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(6, 25)
        Me.ToolStripSeparator11.Visible = False
        '
        'Btc_CenterLine
        '
        Me.Btc_CenterLine.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.Btc_CenterLine.Image = CType(resources.GetObject("Btc_CenterLine.Image"), System.Drawing.Image)
        Me.Btc_CenterLine.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Btc_CenterLine.Name = "Btc_CenterLine"
        Me.Btc_CenterLine.Size = New System.Drawing.Size(23, 22)
        Me.Btc_CenterLine.Text = "Center Line Show/Hide"
        Me.Btc_CenterLine.Visible = False
        '
        'Btn_CuserLine
        '
        Me.Btn_CuserLine.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.Btn_CuserLine.Image = CType(resources.GetObject("Btn_CuserLine.Image"), System.Drawing.Image)
        Me.Btn_CuserLine.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Btn_CuserLine.Name = "Btn_CuserLine"
        Me.Btn_CuserLine.Size = New System.Drawing.Size(23, 22)
        Me.Btn_CuserLine.Text = "Cuser Line Show/Hide"
        Me.Btn_CuserLine.Visible = False
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(6, 25)
        Me.ToolStripSeparator12.Visible = False
        '
        'Btn_CalColorRange
        '
        Me.Btn_CalColorRange.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.Btn_CalColorRange.Image = CType(resources.GetObject("Btn_CalColorRange.Image"), System.Drawing.Image)
        Me.Btn_CalColorRange.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Btn_CalColorRange.Name = "Btn_CalColorRange"
        Me.Btn_CalColorRange.Size = New System.Drawing.Size(23, 22)
        Me.Btn_CalColorRange.Text = "Cal Color Range"
        Me.Btn_CalColorRange.Visible = False
        '
        'Btn_GrabRecImage
        '
        Me.Btn_GrabRecImage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.Btn_GrabRecImage.Image = CType(resources.GetObject("Btn_GrabRecImage.Image"), System.Drawing.Image)
        Me.Btn_GrabRecImage.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Btn_GrabRecImage.Name = "Btn_GrabRecImage"
        Me.Btn_GrabRecImage.Size = New System.Drawing.Size(23, 22)
        Me.Btn_GrabRecImage.Text = "Grab Rec Image"
        Me.Btn_GrabRecImage.Visible = False
        '
        'Btn_GetMinifiedImage
        '
        Me.Btn_GetMinifiedImage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.Btn_GetMinifiedImage.Image = CType(resources.GetObject("Btn_GetMinifiedImage.Image"), System.Drawing.Image)
        Me.Btn_GetMinifiedImage.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Btn_GetMinifiedImage.Name = "Btn_GetMinifiedImage"
        Me.Btn_GetMinifiedImage.Size = New System.Drawing.Size(23, 22)
        Me.Btn_GetMinifiedImage.Text = "Get Minified Image"
        Me.Btn_GetMinifiedImage.Visible = False
        '
        'ToolStripSeparator13
        '
        Me.ToolStripSeparator13.Name = "ToolStripSeparator13"
        Me.ToolStripSeparator13.Size = New System.Drawing.Size(6, 25)
        Me.ToolStripSeparator13.Visible = False
        '
        'Btn_ClearImage
        '
        Me.Btn_ClearImage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.Btn_ClearImage.Image = CType(resources.GetObject("Btn_ClearImage.Image"), System.Drawing.Image)
        Me.Btn_ClearImage.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Btn_ClearImage.Name = "Btn_ClearImage"
        Me.Btn_ClearImage.Size = New System.Drawing.Size(23, 22)
        Me.Btn_ClearImage.Text = "Clear Image"
        Me.Btn_ClearImage.Visible = False
        '
        'ToolStripSeparator14
        '
        Me.ToolStripSeparator14.Name = "ToolStripSeparator14"
        Me.ToolStripSeparator14.Size = New System.Drawing.Size(6, 25)
        Me.ToolStripSeparator14.Visible = False
        '
        'lbl04
        '
        Me.lbl04.Name = "lbl04"
        Me.lbl04.Size = New System.Drawing.Size(37, 22)
        Me.lbl04.Text = "Status"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel1.Controls.Add(Me.lbl07)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.lbl06)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.lbl05)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Font = New System.Drawing.Font("微軟正黑體", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Panel1.Location = New System.Drawing.Point(0, 525)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(820, 16)
        Me.Panel1.TabIndex = 6
        '
        'lbl07
        '
        Me.lbl07.AutoSize = True
        Me.lbl07.Dock = System.Windows.Forms.DockStyle.Left
        Me.lbl07.Font = New System.Drawing.Font("微軟正黑體", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.lbl07.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lbl07.Location = New System.Drawing.Point(30, 0)
        Me.lbl07.Name = "lbl07"
        Me.lbl07.Size = New System.Drawing.Size(13, 15)
        Me.lbl07.TabIndex = 4
        Me.lbl07.Text = ".."
        Me.lbl07.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Silver
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label2.ForeColor = System.Drawing.Color.Silver
        Me.Label2.Location = New System.Drawing.Point(28, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(2, 16)
        Me.Label2.TabIndex = 3
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lbl06
        '
        Me.lbl06.AutoSize = True
        Me.lbl06.Dock = System.Windows.Forms.DockStyle.Left
        Me.lbl06.Font = New System.Drawing.Font("微軟正黑體", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.lbl06.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lbl06.Location = New System.Drawing.Point(15, 0)
        Me.lbl06.Name = "lbl06"
        Me.lbl06.Size = New System.Drawing.Size(13, 15)
        Me.lbl06.TabIndex = 2
        Me.lbl06.Text = ".."
        Me.lbl06.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Silver
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label1.ForeColor = System.Drawing.Color.Silver
        Me.Label1.Location = New System.Drawing.Point(13, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(2, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lbl05
        '
        Me.lbl05.AutoSize = True
        Me.lbl05.Dock = System.Windows.Forms.DockStyle.Left
        Me.lbl05.Font = New System.Drawing.Font("微軟正黑體", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.lbl05.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lbl05.Location = New System.Drawing.Point(0, 0)
        Me.lbl05.Name = "lbl05"
        Me.lbl05.Size = New System.Drawing.Size(13, 15)
        Me.lbl05.TabIndex = 0
        Me.lbl05.Text = ".."
        Me.lbl05.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'UC_ImgUI
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSlateGray
        Me.Controls.Add(Me.Panel_Main)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "UC_ImgUI"
        Me.Size = New System.Drawing.Size(820, 541)
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel_Main As System.Windows.Forms.Panel
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem7 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SizeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem8 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem9 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents GetSelectColorRangeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents GrabSelectAreaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem10 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripStatusLabel5 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents EraseImageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents Btn_LoadImage As System.Windows.Forms.ToolStripButton
    Friend WithEvents Btn_ImageSaveAs As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Btn_ImageFill As System.Windows.Forms.ToolStripButton
    Friend WithEvents Btn_FitSize As System.Windows.Forms.ToolStripButton
    Friend WithEvents Btn_RealSize As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Btn_SizeUp As System.Windows.Forms.ToolStripButton
    Friend WithEvents Btn_SizeDown As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator11 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Btc_CenterLine As System.Windows.Forms.ToolStripButton
    Friend WithEvents Btn_CuserLine As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator12 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Btn_CalColorRange As System.Windows.Forms.ToolStripButton
    Friend WithEvents Btn_GrabRecImage As System.Windows.Forms.ToolStripButton
    Friend WithEvents Btn_GetMinifiedImage As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator13 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Btn_ClearImage As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator14 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents lbl04 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lbl05 As System.Windows.Forms.Label
    Friend WithEvents lbl07 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lbl06 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label

End Class
