﻿'........................................................................................................................
'........................................................................................................................
' .............................  AUO ETC  公用圖型顯示界面.....................................
' ............................   含公用變數, 類別 與函數       ......................................
' ............................  程式碼開發人 陳俊杰 Jethro 8606 3210 ..................
' ............................  改版日期 20200726   ...................................................
'........................................................................................................................
'........................................................................................................................


Imports ETCDLL02.EtcFunction

Public Class UC_ImgUI

    Private _ImageFileName As String = ""
    Private _RecBox As New Rectangle
    Private _ImageListType As Integer = 2 ' 0 Auto , 1 Stretch , 2 Fill
    Private Pic_photo As PictureBox
    Private ExternalX As Integer = 0
    Private ExternalY As Integer = 0
    Private _PixelSize_um As Double = 8.96
    Private _UCIndex As Integer = 0
    Private _LiveEnable As Boolean = False
    Private Property ErrorOccure As Boolean = False
    Private Property ErrorString As String = ""

    Public Enum eImageStretchType
        Auto = 0
        Stretch = 1
        Fill = 2
    End Enum

    Public Property ImageStretchType As eImageStretchType
        Get
            Return _ImageListType
        End Get
        Set(ByVal value As eImageStretchType)
            If value <> _ImageListType Then
                _ImageListType = value
                RefreshImageList()
            End If
        End Set
    End Property

    Public Property LiveEnable As Boolean
        Get
            Return _LiveEnable
        End Get
        Set(ByVal value As Boolean)
            If value <> _LiveEnable Then
                EnableLive(value)
                _LiveEnable = value
            End If
        End Set
    End Property

    '  變更 Live 狀態時關閉或開啟 部分功能, 避免當機
    Private Sub EnableLive(ByVal TEnable As Boolean)
        Dim IsLive As Boolean = TEnable
        ToolStripMenuItem2.Enabled = Not IsLive
        If IsLive Then CusorLineShowHideSwitch(False)
        GetSelectColorRangeToolStripMenuItem.Enabled = Not IsLive
        GrabSelectAreaToolStripMenuItem.Enabled = Not IsLive
        ToolStripMenuItem10.Enabled = Not IsLive
        EraseImageToolStripMenuItem.Enabled = Not IsLive
    End Sub

#Region "事件"
    ' Picture Box 產生Mouse Up 事件,跟著處發以下事件
    Public Event MouthUpEvents(ByVal Index As Integer, ByVal Pos_Pix As PointF, ByVal DistToCenter_Pix As PointF, ByVal DistToCenter_um As PointF)
    ' 事件觸發函數 
    Private Sub RaiseMouseUpEvent(ByVal X As Integer, ByVal Y As Integer)
        Dim TPic As PictureBox = Pic_photo  ' GetFrontImage()    '取得 Panel1裡面最上層的PictureBox
        If IsNothing(TPic.Image) Then
            Application.DoEvents()
            Exit Sub
        End If
        Dim LengthRate As Double = _PixelSize_um ' GetLengthRatio()
        Dim SizeRatioX As Double = TPic.Image.Width / TPic.Width
        Dim SizeRatioY As Double = TPic.Image.Height / TPic.Height
        Dim Pos_X As Single = X * SizeRatioX  ' 換算成完整大小後的X
        Dim Pos_Y As Single = Y * SizeRatioY ' 換算成完整大小後的Y
        Dim Pos_Pix As New PointF(Pos_X, Pos_Y)
        Dim DX As Double = (X - TPic.Width / 2) * SizeRatioX  ' 與中心偏移量 Pixel
        Dim DY As Double = (Y - TPic.Height / 2) * SizeRatioY
        Dim DistToCenter_Pix As New PointF(DX, DY)
        Dim DX_um As Double = DX * _PixelSize_um  ' 與中心偏移量 Pixel
        Dim DY_um As Double = DY * _PixelSize_um
        Dim DistToCenter_um As New PointF(DX_um, DY_um)
        RaiseEvent MouthUpEvents(_UCIndex, Pos_Pix, DistToCenter_Pix, DistToCenter_um)
    End Sub
#End Region
#Region "屬性"

    Public ReadOnly Property Image As Bitmap
        Get
            Return Pic_photo.Image
        End Get
    End Property

    Public Property PixelSize_um As Double
        Get
            Return _PixelSize_um
        End Get
        Set(ByVal value As Double)
            _PixelSize_um = value
        End Set
    End Property

    Public Property UCIndex As Integer
        Get
            Return _UCIndex
        End Get
        Set(ByVal value As Integer)
            _UCIndex = value
        End Set
    End Property
    Public ReadOnly Property ImageFileName As String
        Get
            Return _ImageFileName
        End Get
    End Property
    Public ReadOnly Property ImageFolder As String
        Get
            If _ImageFileName.Trim = "" Then Return ""
            Dim lastIndex As Integer = _ImageFileName.LastIndexOf("\")
            Return _ImageFileName.Substring(0, lastIndex)
        End Get
    End Property
    Public ReadOnly Property ImageName As String
        Get
            If _ImageFileName.Trim = "" Then Return ""
            Dim lastIndex As Integer = _ImageFileName.LastIndexOf("\")
            Return _ImageFileName.Substring(lastIndex + 1)
        End Get
    End Property
    Public ReadOnly Property RecBox As Rectangle
        Get
            Return _RecBox
        End Get
    End Property
    Public ReadOnly Property RecVisible As Boolean
        Get
            Return RecLine(0).Visible
        End Get
    End Property
    Public ReadOnly Property RecSizeEnough As Boolean
        Get
            Return _RecBox.Width >= 200 And _RecBox.Height >= 200
        End Get
    End Property
#End Region
    ' 物件程式進入點
    Public Sub New()

        ' 此為設計工具所需的呼叫。
        InitializeComponent()

        ' 在 InitializeComponent() 呼叫之後加入任何初始設定。
        InitialPictureBox()
    End Sub
    Public Sub New(ByVal Index As Integer)
        ' 此為設計工具所需的呼叫。
        InitializeComponent()

        ' 在 InitializeComponent() 呼叫之後加入任何初始設定。
        _UCIndex = Index
        InitialPictureBox()
    End Sub
    Private Sub UC_ImgUI_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        InstallRecLine() ' 安裝指示線 如中心線; 方塊線 ; 游標線等
        lineinstalled = True
        'Timer1.Enabled = True
    End Sub
    ' 初始化顯示區域
    Private Sub InitialPictureBox()
        If Not IsNothing(Pic_photo) Then
            Try
                Panel_Main.Controls.Remove(Pic_photo)
                Pic_photo = Nothing
                Threading.Thread.Sleep(10)
            Catch ex As Exception
            End Try
        End If

        Pic_photo = New PictureBox
        Pic_photo.Left = 0
        Pic_photo.Top = 0
        Pic_photo.Width = 1
        Pic_photo.Height = 1
        Pic_photo.SizeMode = PictureBoxSizeMode.AutoSize
        Pic_photo.BackColor = Color.Black
        Panel_Main.Controls.Add(Pic_photo)
        Pic_photo.Tag = "MainPicBox"
        Pic_photo.SendToBack()
        ' 指定Pic_Photo滑鼠對應事件
        AddHandler Pic_photo.MouseDown, AddressOf PictureBox_MouseDown
        AddHandler Pic_photo.MouseMove, AddressOf PictureBox_MouseMove
        AddHandler Pic_photo.MouseUp, AddressOf PictureBox_MouseUp
        AddHandler Pic_photo.MouseLeave, AddressOf PictureBox_MouseLeave
        AddHandler Pic_photo.MouseEnter, AddressOf PictureBox_MouseEnter
    End Sub

#Region "繪製方塊與中心線"
    Private lineinstalled As Boolean = False
    Private _ShowCusorLine As Boolean = False
    Private _DrawRec As Boolean = False
    Dim CenterLine(1) As PictureBox ' 中心線
    Dim CusorLine(3) As PictureBox ' 游標線
    Dim RecLine(3) As PictureBox   '  方塊線 0 左 1 右 2 上 3 下
    Dim VectorLine(1) As PictureBox   '  方位線
    Dim SX As Integer
    Dim SY As Integer
    Dim CX As Integer
    Dim CY As Integer
    ' 安裝指示線 如中心線; 方塊線 ; 游標線等, 同時指定各線段的滑鼠事件
    Private Sub InstallRecLine()
        ' 安裝 方塊線 
        For i As Integer = 0 To 3
            RecLine(i) = New PictureBox
            RecLine(i).Visible = False
            RecLine(i).BackColor = Color.Red
            Panel_Main.Controls.Add(RecLine(i))
            RecLine(i).ContextMenuStrip = ContextMenuStrip1 ' 指定快顯功能表到 RecLine
        Next
        RecLine(0).Width = 1
        RecLine(1).Width = 1
        RecLine(2).Height = 1
        RecLine(3).Height = 1
        ' 安裝 中心線 與 游標線 與 方  位線
        For i As Integer = 0 To 3
            CusorLine(i) = New PictureBox
            CusorLine(i).Visible = False
            CusorLine(i).BackColor = Color.Blue
            CusorLine(i).Enabled = False
            Panel_Main.Controls.Add(CusorLine(i))
            'CusorLine(i).ContextMenuStrip = ContextMenuStrip1 ' 指定快顯功能表到 CusorLine
        Next
        For i As Integer = 0 To 1
            CenterLine(i) = New PictureBox
            CenterLine(i).Visible = False
            CenterLine(i).BackColor = Color.Yellow
            CenterLine(i).ContextMenuStrip = ContextMenuStrip1 ' 指定快顯功能表到 CenterLine
            CenterLine(i).Enabled = False
            Panel_Main.Controls.Add(CenterLine(i))
            VectorLine(i) = New PictureBox
            VectorLine(i).Visible = False
            VectorLine(i).BackColor = Color.Cyan
            Panel_Main.Controls.Add(VectorLine(i))
        Next
    End Sub
    Private Sub DrawRectangle()
        Dim left As Integer = IIf(CX < SX, CX, SX)
        Dim Top As Integer = IIf(CY < SY, CY, SY)
        Dim Right As Integer = IIf(CX > SX, CX, SX)
        Dim Down As Integer = IIf(CY > SY, CY, SY)
        Dim width As Integer = Right - left + 1
        Dim height As Integer = Down - Top + 1
        RecLine(0).Left = left
        RecLine(0).Top = Top
        RecLine(0).Width = 1
        RecLine(0).Height = height
        RecLine(1).Left = Right
        RecLine(1).Top = Top
        RecLine(1).Width = 1
        RecLine(1).Height = height
        RecLine(2).Left = left
        RecLine(2).Top = Top
        RecLine(2).Width = width
        RecLine(2).Height = 1
        RecLine(3).Left = left
        RecLine(3).Top = Down
        RecLine(3).Width = width
        RecLine(3).Height = 1
        If Panel_Main.Controls.GetChildIndex(RecLine(0)) <> 0 Then
            For i = 3 To 0 Step -1
                RecLine(i).BringToFront()
            Next
        End If
        If Not RecLine(0).Visible Then
            For i As Integer = 0 To 3
                RecLine(i).Visible = True
            Next
        End If
        ShowRecStatus()    ' 顯示框線狀態
    End Sub
    ' 隱藏框線
    Public Sub HideRectangle()
        For i As Integer = 0 To 3
            RecLine(i).Visible = False
        Next
    End Sub
    ' 顯示框線
    Private Sub ShowRectangle()
        For i As Integer = 0 To 3
            RecLine(i).Visible = True
            RecLine(i).BringToFront()
        Next
    End Sub
    ' 顯示框線狀態
    Private Sub ShowRecStatus()
        Try
            Dim TPic As PictureBox = Pic_photo  ' GetFrontImage()    '取得 Panel1裡面最上層的PictureBox
            Dim LengthRate As Double = 1 ' GetLengthRatio()
            Dim SizeRatioX As Double = TPic.Image.Width / TPic.Width
            Dim SizeRatioY As Double = TPic.Image.Height / TPic.Height
            Dim width As Double = RecLine(2).Width * SizeRatioX * LengthRate
            Dim Height As Double = RecLine(0).Height * SizeRatioY * LengthRate
            Dim Left As Double = (RecLine(0).Left - TPic.Left) * SizeRatioX * LengthRate
            Dim Top As Double = (RecLine(0).Top - TPic.Top) * SizeRatioY * LengthRate
            _RecBox.X = CInt(Left)
            _RecBox.Y = CInt(Top)
            _RecBox.Width = CInt(width)
            _RecBox.Height = CInt(Height)
            lbl06.Text = "Rec X:" & CInt(Left) & " Y:" & CInt(Top) & _
            " W:" & CInt(width) & " H:" & CInt(Height)
            Dim PixelSize As Double = _PixelSize_um
            Dim Left_um As Double = Math.Round(Left * PixelSize, 0)
            Dim Top_um As Double = Math.Round(Top * PixelSize, 0)
            Dim W_um As Double = Math.Round(width * PixelSize, 0)
            Dim H_um As Double = Math.Round(Height * PixelSize, 0)
            lbl07.Text = "1Pix=" & PixelSize & "um; X:" & Left_um & " Y:" & Top_um & _
           " W:" & W_um & " H:" & H_um
        Catch ex As Exception
        End Try
    End Sub

    ' 提供外界顯示方塊
    Public Sub ShowRectangle(ByVal rec As Rectangle)
        Dim TPic As PictureBox = Pic_photo
        Dim SizeRatioX As Double = TPic.Image.Width / TPic.Width
        Dim SizeRatioY As Double = TPic.Image.Height / TPic.Height

        Dim Left As Integer = rec.Left / SizeRatioX
        Dim Top As Integer = rec.Top / SizeRatioY
        Dim Width As Integer = rec.Width / SizeRatioX
        Dim Height As Integer = rec.Height / SizeRatioY

        Dim Down As Integer = Top + Height
        Dim Right As Integer = Left + Width

        _RecBox.X = rec.Left
        _RecBox.Y = rec.Top
        _RecBox.Width = rec.Width
        _RecBox.Height = rec.Height

        RecLine(0).Left = Left
        RecLine(0).Top = Top
        RecLine(0).Width = 1
        RecLine(0).Height = Height
        RecLine(1).Left = Right
        RecLine(1).Top = Top
        RecLine(1).Width = 1
        RecLine(1).Height = Height
        RecLine(2).Left = Left
        RecLine(2).Top = Top
        RecLine(2).Width = Width
        RecLine(2).Height = 1
        RecLine(3).Left = Left
        RecLine(3).Top = Down
        RecLine(3).Width = Width
        RecLine(3).Height = 1

        ShowRectangle()

    End Sub


    ' 取得方蒯範圍內所有顏色的分布
    Private Function GetRecColorRange() As List(Of Byte())
        Dim R() As Byte = {255, 0}
        Dim G() As Byte = {255, 0}
        Dim B() As Byte = {255, 0}
        Dim Gray() As Byte = {255, 0}
        Dim rtn As New List(Of Byte())
        Dim TPic As PictureBox = Pic_photo  ' GetFrontImage()    '取得 Panel1裡面最上層的PictureBox
        Dim LengthRate As Double = 1 ' GetLengthRatio()
        Dim SizeRatioX As Double = TPic.Image.Width / TPic.Width
        Dim SizeRatioY As Double = TPic.Image.Height / TPic.Height
        Dim width As Double = RecLine(2).Width * SizeRatioX * LengthRate
        Dim Height As Double = RecLine(0).Height * SizeRatioY * LengthRate
        Dim Left As Double = (RecLine(0).Left - TPic.Left) * SizeRatioX * LengthRate
        Dim Top As Double = (RecLine(0).Top - TPic.Top) * SizeRatioY * LengthRate
        Dim Right As Double = Left + width - 1
        Dim Down As Double = Top + Height - 1
        Dim newbmp As Bitmap = TPic.Image
        With newbmp
            For X As Integer = Left To Right
                For Y As Integer = Top To Down
                    Dim CL As Color = .GetPixel(X, Y)
                    Dim tR As Double = CL.R
                    Dim tG As Double = CL.G
                    Dim tB As Double = CL.B
                    Dim tGray As Double = 0.299 * tR + 0.587 * tG + 0.114 * tB
                    If tR < R(0) Then R(0) = tR
                    If tR > R(1) Then R(1) = tR
                    If tG < G(0) Then G(0) = tG
                    If tG > G(1) Then G(1) = tG
                    If tB < B(0) Then B(0) = tB
                    If tB > B(1) Then B(1) = tB
                    If tGray < Gray(0) Then Gray(0) = tGray
                    If tGray > Gray(1) Then Gray(1) = tGray
                Next
            Next
        End With
        rtn.Add(R)
        rtn.Add(G)
        rtn.Add(B)
        rtn.Add(Gray)
        Return rtn
    End Function

    Private Function CalImageSizeInContainer(ByVal ContanerSize As Size, ByVal TImg As Bitmap) As Size
        Dim MaxW As Integer = ContanerSize.Width
        Dim MaxH As Integer = ContanerSize.Height
        Dim ImgSizeRate As Single = TImg.Width / TImg.Height
        Dim CntrSizeRate As Single = ContanerSize.Width / ContanerSize.Height
        Dim NewSizeW As Integer
        Dim NewSizeH As Integer
        If ImgSizeRate > CntrSizeRate Then
            NewSizeW = MaxW
            NewSizeH = NewSizeW / ImgSizeRate
        Else
            NewSizeH = MaxH
            NewSizeW = NewSizeH * ImgSizeRate
        End If
        Return New Size(NewSizeW, NewSizeH)
    End Function
    ' 重整中心線位置
    Private Sub CenterLinePosChange()
        Dim TPic As PictureBox = Pic_photo  ' GetFrontImage()  '取得 Panel1裡面最上層的PictureBox
        ' 水平
        CenterLine(0).Width = TPic.Width
        CenterLine(0).Height = 1
        CenterLine(0).Left = TPic.Left
        CenterLine(0).Top = TPic.Top + TPic.Height / 2
        ' 垂直
        CenterLine(1).Width = 1
        CenterLine(1).Height = TPic.Height
        CenterLine(1).Left = TPic.Left + TPic.Width / 2
        CenterLine(1).Top = TPic.Top
    End Sub
    ' 切換中心線是否顯示
    Private Sub CenterLineShowHideSwitch()
        CenterLine(0).Visible = Not CenterLine(0).Visible
        CenterLine(1).Visible = CenterLine(0).Visible
        If CenterLine(0).Visible Then
            CenterLinePosChange()
            CenterLine(0).BringToFront()
            CenterLine(1).BringToFront()
        End If
    End Sub
    ' 重整游標線位置
    Private Sub CusorLinePosChange(ByVal CX As Integer, ByVal CY As Integer)
        Dim Offset As Integer = 2
        Try
            CusorLine(0).Left = Pic_photo.Left
            CusorLine(0).Top = CY
            CusorLine(0).Width = CX - Offset - Pic_photo.Left
            CusorLine(0).Height = 1

            CusorLine(2).Left = CX + Offset
            CusorLine(2).Top = CusorLine(0).Top
            CusorLine(2).Width = Pic_photo.Width - CusorLine(2).Left
            CusorLine(2).Height = 1

            CusorLine(1).Top = Pic_photo.Top
            CusorLine(1).Left = CX
            CusorLine(1).Width = 1
            CusorLine(1).Height = CY - Offset - Pic_photo.Top

            CusorLine(3).Top = CY + Offset
            CusorLine(3).Left = CusorLine(1).Left
            CusorLine(3).Width = 1
            CusorLine(3).Height = Pic_photo.Height - CusorLine(3).Top

            ShowCusorStatus()
            If CusorLine(0).Visible Then Panel_Main.Refresh()
        Catch ex As Exception
            Application.DoEvents()
        End Try

    End Sub
    ' 顯示游標狀態
    Private Sub ShowCusorStatus()
        Try
            Dim TPic As PictureBox = Pic_photo  ' GetFrontImage()    '取得 Panel1裡面最上層的PictureBox
            Dim LengthRate As Double = 1 ' GetLengthRatio()
            Dim SizeRatioX As Double = TPic.Image.Width / TPic.Width
            Dim SizeRatioY As Double = TPic.Image.Height / TPic.Height
            Dim X As Integer = CInt((CusorLine(1).Left - TPic.Left) * SizeRatioX * LengthRate)
            Dim Y As Integer = CInt((CusorLine(0).Top - TPic.Top) * SizeRatioY * LengthRate)
            ExternalX = X
            ExternalY = Y
            Dim newbmp As Bitmap = TPic.Image
            With newbmp
                Dim CL As Color = .GetPixel(X, Y)
                Dim R As Double = CL.R
                Dim G As Double = CL.G
                Dim B As Double = CL.B
                Dim Gray As Double = 0.299 * R + 0.587 * G + 0.114 * B
                lbl05.Text = "X:" & X & " Y:" & Y & "; " & _
                  "R:" & R & " G:" & G & " B:" & B & " Gray:" & Gray
            End With
        Catch ex As Exception
        End Try
    End Sub

    ' 切換游標線是否顯示
    Private Sub CusorLineShowHideSwitch(ByVal Show As Boolean)

        For i = 0 To 3
            CusorLine(i).Visible = Show
        Next
        If Show Then
            If Panel_Main.Controls.GetChildIndex(CusorLine(0)) <> 0 Then
                For i = 0 To 3
                    CusorLine(i).BringToFront()
                Next
            End If
        End If
    End Sub
    ' 隱藏游標線
    Private Sub HideCusorLine()
        For i = 0 To 3
            CusorLine(i).Visible = False
        Next
    End Sub
    ' 顯示游標線
    Private Sub ShowCusorLine()
        If Panel_Main.Controls.GetChildIndex(CusorLine(0)) <> 0 Then
            For i = 0 To 3
                CusorLine(i).BringToFront()
            Next
        End If
        For i = 0 To 3
            If CusorLine(i).Visible = False Then CusorLine(i).Visible = True
        Next

    End Sub

#End Region
    ' Load image
    Private Sub ToolStripMenuItem6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem6.Click, Btn_LoadImage.Click
        Dim CFileName As String = MyOpenFileDialog("bmp")
        Try
            If CFileName = "" Then Exit Sub
            If Not My.Computer.FileSystem.FileExists(CFileName) Then Throw New Exception("Image File does't exist")
            UpLoadImage(CFileName)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    ' 游標線 顯示/隱藏
    Private Sub ToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem2.Click, Btn_CuserLine.Click
        _ShowCusorLine = Not _ShowCusorLine
        CusorLineShowHideSwitch(_ShowCusorLine)
    End Sub
    ' 中心線 顯示/隱藏
    Private Sub ToolStripMenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem5.Click, Btc_CenterLine.Click
        CenterLineShowHideSwitch()
    End Sub
    ' Auto
    Private Sub ToolStripMenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem3.Click, Btn_RealSize.Click
        _ImageListType = 0
        RefreshImageList()
    End Sub
    ' Fit to window ( 保持長寬比 )
    Private Sub ToolStripMenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem4.Click, Btn_FitSize.Click
        _ImageListType = 1
        RefreshImageList()
    End Sub
    ' Fill ( 不保持長寬比 )
    Private Sub ToolStripMenuItem8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem8.Click, Btn_ImageFill.Click
        _ImageListType = 2
        RefreshImageList()
    End Sub
    '  激發事件,將滑鼠座標傳出去
    Private Sub ToolStripMenuItem9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem9.Click
        RaiseMouseUpEvent(ExternalX, ExternalY)
    End Sub
    ' 重整影像顯示
    Private Sub RefreshImageList()
        Panel_Main.AutoScroll = False
        With Pic_photo
            Select Case _ImageListType
                Case 0 ' 
                    Panel_Main.AutoScroll = True
                    .SizeMode = PictureBoxSizeMode.AutoSize
                Case 1  ' Fit to window
                    .SizeMode = PictureBoxSizeMode.Zoom
                    .Left = 0
                    .Top = 0
                    .Size = CalImageSizeInContainer(Panel_Main.Size, .Image)
                Case 2
                    .SizeMode = PictureBoxSizeMode.StretchImage
                    .Left = 0
                    .Top = 0
                    .Size = Panel_Main.Size
            End Select
        End With
        If lineinstalled Then
            CenterLinePosChange() ' 重整中心線位置
        End If
    End Sub
    ' Save Image
    Private Sub ToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem1.Click, Btn_ImageSaveAs.Click
        Dim fileName As String = MySaveFileDialog("bmp")
        If fileName = "" Then Exit Sub
        Try
            Dim TPic As PictureBox = Pic_photo '  GetFrontImage()    '取得 Panel1裡面最上層的PictureBox
            TPic.Image.Save(fileName)
            lbl04.Text = fileName
            MsgBox("File Save succeed in [" & fileName & "]")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    ' 取得指定區塊圖片
    Private Sub GrabSelectAreaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GrabSelectAreaToolStripMenuItem.Click, Btn_GrabRecImage.Click
        Dim bmp As Bitmap = GetImageParts(Pic_photo.Image, _RecBox)
        Dim newform As New Form_SubImage
        newform.Show()
        newform.UpLoad(bmp)
    End Sub
    ' 取得縮圖
    Private Sub ToolStripMenuItem10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem10.Click, Btn_GetMinifiedImage.Click
        Dim bmp As Bitmap = ImageShrinking(Pic_photo.Image, _RecBox.Width, _RecBox.Height)
        Dim newform As New Form_SubImage
        newform.Show()
        newform.UpLoad(bmp)
    End Sub

    Public Sub ViewImagePosition(ByVal X As Integer, ByVal Y As Integer)
        If Pic_photo.Width <= Panel_Main.Width And Pic_photo.Height <= Panel_Main.Height Then
            Pic_photo.Left = 0
            Pic_photo.Top = 0
            ShowPlusLine(X, Y)
            Exit Sub
        End If
        If Pic_photo.Width > Panel_Main.Width Then
            Dim XC As Integer = Panel_Main.Width / 2
            Dim DX As Integer = CInt(X * CalSizeRatioX())
            Pic_photo.Left = XC - DX
        End If
        If Pic_photo.Height > Panel_Main.Height Then
            Dim YC As Integer = Panel_Main.Height / 2
            Dim DY As Integer = CInt(Y * CalSizeRatioX())
            Pic_photo.Top = YC - DY
        End If
        ShowPlusLine(X, Y)
    End Sub
    ' 在圖片上的 X Y 座標上顯示十字線
    Private Sub ShowPlusLine(ByVal X As Integer, ByVal Y As Integer)
        Dim DX As Integer = CInt(X * CalSizeRatioX())
        Dim DY As Integer = CInt(Y * CalSizeRatioY())
        Dim PosX As Integer = Pic_photo.Left + DX
        Dim PosY As Integer = Pic_photo.Top + DY
        ShowVectorLine(PosX, PosY)
    End Sub
    Private Sub ShowVectorLine(ByVal X As Integer, ByVal Y As Integer)
        Dim Length As Integer = 20
        VectorLine(0).Width = Length
        VectorLine(0).Height = 1
        VectorLine(1).Height = Length
        VectorLine(1).Width = 1
        VectorLine(0).Left = X - Length / 2
        VectorLine(0).Top = Y
        VectorLine(1).Left = X
        VectorLine(1).Top = Y - Length / 2
        VectorLine(0).Visible = True
        VectorLine(1).Visible = True
        VectorLine(0).BringToFront()
        VectorLine(1).BringToFront()
    End Sub
    Private Sub HideVectorLine()
        VectorLine(0).Visible = False
        VectorLine(1).Visible = False
    End Sub
    Private Function CalSizeRatioX() As Single  '原圖比上顯示圖形
        Return Pic_photo.Width / Pic_photo.Image.Width
    End Function
    Private Function CalSizeRatioY() As Single
        Return Pic_photo.Height / Pic_photo.Image.Height
    End Function
    ' Size Up
    Private Sub ToolStripMenuItem7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem7.Click, Btn_SizeUp.Click
        ImageSizeChange(0.1)
    End Sub
    ' Size Down
    Private Sub SizeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SizeToolStripMenuItem.Click, Btn_SizeDown.Click
        ImageSizeChange(-0.1)
    End Sub
    Private Sub ImageSizeChange(ByVal ChangeRate As Single, Optional ByVal HomeIsZero As Boolean = False)
        Dim NewW As Integer = Pic_photo.Width * (1 + ChangeRate)
        Dim NewH As Integer = Pic_photo.Height * (1 + ChangeRate)
        If NewW < 10 Or NewH < 10 Then Exit Sub
        Dim Xc As Integer = Panel_Main.Width / 2
        Dim Yc As Integer = Panel_Main.Height / 2
        Dim DX0 As Integer = Xc - Pic_photo.Left
        Dim DY0 As Integer = Yc - Pic_photo.Top
        Dim DX1 As Integer = DX0 * (1 + ChangeRate)
        Dim DY1 As Integer = DY0 * (1 + ChangeRate)
        Dim NewLeft As Integer = Xc - DX1
        Dim NewTop As Integer = Yc - DY1
        If NewW <= Panel_Main.Width Then NewLeft = 0
        If NewH <= Panel_Main.Height Then NewTop = 0
        If NewLeft > 0 Then NewLeft = 0
        If NewTop > 0 Then NewTop = 0
        Pic_photo.SizeMode = PictureBoxSizeMode.StretchImage
        Pic_photo.Width = NewW
        Pic_photo.Height = NewH
        If NewW > Panel_Main.Width Or NewH > Panel_Main.Height Then
            Panel_Main.AutoScroll = True
        Else
            Panel_Main.AutoScroll = False
        End If
        Pic_photo.Left = NewLeft
        Pic_photo.Top = NewTop
    End Sub
    Public Sub ImageSizeUp()
        ImageSizeChange(0.1)
    End Sub
    Public Sub ImageSizeDown()
        ImageSizeChange(-0.1)
    End Sub
    Private Sub ClearImage()
        Try
            If IsNothing(Pic_photo.Image) Then Exit Sub
            Using Pic_photo.Image
                Pic_photo.Image.Dispose()
                Pic_photo.Image = Nothing
            End Using
        Catch ex As Exception
            MsgBox("Clear image error : " & ex.Message)
        End Try
    End Sub
    ' 取得方塊內的顏色範圍
    Private Sub GetSelectColorRangeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetSelectColorRangeToolStripMenuItem.Click, Btn_CalColorRange.Click
        Dim rtn As List(Of Byte()) = GetRecColorRange()
        Application.DoEvents()
        Dim ShowStr As String = "Range_R = (" & rtn(0)(0) & " , " & rtn(0)(1) & " )" & vbCrLf
        ShowStr &= "Range_G = (" & rtn(1)(0) & " , " & rtn(1)(1) & " )" & vbCrLf
        ShowStr &= "Range_B = (" & rtn(2)(0) & " , " & rtn(2)(1) & " )" & vbCrLf
        ShowStr &= "Range_Gray = (" & rtn(3)(0) & " , " & rtn(3)(1) & " )"
        MsgBox(ShowStr)
    End Sub

#Region "滑鼠事件"

    Private WheelAble As Boolean = False
    Private NeedToRefresh As Boolean = False

    ' 滑鼠下壓事件
    Private Sub PictureBox_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)

        If _LiveEnable Then Exit Sub ' 動畫顯示時不可以執行事件

        _DrawRec = e.Button = Windows.Forms.MouseButtons.Left
        If _DrawRec Then
            SX = e.X + sender.Left
            SY = e.Y + sender.Top
            HideRectangle()
        End If
    End Sub
    ' 滑鼠移動事件
    Private Sub PictureBox_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)

        If _LiveEnable Then Exit Sub ' 動畫顯示時不可以執行事件

        CX = e.X - 0 + sender.Left
        CY = e.Y - 0 + sender.Top
        If _DrawRec Then DrawRectangle()
        CusorLinePosChange(CX, CY)
        If _ShowCusorLine Then
            If Not CusorLine(0).Visible Then ShowCusorLine()
        End If

    End Sub

    ' 滑鼠放開事件
    Private Sub PictureBox_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)

        If _LiveEnable Then Exit Sub ' 動畫顯示時不可以執行事件

        _DrawRec = False
        If e.Button = Windows.Forms.MouseButtons.Left Then
            RaiseMouseUpEvent(e.X, e.Y)
        End If

    End Sub
    ' 滑鼠離開事件--> 游標移到圖形外--> 關閉 游標線, 讓 WheelAble = False
    Private Sub PictureBox_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs)

        If _LiveEnable Then Exit Sub ' 動畫顯示時不可以執行事件

        If _ShowCusorLine Then HideCusorLine()
        WheelAble = False
        'OnImage = False


    End Sub
    ' 滑鼠移到圖片內, 如果MyBas 未得到 Focus, 則進行 Focus, 讓 WheelAble = True
    Private Sub PictureBox_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs)
        If _LiveEnable Then Exit Sub ' 動畫顯示時不可以執行事件

        If Not Me.Focused Then Me.Focus()
        WheelAble = True
    End Sub
    Private Sub Panel_Main_Scroll(ByVal sender As Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles Panel_Main.Scroll
        If e.ScrollOrientation = ScrollOrientation.HorizontalScroll And e.NewValue = 0 Then ' 水平捲到0
            Pic_photo.Left = 0
        End If
        If e.ScrollOrientation = ScrollOrientation.VerticalScroll And e.NewValue = 0 Then ' 水平捲到0
            Pic_photo.Top = 0
        End If
    End Sub
    Private Sub UC_ImgUI_MouseWheel(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseWheel
        If _LiveEnable Then Exit Sub ' 動畫顯示時不可以執行事件

        If Not WheelAble Then Exit Sub
        If e.Delta > 0 Then
            ImageSizeChange(0.05)
        Else
            ImageSizeChange(-0.05)
        End If
    End Sub
    Private Sub Panel_Main_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Panel_Main.SizeChanged
        If Not lineinstalled Then Exit Sub
        NeedToRefresh = True
    End Sub
    Private Sub UC_ImgUI_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        If Not lineinstalled Then Exit Sub
        If NeedToRefresh Then
            NeedToRefresh = False
            RefreshImageList()
        End If
    End Sub

#End Region


#Region "方法 : 影像載入函數"
    Private Delegate Sub UpdateUI(ByVal pic As Bitmap)
    ' 載入圖片副程式
    Public Sub SetImage(ByVal SImage As Bitmap)
        ClearImage()
        UploadImage(SImage)
    End Sub
    ' 多載1 : 載入圖片副程式
    Public Sub UploadImage(ByVal FileName As String)
        Try
            If FileName = "" Then Exit Sub
            If Not My.Computer.FileSystem.FileExists(FileName) Then Throw New Exception("Image File does't exist")
            UploadImage(New Bitmap(FileName), FileName)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    ' 多載2 (本體)  : 載入圖片副程式 20200730 變更: 可載入不同執行續傳過來的影像
    Public Sub UpLoadImage(ByVal Image As Bitmap, Optional ByVal ImgName As String = "")
        If Me.InvokeRequired() Then
            Dim um As New UpdateUI(AddressOf ShowImage)
            Me.Invoke(um, Image)
        Else
            ShowImage(Image, ImgName)
        End If
    End Sub
    ' 影像載入
    Private Sub ShowImage(ByVal SImage As Bitmap, Optional ByVal ImgName As String = "")
        Dim ErrID As Integer
        Try
            'If Not LiveEnable Then ClearImage() ' 清除既有影像
            'ClearImage()
            Dim Pos As New Point(0, 0)
            If IsNothing(SImage) Then
                Throw New Exception("傳入圖檔為NULL")
            ElseIf SImage.Width = 0 Then
                Throw New Exception("圖檔大小為零")
            End If
            ErrID = 2
            Pic_photo.Image = SImage
            'Using SImage
            '    Pic_photo.Image = SImage.Clone ' ImageCopy_IndexFree(SImage)  ' 將圖檔複製一份並解除關連鎖飲
            'End Using
            ErrID = 3
            Panel_Main.SetAutoScrollMargin(Pos.X, Pos.Y)   ' 捲動Scroll
            ErrID = 4
            Pic_photo.Refresh()
            ErrID = 5
            HideVectorLine() ' 隱藏指示座標
            ErrID = 6
            _ImageFileName = ImgName
            ErrorOccure = False
            ErrorString = ""
            Dim TytleStr As String = IIf(ImgName = "", GetTimeString, ImgName)
            lbl04.Text = TytleStr & ", Image Uploaded!"
            lbl04.ForeColor = Color.DarkBlue
        Catch ex As Exception
            ErrorOccure = True
            ErrorString = "Image Upload Error :" & ex.Message
            lbl04.Text = ErrorString
            lbl04.ForeColor = Color.Red
            MsgBox("ImgUI Alarm : " & ErrorString)
        End Try
    End Sub
    Private Function GetTimeString() As String
        Return Now.ToString & "." & Now.Millisecond.ToString("000")
    End Function

#End Region
#Region "方法 : Picture Box 有關公開函數"
    ' 取得Picture Box 內影像
    Public Function GetImage() As Image
        Return Pic_photo.Image
    End Function
    ' 設定Picture Box 在承載容器中的位置
    Public Sub SetImagePos(ByVal left As Integer, ByVal top As Integer)
        If Pic_photo.SizeMode = PictureBoxSizeMode.StretchImage Then
            Exit Sub
        End If
        Pic_photo.Left = left
        Pic_photo.Top = top
    End Sub
    ' 取得Picture Box 的Handle >> 通常拿去顯示動畫
    Public Function GetPictureBoxHandle() As IntPtr
        Return Pic_photo.Handle
    End Function
    Public Function GetPicBoxHandle() As IntPtr
        Return Pic_photo.Handle
    End Function
    ' 清除影像
    Public Sub DisPoseImage()
        ClearImage()
    End Sub
#End Region
#Region "方法 : 從既有影像中取圖之函數"
    ' 影像複製同時去除索引 (新舊像圖無關連性)
    Public Function ImageCopy_IndexFree(ByVal bmp As Bitmap) As Bitmap
        Dim newbmp As New Bitmap(bmp.Width, bmp.Height)
        Dim g As Graphics = Graphics.FromImage(newbmp)
        g.DrawImage(bmp, 0, 0, bmp.Width, bmp.Height)
        Return newbmp
    End Function
    ' 影像縮圖(縮到指定大小) 同時去除引 (新舊像圖無關連性)
    Public Function ImageShrinking(ByVal bmp As Bitmap, ByVal Width As Integer, ByVal Height As Integer) As Bitmap
        Dim newbmp As New Bitmap(Width, Height)
        Dim g As Graphics = Graphics.FromImage(newbmp)
        g.DrawImage(bmp, 0, 0, Width, Height)
        Return newbmp
    End Function
    ' 取得部分影像 同時去除引 (新舊像圖無關連性)
    Public Function GetImageParts(ByVal bmp As Bitmap, ByVal rec As Rectangle) As Bitmap
        Dim newbmp As New Bitmap(rec.Width, rec.Height)
        Dim recnew As New Rectangle(0, 0, newbmp.Width, newbmp.Height)  ' 代表印到新圖的區塊
        Dim g As Graphics = Graphics.FromImage(newbmp)
        'g.DrawImage(bmp, rec0, rec.X, rec.Y, rec.Width, rec.Height, GraphicsUnit.Pixel)
        g.DrawImage(bmp, recnew, rec, GraphicsUnit.Pixel)
        Return newbmp
    End Function

    Public Function GetImageParts() As Bitmap
        Dim bmp As Bitmap = Pic_photo.Image
        Dim rec = _RecBox
        Return GetImageParts(bmp, rec)
    End Function

#End Region


    Private Sub EraseImageToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EraseImageToolStripMenuItem.Click, Btn_ClearImage.Click
        ClearImage()
    End Sub
  

End Class
