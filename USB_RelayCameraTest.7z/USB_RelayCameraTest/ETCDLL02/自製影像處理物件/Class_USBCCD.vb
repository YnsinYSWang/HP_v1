﻿Imports System.Drawing.Imaging
Imports System.Threading
Imports System.Runtime.InteropServices
Imports Emgu.CV
Imports Emgu.CV.Structure
Imports Emgu.CV.CvEnum
Imports System.Drawing
Imports System.Xml


Public Class Class_USBCCD
    Private _cCamera As Capture
    Private _outMatImage As New Mat
    Private _tmpMatImage As New Mat
    Private _tmpOutputImage As Image(Of Gray, Byte)
    Private _CameraID As Integer = 0
    Private _bGrabFlag As Boolean = False ' 是否正在取像
    Private _CCDConnected As Boolean = False
    Private _IsLastGrab As Boolean = False ' 重複取圖中是否為最後一張 (是才要將塗倒入)
    Private _LastGrabImage As Bitmap
    Private _GrabEventUpdate As Boolean = False
    Private _LastGrabTicks As Long
    Private _FlipHorizontal As Boolean = False
    Private _FlipVerticle As Boolean = False
    Private _RepeatTimes As Integer = 3 ' 真正的重複擷取次數
    Private _GrabIsOn As Boolean = False
    Private _GrabIsFinished As Boolean = False
    Private _VideoOnRecord As Boolean = False

    Public Property CCDImageWidth As Integer = 640 '1280
    Public Property CCDImageHeight As Integer = 480 '1024
    Public Property CntProcessName As String = ""  ' 正在處理的程序
    Public Property ErrorOccure As Boolean = False
    Public Property ErrorString As String = ""
    Public Property ProcessIsOn As Boolean = False
    Public Property ProcessIsFinished As Boolean = False
    ' 為了避免取到之前的像圖, 每次取像都取 _RepeatTimes 次
    Public Property DftRepeatTimes As Integer = 3 ' 預設的重複擷取次數
    Public Property FlipHorizontal As Boolean  ' 水平翻轉
        Get
            Return _FlipHorizontal
        End Get
        Set(ByVal value As Boolean)
            _FlipHorizontal = value
            If _CCDConnected Then _cCamera.FlipHorizontal = value
        End Set
    End Property
    Public Property FlipVerticle As Boolean  ' 垂直翻轉
        Get
            Return _FlipVerticle
        End Get
        Set(ByVal value As Boolean)
            _FlipVerticle = value
            If _CCDConnected Then _cCamera.FlipVertical = value
        End Set
    End Property
    Public ReadOnly Property CCDConnected As Boolean
        Get
            Return _CCDConnected
        End Get
    End Property
    Public ReadOnly Property LastGrabImage As Bitmap
        Get
            Return _LastGrabImage
        End Get
    End Property
    Public ReadOnly Property GrabIsOn As Boolean
        Get
            Return _GrabIsOn
        End Get
    End Property
    Public ReadOnly Property GrabIsFinished As Boolean
        Get
            Return _GrabIsFinished
        End Get
    End Property
    Public Property TimeUsed As Double = 0

    Public Event eventError(ByVal iCameraNo As UInteger, ByVal strErrorMsg As String)
    Public Event Event_ImageCatch(ByVal CameraID As Integer, ByVal Image As Bitmap, ByVal UsedTime As Double)

    Public Sub New(ByVal iCameraID As Integer, Optional ByVal FrameWidth As Integer = 640, Optional ByVal FrameHeight As Integer = 480)
        _CameraID = iCameraID
        CCDImageWidth = FrameWidth
        CCDImageHeight = FrameHeight
    End Sub

    ' 重建USB CCD 連線
    Public Function CreateNewCamera() As Boolean
        Try
            Dim StartTicks As Long = Now.Ticks
            setProcessStart("CreateNewCamera")
            CloseCamera()  '  安全關閉相機
            _cCamera = New Capture(_CameraID)
            _cCamera.SetCaptureProperty(CapProp.FrameWidth, _CCDImageWidth)
            _cCamera.SetCaptureProperty(CapProp.FrameHeight, _CCDImageHeight)
            _cCamera.SetCaptureProperty(CapProp.Fps, 30)

            _tmpOutputImage = New Image(Of Gray, Byte)(_CCDImageWidth, _CCDImageHeight, New Gray(0))
            AddHandler _cCamera.ImageGrabbed, AddressOf event_FrameGrabber
            Dim CarName As String = _cCamera.Ptr
            _RepeatTimes = 10 ' 剛剛開始連線 , 重複取像次數設為10 次 , 因為剛開始畫面非常暗
            _CCDConnected = True
            setProcessFinished()
            TimeUsed = Math.Round(1000 * (Now.Ticks - StartTicks) / 10 ^ 7, 2)
            Application.DoEvents()
            Return True
        Catch ex As Exception
            setProcessFinished(ex.Message)
            _CCDConnected = False
            Application.DoEvents()
            Return False
        End Try
    End Function
    '  安全關閉相機
    Private Sub CloseCamera()
        Try
            If IsNothing(_cCamera) Then
                Exit Sub
            End If
            If _cCamera Is Nothing Then
                Exit Sub
            End If
            Try : _cCamera.Stop() : Catch ex As Exception : End Try
            Try : RemoveHandler _cCamera.ImageGrabbed, AddressOf event_FrameGrabber : Catch ex As Exception : End Try
            Try : _cCamera.Dispose() : Catch ex As Exception : End Try
            _cCamera = Nothing
            _CCDConnected = False
        Catch ex As Exception
            MsgBox("Camera Closing Failure : " & ex.Message)
        End Try
    End Sub

    ' 接收事件_CCD 影像取得事件
    Private Sub event_FrameGrabber(ByVal sender As Object, ByVal e As EventArgs)
        Try
            If _bGrabFlag = True Then   ' 前一張像圖還沒取完, 新進像圖必須捨棄 不然會出錯
                Using _tmpMat As New Mat
                    _cCamera.Retrieve(_tmpMat)  ' 更新像圖
                    _tmpMat.Dispose()
                End Using
                Exit Sub
            End If
            _bGrabFlag = True  ' 代表正式取圖 (前一張像圖產生的_bGrabFlag已經清除)
            _cCamera.Retrieve(_outMatImage)  ' 將Camera 影像 倒入 Buffer _outMatImage
            ' 轉換  Buffer _outMatImage 成為影像格式 _tmpOutputImage
            If _IsLastGrab Then  ' 因重複取圖關係, 只有最後一張才要
                CvInvoke.CvtColor(_outMatImage, _tmpOutputImage, ColorConversion.Rgb2Gray)
                _LastGrabImage = _tmpOutputImage.Bitmap
            End If
            _LastGrabTicks = Now.Ticks
            _bGrabFlag = False
            _GrabEventUpdate = True
            Application.DoEvents()
            If _VideoOnRecord Then
                VWriter.Write(_outMatImage)
            End If

            If LiveIsOn Then
                RaiseCCDCatchEvent()
            End If
            ' Dim outputBitmap As Bitmap = _tmpOutputImage.Bitmap
        Catch ex As Exception
            _bGrabFlag = False
            _GrabEventUpdate = True
            ErrorOccure = True
            ErrorString = ex.Message
            ErrorMsgEvent("取像錯誤 : " & ex.ToString)
            ' 取像錯誤
        End Try
    End Sub
    ' 激發事件_錯誤發生事件
    Private Sub ErrorMsgEvent(ByVal strErrorMsg As String)
        Dim strOutErrorMsg As String = strErrorMsg ' String.Format("圖片轉換錯誤，ExceptionMsg:{0}", strErrorMsg)
        RaiseEvent eventError(_CameraID, strOutErrorMsg)
    End Sub


    Private Sub setProcessStart(ByVal ProcessName As String)
        CntProcessName = ProcessName
        ErrorOccure = False
        ErrorString = ""
        ProcessIsOn = True
        ProcessIsFinished = False
    End Sub
    Private Sub setProcessFinished(Optional ByVal Errorstr As String = "")
        ErrorOccure = Errorstr <> ""
        If ErrorOccure Then ErrorString = CntProcessName & " Error : " & Errorstr
        ProcessIsOn = False
        ProcessIsFinished = True
    End Sub

    '  向CCD 下達一次取像指令
    Private Function GrabOne() As Boolean
        Return _cCamera.Grab()
    End Function

    ' CCD 取像指令 重複取向後丟出像圖
    Public Function GrabImage() As Boolean
        Static RetryNo As Integer = 0
        setProcessStart("GrabImage")
        _IsLastGrab = False
        _GrabIsOn = True
        _GrabIsFinished = False

        Dim CatchTicks As Long = Now.Ticks
        Try
            For i = 0 To _RepeatTimes
                Dim InsTick As Long = Now.Ticks
                _IsLastGrab = IIf(i = _RepeatTimes, True, False)
                _GrabEventUpdate = False
                Dim rtn = GrabOne()
                If rtn = False Then
                    Throw New Exception("CCD " & _CameraID & " Grab Error :CCD DisConnected")
                End If
                Do
                    Application.DoEvents()
                    Threading.Thread.Sleep(1)
                    If (Now.Ticks - InsTick) / 10 ^ 7 > 1 Then
                        Throw New Exception("CCD Grab Time Out")
                    End If
                Loop Until _GrabEventUpdate
                If ErrorOccure Then Throw New Exception(ErrorString)
                Application.DoEvents()
                Threading.Thread.Sleep(5)
            Next
            _RepeatTimes = DftRepeatTimes
            ' 計算取圖耗時
            TimeUsed = Math.Round(1000 * (Now.Ticks - CatchTicks) / 10 ^ 7, 2)
            RaiseCCDCatchEvent() '       RaiseEvent Event_ImageCatch(_CameraID, _LastGrabImage, TimeUsed)  ' 觸發事件
            setProcessFinished()
            _GrabIsOn = False
            _GrabIsFinished = True
            Return True
        Catch ex As Exception
            Application.DoEvents()
            ErrorMsgEvent("取像錯誤 : " & ex.Message)
            setProcessFinished(ex.Message)
            Return False
        End Try
    End Function

    Private Sub RaiseCCDCatchEvent()
        RaiseEvent Event_ImageCatch(_CameraID, _LastGrabImage, TimeUsed)  ' 觸發事件
    End Sub


    ' 使用Open CV 旋轉像圖
    Public Function RotateImage(ByRef src_img As Bitmap, ByVal iAngle As Integer) As Bitmap
        Try
            Dim tmpInputImage As Image(Of Gray, Byte) = New Image(Of Gray, Byte)(src_img)
            Dim tmpOutputImage As Image(Of Gray, Byte) = tmpInputImage.Rotate(iAngle, New PointF(tmpInputImage.Width / 2, tmpInputImage.Height / 2), Inter.Area, New Gray(0), False)
            tmpInputImage.Dispose()
            Return tmpOutputImage.Bitmap
        Catch ex As Exception
            ErrorMsgEvent("旋轉像圖錯誤 : " & ex.ToString)
            Return Nothing
        End Try
    End Function


    Public Property LiveIsOn As Boolean = False



    Public Function LiveOn() As Boolean
        '_bImageGrabOneFlag = False
        '_bImageGrabOne = False
        Try
            LiveIsOn = True
            _IsLastGrab = True
            _cCamera.Start()
        Catch ex As Exception
            Return False
        End Try
        Return True
    End Function

    Private VWriter As Emgu.CV.VideoWriter
    Private VCap As Emgu.CV.Capture

    Public Function LiveOff() As Boolean
        Try
            LiveIsOn = False
            _IsLastGrab = False
            _VideoOnRecord = False
            VWriter.Dispose()
            _cCamera.Stop()

        Catch ex As Exception
            Return False
        End Try
        Return True
    End Function

    Public Sub VedioWriter(ByVal AviFile As String, ByVal Fps As Integer, ByVal Width As Integer, ByVal Height As Integer)
        VWriter = New VideoWriter("C:\Temp\V123.avi", 30, New Size(_cCamera.Width, _cCamera.Height), False)
        _VideoOnRecord = True
        LiveOn()
    End Sub

End Class
