﻿' 本類別為影像處理模組, 處理模式:從影像擷取 Pixel 進行演算
' 不必使用 Mil , Holcan or OpenCV 等既有元件
' 開發: AUO 設備技術處 陳俊杰
Imports System.Drawing
Imports System.Windows.Forms
Imports System.Threading
Imports System.Drawing.Drawing2D
Imports ETCDLL02.EtcPublicObject
Public Class Class_ImageDeal

    Private _SourceImage As Bitmap  ' 來源圖檔
    Private _Image As Bitmap ' 已經解除索引的圖檔(可用來繪圖)
    Private _orgSImage As Bitmap
    Private _ImageByte() As Byte
    Private _ImageByteBendWidth As Integer
    Private _ImageFormat As eImageFormat = eImageFormat.Gray
    Private _ShiftCoeff As Integer
    Private _ShiftRate As Integer
    Private _PixelSize_um As Integer = 1
    Private ImgWriter As New Class_ImageWrite



#Region "定義屬性"

    Public ReadOnly Property ImageByte() As Byte()
        Get
            Return _ImageByte
        End Get
    End Property
    Public ReadOnly Property Image() As Bitmap
        Get
            Return _Image
        End Get
    End Property

    Public ReadOnly Property ImageWidth() As Integer
        Get
            Return _Image.Width
        End Get
    End Property
    Public ReadOnly Property ImageByteBendWidth() As Integer
        Get
            Return _ImageByteBendWidth
        End Get
    End Property
    Public ReadOnly Property SourceImage() As Bitmap
        Get
            Return _SourceImage
        End Get
    End Property
 
    Public ReadOnly Property ImageFormat() As eImageFormat
        Get
            Return _ImageFormat
        End Get
    End Property
#End Region
#Region "定義類別"
    ' 垂直線類別
    Public Class Class_VLine
        Public X As Integer
        Public UB As Integer
        Public DB As Integer
        Public YC As Double
        Public Length_Pixel As Integer
        Public Length_um As Integer
        Public Sub New(ByVal Xpos As Integer, ByVal Y1 As Integer, ByVal Y2 As Integer)
            X = Xpos
            UB = Y1
            DB = Y2
            YC = (UB + DB) / 2
            Length_Pixel = DB - UB + 1
            'Length_um = Length_Pixel * _PixelSize_um
        End Sub
    End Class
    ' 水平線類別
    Public Class Class_HLine
        Public Y As Integer
        Public LB As Integer
        Public RB As Integer
        Public XC As Double
        Public Length_Pixel As Integer
        Public Length_um As Integer
        Public Sub New(ByVal Ypos As Integer, ByVal X1 As Integer, ByVal X2 As Integer)
            Y = Ypos
            LB = X1
            RB = X2
            XC = (LB + RB) / 2
            Length_Pixel = RB - LB + 1
            'Length_um = Length_Pixel * _PixelSize_um
        End Sub
    End Class
    ' 山脈分析法之Class 1  : cls_mountain
    Public Class cls_mountain
        Public Index As Integer
        Public left As Integer  ' 左山腳
        Public right As Integer ' 右山腳
        Public peak As Integer  ' 山峰
        Public width As Integer ' 山脈寬度
        Public height As Integer ' 山脈高度
        Public eachbar As List(Of cls_ColorBar) ' 每一個位置的海拔
        Public volumn As Integer ' 整座山的體積
        Public volumnRate As Single ' 整座山的體積佔總陸地百分比
        Public PeakPosShiftRate As Single '0~1  0: 表示在最左端 1 表示在最右端 ,0.5 在正中央, 越靠左端比例越小
        Public LeftPercent As Single
        Public RightPercent As Single
        Public Sub New()
            eachbar = New List(Of cls_ColorBar)
        End Sub
        Public Sub calculatecoef()
            If eachbar.Count = 0 Then Exit Sub
            width = right - left + 1
            Dim rslt = From item In eachbar Order By item.Count Descending ' 依高度排序
            peak = rslt(0).POS
            height = rslt(0).Count
            volumn = 0
            For Each item In eachbar
                volumn += item.Count
            Next
            If width = 1 Then
                PeakPosShiftRate = 0.5
            Else
                PeakPosShiftRate = (peak - left) / (right - left)
            End If
            LeftPercent = eachbar(0).Percent
            RightPercent = eachbar(eachbar.Count - 1).Percent
        End Sub
    End Class
    '  山脈分析法之Class 2 : cls_ColorBar
    Public Class cls_ColorBar
        Public POS As Integer  ' 該顏色值 0~255
        Public Count As Integer ' 該顏色值數量
        Public PreCount As Integer ' 前一顏色值數量
        Public NxtCount As Integer ' 下一顏色值數量
        Public SlopType As String
        Public Percent As Single
        ' 計算斜率狀態 -1-1:下降中 , +1+1 上升中, -1+1 下始點, +1-1 上始點
        ' -10 下降到平地, +10 上升到平地 , 0-1 平地到下坡, 0+1 平地到上坡 , 00平地
        Public Sub calculatesloptype()
            Dim minSlop As Integer = 5
            Dim PreDist As Integer = Count - PreCount
            Dim NxtDist As Integer = Count - NxtCount
            Dim PreTxt As String = "0"
            If PreDist >= minSlop Then PreTxt = "+1"
            If PreDist <= -minSlop Then PreTxt = "-1"
            Dim NxtTxt As String = "0"
            If NxtDist >= minSlop Then NxtTxt = "-1"
            If NxtDist <= -minSlop Then NxtTxt = "+1"
            SlopType = PreTxt & NxtTxt
        End Sub
    End Class
    ' 顏色分布 (不使用山脈分析)
    Public Class class_ColorDistribute
        Public ColorRange As Integer ' 顏色範圍 最白-最黑  越大越好
        Public BlacLevel As Integer ' 黑色Level
        Public WhiteLevel As Integer ' 白色Level
        Public BlacCount As Integer ' 黑色總數
        Public WhiteCount As Integer ' 白色總數
        Public GrayCount As Integer ' 灰色總數 ' 越少越好
        Public WhiteRate As Double ' 白色百分比
        Public BlackRate As Double ' 黑色百分比
        Public GrayRate As Double ' 黑色百分比
    End Class

#End Region
#Region "定義結構"
    Public Structure str_Colordistribution   ' 使用山脈分析得出的結構
        Public V0_Max As Integer ' 最大灰階(最白)
        Public V1_Up As Integer  ' 保證白色區域
        Public V2_bwlevel As Integer ' 黑白分界
        Public V3_down As Integer  ' 保證黑色區域
        Public V4_min As Integer ' 最黑
        Public 中位數
    End Structure
#End Region
#Region "定義列舉"
    Public Enum eSearchColor
        Black = 0
        White
    End Enum
    Public Enum eRgbColorType
        B = 0
        G
        R
        Gray
        A
    End Enum
    Public Enum eImageFormat
        Gray = 0
        RGB
        ARGB
        UnKnown
    End Enum
#End Region
#Region "建構函數"
    Public Sub New(ByVal TImage As Bitmap)
        _ImageByte = TransferImageToByte(TImage, _ImageByteBendWidth)  ' 將圖檔轉化成 Byte 陣列
        _Image = RemoveImagePixelIndex(TImage)   ' Bitmap圖檔轉成可編輯圖檔(除去像素索引)
        _SourceImage = TImage
    End Sub

    Public Sub New()

    End Sub

    Public Function UploadImage(ByVal TImage As Bitmap) As cls_ReturnValue
        Dim rtn As New cls_ReturnValue
        Try
            CleanResource()   ' 清除資料並釋放記憶體
            _ImageByte = TransferImageToByte(TImage, _ImageByteBendWidth)  ' 將圖檔轉化成 Byte 陣列
            _Image = RemoveImagePixelIndex(TImage)   ' Bitmap圖檔轉成可編輯圖檔(除去像素索引)
            '_SourceImage = RemoveImagePixelIndex(TImage)
            _SourceImage = New Bitmap(TImage)
            rtn.SetFinish()
            Return rtn
        Catch ex As Exception
            rtn.SetFinish("UploadImage Error : " & ex.Message)
            Return rtn
        End Try
       
    End Function

    ' 清除資料並釋放記憶體
    Private Sub CleanResource()
        On Error Resume Next
        _Image.Dispose()
        _SourceImage.Dispose()
        _ImageByte = Nothing
        _Image = Nothing
        _SourceImage = Nothing
        GC.Collect()
    End Sub


#End Region
#Region "Public 方法"
    ' 將圖檔轉化成 Byte 陣列' Transfer image to byte()
    Public Function TransferImageToByte(ByVal Image As Bitmap, ByRef BendWidth As Integer) As Byte()
        Try
            Dim oRect = New Rectangle(0, 0, Image.Width, Image.Height)
            Dim ImageBitData As System.Drawing.Imaging.BitmapData
            Dim FScan0 As System.IntPtr
            'Lock the bitmap's bits. 
            ImageBitData = Image.LockBits(oRect, Drawing.Imaging.ImageLockMode.ReadWrite, Image.PixelFormat)
            ' Get ScanWidth
            BendWidth = ImageBitData.Stride
            Select Case CInt(BendWidth / Image.Width)
                Case 1 ' Gray
                    _ImageFormat = eImageFormat.Gray
                    _ShiftCoeff = 0
                    _ShiftRate = 1
                Case 3
                    _ImageFormat = eImageFormat.RGB
                    _ShiftCoeff = 1
                    _ShiftRate = 3
                Case 4
                    _ImageFormat = eImageFormat.ARGB
                    _ShiftCoeff = 1
                    _ShiftRate = 4
                Case Else
                    _ImageFormat = eImageFormat.UnKnown
                    _ShiftCoeff = 1
                    _ShiftRate = CInt(BendWidth / Image.Width)
            End Select
            FScan0 = ImageBitData.Scan0
            Dim FBytes = ImageBitData.Stride * ImageBitData.Height
            Dim ImgByte(FBytes - 1) As Byte
            System.Runtime.InteropServices.Marshal.Copy(FScan0, ImgByte, 0, ImgByte.Length)
            ' 從系統記憶體解除鎖定這個 Bitmap
            Image.UnlockBits(ImageBitData)
            Return ImgByte
        Catch ex As Exception
            MsgBox("ImageData Transfer Error : " & ex.Message, MsgBoxStyle.Critical)
            Return Nothing
        End Try
    End Function

    ' 將Byte陣列 轉成 BMP
    Public Shared Function BytesToBmp(ByVal b() As Byte) As Bitmap
        Dim ms As New System.IO.MemoryStream(b)
        Dim bmp As Bitmap = Bitmap.FromStream(ms)
        Return bmp
    End Function

    ' 將BMP 轉成 Byte陣列
    Public Shared Function BmpToBytes(ByVal bmp As Bitmap) As Byte()
        Dim ms As New System.IO.MemoryStream
        bmp.Save(ms, Imaging.ImageFormat.Png)
        Dim b() As Byte = ms.GetBuffer
        bmp.Dispose()
        Return b
    End Function

    ' Bitmap圖檔轉成可編輯圖檔(除去像素索引)
    Public Shared Function RemoveImagePixelIndex(ByVal bmp As Bitmap) As Bitmap
        Dim newbmp As New Bitmap(bmp.Width, bmp.Height)
        Dim g As Graphics = Graphics.FromImage(newbmp)
        g.DrawImage(bmp, 0, 0, bmp.Width, bmp.Height)
        Return newbmp
    End Function
    ' 將圖片存檔, 如果目錄不存在, 則建立目錄, 如果檔案已存在, 則在檔名後加上編號存檔
    Public Sub SaveImageFile(ByVal FileName As String, ByVal bmp As Bitmap)
        Dim folder As String = ""
        Dim name As String = ""
        Dim subname As String = ""
        Dim LastFileName As String = ""
        Try
            If CheckFoledeAndFileName(FileName, folder, name, subname) = False Then Throw New Exception(" Failure , illigal filaneme") ' 檢查檔名路徑是否合法,如果合法則確保路徑建立
            ' 確保檔案不重複
            If Not My.Computer.FileSystem.FileExists(FileName) Then
                LastFileName = FileName
            Else
                Dim apid As Integer = 0
                Do
                    apid += 1
                    Dim appstr As String = apid.ToString("000")
                    LastFileName = folder & "\" & name & "_" & appstr & "." & subname
                    If Not My.Computer.FileSystem.FileExists(LastFileName) Then Exit Do
                Loop
            End If
            bmp.Save(LastFileName, System.Drawing.Imaging.ImageFormat.Jpeg)
            MsgBox("Image File save path =" & LastFileName)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    ' 建立目錄(從最外層建立到最裡層)
    Public Shared Sub CreateFolder(ByVal Folder As String)
        Dim FolderPart() As String = Folder.Split("\")
        Dim tFolder As String = ""
        For i As Integer = 0 To FolderPart.Count - 1
            If FolderPart(i).Trim <> "" Then
                Dim headchr As String = IIf(i <> 0, "\", "")
                tFolder &= headchr & FolderPart(i)
                If Not My.Computer.FileSystem.DirectoryExists(tFolder) Then My.Computer.FileSystem.CreateDirectory(tFolder)
            End If
        Next
    End Sub
    ' 檢查檔名路徑是否合法,如果合法則確保路徑建立
    Public Shared Function CheckFoledeAndFileName(ByVal FileName As String, ByRef folder As String, ByRef name As String, ByRef subname As String) As Boolean
        Try
            Dim Index1 As Integer = FileName.LastIndexOf("\")
            Dim Index0 As Integer = FileName.IndexOf(":")
            Dim Index3 As Integer = FileName.LastIndexOf(".")
            If Index1 < 0 Then ' C:ABS.txt or C:ABC 格式
                If Index3 < 0 Then ' 只有目錄 C:ABC
                    folder = FileName
                    name = ""
                    subname = ""
                    CreateFolder(folder)
                    Return True
                Else  ' C:ABS.txt格式
                    folder = FileName.Substring(0, Index0 + 1)
                    name = FileName.Substring(Index0 + 1, Index3 - Index0 - 1)
                    subname = FileName.Substring(Index3 + 1, FileName.Length - (Index3 + 1))
                    CreateFolder(folder)
                    Return True
                End If
            End If
            ' Index1 > 0
            Dim tmpNmae As String = FileName.Substring(Index1 + 1, FileName.Length - (Index1 + 1))
            If tmpNmae.Contains(".") Then ' 最後一部分為名字
                Dim tmpid As Integer = tmpNmae.LastIndexOf(".")
                folder = FileName.Substring(0, Index1 + 1)
                name = tmpNmae.Substring(0, tmpid)
                subname = tmpNmae.Substring(tmpid + 1, tmpNmae.Length - tmpid - 1)
                CreateFolder(folder)
                Return True
            Else  ' 全為路徑
                Dim tmpstr3 As String = FileName.Trim
                If tmpstr3.Substring(tmpstr3.Length - 1) = "\" Then tmpstr3 = tmpstr3.Substring(0, tmpstr3.Length - 1)
                folder = tmpstr3
                name = ""
                subname = ""
                CreateFolder(folder)
                Return True
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function


    ' 使用山脈分析法取得色階分布 Shared 共享函數   2020/07/31 Modify By Jethro
    '  Filter 決定是否要慮除所有顏色中最高與最低各百分之十的色階
    Public Shared Function GetColorDistribution(ByVal OrgColors() As Byte, Optional ByVal Filter As Boolean = True) As str_Colordistribution
        Dim rtn As New str_Colordistribution
        Dim FilterRate As Double = IIf(Filter, 0.01, 0)
        Dim Shift As Integer = OrgColors.Count * FilterRate
        Array.Sort(OrgColors)
        Dim Length As Integer = OrgColors.Length - Shift * 2
        Dim Colors(Length - 1) As Byte
        Array.Copy(OrgColors, Shift, Colors, 0, Length)
        Dim DefWhite As Byte = Colors.Max
        Dim DefBlack As Byte = Colors.Min
        Dim MidValue As Integer = DefWhite / 2 + DefBlack / 2  ' 中位數
        Dim ColorBar = GetAllColorBar(Colors)
        Dim Mountain = CalculateMountain(ColorBar)
        If Mountain.Count = 0 Then
            rtn.V0_Max = DefWhite
            rtn.V4_min = DefBlack
            rtn.V2_bwlevel = MidValue
            rtn.V1_Up = (DefWhite + MidValue) / 2
            rtn.V3_down = (DefBlack + MidValue) / 2
            Return rtn
        End If
        If Mountain.Count = 1 Then
            rtn.V0_Max = Mountain(0).right
            rtn.V4_min = Mountain(0).left
            rtn.V2_bwlevel = Mountain(0).peak
            rtn.V1_Up = (Mountain(0).right + rtn.V2_bwlevel) / 2
            rtn.V3_down = (Mountain(0).left + rtn.V2_bwlevel) / 2
            rtn.中位數 = rtn.V2_bwlevel
            Return rtn
        End If
        If Mountain.Count = 2 Then
            rtn.V4_min = Mountain(0).peak
            rtn.V0_Max = Mountain(1).peak
            rtn.V2_bwlevel = (Mountain(0).right + Mountain(1).left) / 2
            rtn.V1_Up = Mountain(1).left
            rtn.V3_down = Mountain(0).right
            rtn.中位數 = rtn.V2_bwlevel
            Return rtn
        End If
        ' 至少三座高峰
        Dim IDMin As Integer = 0
        Dim IDMax As Integer = Mountain.Count - 1
        rtn.V4_min = Mountain(IDMin).peak
        rtn.V0_Max = Mountain(IDMax).peak
        rtn.V2_bwlevel = (Mountain(IDMin).right + Mountain(IDMax).left) / 2
        rtn.V1_Up = Mountain(IDMax).left
        rtn.V3_down = Mountain(IDMin).right
        rtn.中位數 = rtn.V2_bwlevel
        Return rtn
    End Function


    ' 取得色階分布 Shared 共享函數   2020/07/31 Modify By Jethro
    '  Filter 決定是否要慮除所有顏色中最高與最低各百分之十的色階
    Public Shared Function GetColorDistribution_II(ByVal Colors() As Byte, Optional ByVal Filter As Boolean = True) As str_Colordistribution
        Dim rtn As New str_Colordistribution
        Dim ColorBar = GetAllColorBar(Colors)
        Dim FilterRate As Double = IIf(Filter, 0.01, 0)
        Dim MidValue As Byte = 0 ' 中位數
        Dim SumVal As Double = 0
        For i = 0 To ColorBar.Count - 1
            SumVal += ColorBar(i).Count
            If SumVal >= Colors.Count / 2 Then ' 找到中位數
                MidValue = i
                Exit For
            End If
        Next
        Dim COLDIST As class_ColorDistribute = GetColorDistribute(Colors, 0.1, Filter)
        Dim NewRtn As New str_Colordistribution
        With NewRtn
            .V2_bwlevel = MidValue
            .中位數 = MidValue
            .V4_min = COLDIST.BlacLevel
            .V0_Max = COLDIST.WhiteLevel
            ' 黑白轉換值必須介於最大與最小之間 2019/05/25 Modify By Jethro 新增
            If .V2_bwlevel >= COLDIST.WhiteLevel Or
                 .V2_bwlevel <= COLDIST.BlacLevel Then
                .V2_bwlevel = 0.5 * (COLDIST.WhiteLevel + COLDIST.BlacLevel)
            End If
            .V1_Up = (NewRtn.V0_Max + NewRtn.V2_bwlevel) / 2
            .V3_down = (NewRtn.V4_min + NewRtn.V2_bwlevel) / 2
        End With
        Return NewRtn
    End Function


    ' 簡單分析法取得顏色分布(不使用山脈分析),BWRate代表顏色範圍多少百分比定義黑白
    '  Filter 決定是否要慮除所有顏色中最高與最低各百分之十的色階
    Public Shared Function GetColorDistribute(ByVal Colors() As Byte, Optional ByVal BWRate As Double = 0.1, Optional ByVal Filter As Boolean = True) As class_ColorDistribute
        Dim rtn As New class_ColorDistribute
        If IsNothing(Colors) Then Throw New Exception("GetColorDistribut Error : Input Bytes() is Empty :")
        If Colors Is Nothing Then Throw New Exception("GetColorDistribut Error : Input Bytes() is Empty :")
        Array.Sort(Colors) ' = From item In Colors Order By item
        Dim filterrate As Double = IIf(Filter, 0.1, 0)
        Dim Shift As Integer = Colors.Count * filterrate
        With rtn
            Dim CMax As Byte = Colors(Colors.Count - 1 - Shift) ' Colors.Max
            Dim CMin As Byte = Colors(Shift)  ' Colors.Min
            .ColorRange = CMax - CMin
            .BlacLevel = CMin + .ColorRange * BWRate
            .WhiteLevel = CMax - .ColorRange * BWRate
            .BlacCount = 0
            .WhiteCount = 0
            .GrayCount = 0
            For Each itm In Colors
                If itm >= .WhiteLevel Then
                    .WhiteCount += 1
                ElseIf itm <= .BlacLevel Then
                    .BlacCount += 1
                Else
                    .GrayCount += 1
                End If
            Next
            .WhiteRate = Math.Round(.WhiteCount / Colors.Count, 5)
            .BlackRate = Math.Round(.BlacCount / Colors.Count, 5)
            .GrayRate = Math.Round(.GrayCount / Colors.Count, 5)
        End With
        Return rtn
    End Function

    ' 多型:取得影像模糊度,越大表示越模糊, 越小表示越清晰
    Public Function GetImageFuzzyRange(Optional ByVal Rec As Rectangle = Nothing) As class_ColorDistribute
        If IsNothing(Rec) Then '使用預設區域()
            Dim BondOffset As Integer = 10
            Rec = New Rectangle(BondOffset, BondOffset, _Image.Width - BondOffset * 2, _Image.Height - BondOffset * 2)
        End If
        Dim GraveValue As New List(Of Byte)
        Dim SkipX As Integer = Math.Round(Rec.Width / 200, 0)
        Dim SkipY As Integer = Math.Round(Rec.Height / 200, 0)
        If SkipX < 1 Then SkipX = 1
        If SkipY < 1 Then SkipY = 1
        For Y As Integer = Rec.Top To Rec.Bottom Step SkipY
            For X As Integer = Rec.Left To Rec.Right Step SkipX
                GraveValue.Add(GetPixel(X, Y, eRgbColorType.Gray))
            Next
        Next
        Dim ColorDisturbute As class_ColorDistribute = GetColorDistribute(GraveValue.ToArray, 0.1)
        Return ColorDisturbute
    End Function
    ' 多型(共享函數):取得影像模糊度,越大表示越模糊, 越小表示越清晰
    Public Shared Function GetImageFuzzyRange(ByVal TImage As Bitmap, Optional ByVal Rec As Rectangle = Nothing) As class_ColorDistribute
        Dim ImgHdl As New Class_ImageDeal(TImage)
        If IsNothing(Rec) Then '使用預設區域()
            Dim BondOffset As Integer = 10
            Rec = New Rectangle(BondOffset, BondOffset, TImage.Width - BondOffset * 2, TImage.Height - BondOffset * 2)
        End If
        Dim GraveValue As New List(Of Byte)
        Dim SkipX As Integer = Math.Round(Rec.Width / 200, 0)
        Dim SkipY As Integer = Math.Round(Rec.Height / 200, 0)
        If SkipX < 1 Then SkipX = 1
        If SkipY < 1 Then SkipY = 1
        For Y As Integer = Rec.Top To Rec.Bottom Step SkipY
            For X As Integer = Rec.Left To Rec.Right Step SkipX
                GraveValue.Add(ImgHdl.GetPixel(X, Y, eRgbColorType.Gray))
            Next
        Next
        Dim ColorDisturbute As class_ColorDistribute = GetColorDistribute(GraveValue.ToArray, 0.1)
        Return ColorDisturbute
    End Function
    '    取得像素顏色 (快速, 因為是從Byte陣列取得, 而非使用 Bitmap.GetPixel )
    Public Function GetPixel(ByVal X As Integer, ByVal Y As Integer) As Color
        Dim TmpX As Integer = X * _ShiftRate
        Select Case _ImageFormat
            Case eImageFormat.Gray
                Dim B As Byte = _ImageByte((Y * _ImageByteBendWidth) + TmpX)
                Return Color.FromArgb(255, B, B, B)
            Case Else
                Dim B As Byte = _ImageByte((Y * _ImageByteBendWidth) + TmpX)
                Dim G As Byte = _ImageByte((Y * _ImageByteBendWidth) + TmpX + 1 * _ShiftCoeff)
                Dim R As Byte = _ImageByte((Y * _ImageByteBendWidth) + TmpX + 2 * _ShiftCoeff)
                Dim A As Byte = 255
                If _ImageFormat = eImageFormat.ARGB Then
                    A = _ImageByte((Y * _ImageByteBendWidth) + TmpX + 3 * _ShiftCoeff)
                End If
                Return Color.FromArgb(255, R, G, B)
        End Select
    End Function
    Public Function GetPixel(ByVal X As Integer, ByVal Y As Integer, ByVal ColorType As eRgbColorType) As Byte
        Dim TmpX As Integer = X * _ShiftRate
        Try
            Select Case _ImageFormat
                Case eImageFormat.Gray
                    Dim Gray As Byte = _ImageByte((Y * _ImageByteBendWidth) + TmpX)
                    Return Gray
                Case Else
                    Select Case ColorType
                        Case eRgbColorType.B
                            Dim B As Byte = _ImageByte((Y * _ImageByteBendWidth) + TmpX)
                            Return B
                        Case eRgbColorType.G
                            Dim G As Byte = _ImageByte((Y * _ImageByteBendWidth) + TmpX + 1 * _ShiftCoeff)
                            Return G
                        Case eRgbColorType.R
                            Dim R As Byte = _ImageByte((Y * _ImageByteBendWidth) + TmpX + 2 * _ShiftCoeff)
                            Return R
                        Case eRgbColorType.A
                            Dim A As Byte = 255
                            If _ImageFormat = eImageFormat.ARGB Then
                                A = _ImageByte((Y * _ImageByteBendWidth) + TmpX + 3 * _ShiftCoeff)
                            End If
                            Return A
                        Case Else ' eRgbColorType.Gray
                            Dim B As Byte = _ImageByte((Y * _ImageByteBendWidth) + TmpX)
                            Dim G As Byte = _ImageByte((Y * _ImageByteBendWidth) + TmpX + 1 * _ShiftCoeff)
                            Dim R As Byte = _ImageByte((Y * _ImageByteBendWidth) + TmpX + 2 * _ShiftCoeff)
                            Dim TmpVal As Double = 0.299 * R + 0.587 * G + 0.114 * B
                            Return CByte(TmpVal)
                    End Select
            End Select
        Catch ex As Exception
            Return 0
        End Try
    End Function
    ' 取得矩陣區塊像素顏色,傳回 2 維Byte 陣列
    Public Function GetGrayValue_2D(ByVal Rec As Rectangle) As Byte(,)
        Dim H = 1
        Dim rtn(Rec.Width - 1, Rec.Height - 1) As Byte
        For i = 0 To Rec.Width - 1
            For j = 0 To Rec.Height - 1
                Dim X = Rec.Left + i
                Dim Y = Rec.Top + j
                rtn(i, j) = GetPixel(X, Y, eRgbColorType.Gray)
            Next
        Next
        Return rtn
    End Function
    ' 取得矩陣區塊像素顏色,傳回 1 維Byte 陣列
    Public Function GetGrayValue_1D(ByVal Rec As Rectangle, Optional ByVal StepX As Integer = 1, Optional ByVal StepY As Integer = 1) As Byte()
        Dim H = 1
        Dim Rtn As New List(Of Byte)
        For i = 0 To Rec.Width - 1 Step StepX
            For j = 0 To Rec.Height - 1 Step StepY
                Dim X = Rec.Left + i
                Dim Y = Rec.Top + j
                Rtn.Add(GetPixel(X, Y, eRgbColorType.Gray))
            Next
        Next
        Return Rtn.ToArray
    End Function
    ' 取得部分影像檔
    Public Function GetImageParts(ByVal Rec As Rectangle) As Bitmap
        Dim destBitmap As New Bitmap(Rec.Width, Rec.Height)
        Dim destrec As New Rectangle(0, 0, destBitmap.Width, destBitmap.Height)
        Graphics.FromImage(destBitmap).DrawImage(_Image, destrec, Rec, GraphicsUnit.Pixel)
        Return destBitmap
    End Function
    ' 搜尋垂直線段, 其長度符合需求
  
    Public Function SearchLine_H_II(ByVal Y As Integer, _
                            ByVal LB As Integer, _
                            ByVal RB As Integer, _
                            ByVal Length_min As Integer, _
                            ByVal Length_max As Integer, _
                            ByVal bendwidth As Integer, _
                            ByVal ColorValue As Integer, _
                            ByVal LineColor As eSearchColor) _
                            As List(Of Class_HLine)
        Dim rtn As New List(Of Class_HLine)
        Dim UB As Integer = Y - 0.5 * bendwidth
        Dim DB As Integer = Y + 0.5 * bendwidth
        Dim SwitchOffset As Integer = 10

        Dim CrPt As New List(Of Integer)
        Dim LineStart As Integer = LB
        Dim LineEnd As Integer = LB

        Dim cntLineColor As Integer = -1 ' - 未知, 0 黑 1 白
        Try

    


        For X = LB To RB
            Dim Color0 As Byte = GetPixel(X, Y, eRgbColorType.Gray)
            Dim Color1 As Byte = GetPixel(X + 3, Y, eRgbColorType.Gray)

            Select Case LineColor
                Case eSearchColor.White ' 找白線
                    If Color1 > Color0 + SwitchOffset Then ' 變白 找到起點
                        cntLineColor = 1
                        LineStart = X + 3
                        LineEnd = LineStart
                        X = LineStart
                    ElseIf Color1 < Color0 - SwitchOffset Then ' 變黑 找到終點
                        cntLineColor = 0
                        LineEnd = X
                        Dim newline = (CreateHLine(Y, LineStart, LineEnd))
                        If newline.Length_Pixel >= Length_min And newline.Length_Pixel <= Length_max Then
                            rtn.Add(newline)
                        End If
                        LineStart = X + 3
                        LineEnd = LineStart
                        X = LineStart
                    Else ' 顏色不變
                        LineEnd = X
                    End If

                    If X = RB And cntLineColor = 1 Then
                        Dim newline = (CreateHLine(Y, LineStart, LineEnd))
                        If newline.Length_Pixel >= Length_min And newline.Length_Pixel <= Length_max Then
                            rtn.Add(newline)
                        End If
                        Exit For
                    End If
                    If X = RB And cntLineColor = 0 Then
                        Exit For
                    End If
                    If X = RB And cntLineColor = -1 Then
                        Dim newline = (CreateHLine(Y, LineStart, LineEnd))
                        If newline.Length_Pixel >= Length_min And newline.Length_Pixel <= Length_max Then
                            Dim Rec As New Rectangle(LineStart, Y, LineEnd - LineStart, 1)
                            Dim GV() As Byte = GetGrayValue_1D(Rec)
                                If GetAverage(GV) > ColorValue Then
                                    rtn.Add(newline)
                                End If
                        End If
                    End If

                Case eSearchColor.Black ' 找黑線

            End Select


        Next
            Return rtn

        Catch ex As Exception
            Application.DoEvents()
        End Try


    End Function


    Private Function GetAverage(ByVal GV() As Byte) As Double
        Dim tt As Long = 0
        For i = 0 To GV.Count - 1
            tt += GV(i)
        Next
        Return tt / GV.Length
    End Function


    Public Function SearchLine_V_II(ByVal X As Integer, _
                        ByVal UB As Integer, _
                        ByVal DB As Integer, _
                        ByVal Length_min As Integer, _
                        ByVal Length_max As Integer, _
                        ByVal bendwidth As Integer, _
                        ByVal ColorValue As Integer, _
                        ByVal LineColor As eSearchColor) _
                        As List(Of Class_VLine)
        Dim rtn As New List(Of Class_VLine)
        Dim SwitchOffset As Integer = 4

        Dim LineStart As Integer = UB
        Dim LineEnd As Integer = UB
        Dim WLine As New List(Of Class_VLine)
        Dim BLine As New List(Of Class_VLine)
        Dim cntLineColor As Integer = -1 ' - 未知, 0 黑 1 白

        For Y = UB To DB
            Dim Color0 As Byte = GetPixel(X, Y, eRgbColorType.Gray)
            Dim Color1 As Byte = GetPixel(X, Y + 2, eRgbColorType.Gray)
            Select Case LineColor
                Case eSearchColor.White ' 找白線
                    If Color1 > Color0 + SwitchOffset Then ' 變白 找到起點
                        cntLineColor = 1
                        LineStart = Y + 3
                        LineEnd = LineStart
                        Y = LineStart
                    ElseIf Color1 < Color0 - SwitchOffset Then ' 變黑 找到終點
                        cntLineColor = 0
                        LineEnd = Y
                        Dim newline = (CreateVLine(X, LineStart, LineEnd))
                        If newline.Length_Pixel >= Length_min And newline.Length_Pixel <= Length_max Then
                            rtn.Add(newline)
                        End If
                        LineStart = Y + 3
                        LineEnd = LineStart
                        Y = LineStart
                    Else ' 顏色不變
                        LineEnd = Y
                    End If
                    If Y = DB And cntLineColor = 1 Then
                        Dim newline = (CreateVLine(X, LineStart, LineEnd))
                        If newline.Length_Pixel >= Length_min And newline.Length_Pixel <= Length_max Then
                            rtn.Add(newline)
                        End If
                        Exit For
                    End If
                    If Y = DB And cntLineColor = 0 Then
                        Exit For
                    End If
                    If Y = DB And cntLineColor = -1 Then
                        Dim newline = (CreateVLine(X, LineStart, LineEnd))
                        If newline.Length_Pixel >= Length_min And newline.Length_Pixel <= Length_max Then
                            Dim Rec As New Rectangle(X, LineStart, 1, LineEnd - LineStart)
                            Dim GV() As Byte = GetGrayValue_1D(Rec)
                            If GetAverage(GV) > ColorValue Then
                                rtn.Add(newline)
                            End If
                        End If
                    End If
                Case eSearchColor.Black ' 找黑線

            End Select
        Next
        Return rtn

    End Function

    Public Function SearchLine_H(ByVal Y As Integer, _
                               ByVal LB As Integer, _
                               ByVal RB As Integer, _
                               ByVal Length_min As Integer, _
                               ByVal Length_max As Integer, _
                               ByVal bendwidth As Integer, _
                               ByVal ColorValue As Integer, _
                               ByVal LineColor As eSearchColor) _
                               As List(Of Class_HLine)

        Dim rtn As New List(Of Class_HLine)
        Dim UB As Integer = Y - 0.5 * bendwidth
        Dim DB As Integer = Y + 0.5 * bendwidth
        If bendwidth <= 2 Then
            UB = Y
            DB = Y + 1
        End If
        Dim LineStart As Integer = -1
        Dim LineEnd As Integer = -1
        For x = LB To RB
            Dim Rec As New Rectangle(x, UB, 1, bendwidth)
            If x > 1700 Then
                Application.DoEvents()
            End If
            Dim GV(,) As Byte = GetGrayValue_2D(Rec)
            Dim CLength As Integer
            If LineColor = eSearchColor.Black Then
                CLength = GetBlackWeight(GV, ColorValue)
            Else
                CLength = GetWhiteWeight(GV, ColorValue)
            End If
            Dim ColorRate As Double = CLength / GV.Length
            If ColorRate >= 0.5 Then ' 找到指定顏色
                If LineStart = -1 Then '指定顏色起點
                    LineStart = x
                    LineEnd = x
                Else  ' 指定顏色持續
                    LineEnd = x
                    If x = RB Then ' 搜尋終結
                        Dim newline = CreateHLine(Y, LineStart, LineEnd)
                        If newline.Length_Pixel >= Length_min And newline.Length_Pixel <= Length_max Then
                            rtn.Add(newline)
                        End If
                    End If
                End If
            Else  ' 找到非指定顏色
                If LineStart <> -1 Then  ' 指定顏色截止區域
                    Dim newline = CreateHLine(Y, LineStart, LineEnd)
                    If newline.Length_Pixel >= Length_min And newline.Length_Pixel <= Length_max Then
                        rtn.Add(newline)
                    End If
                    LineStart = -1
                    LineEnd = -1
                Else ' 非指定顏色持續
                    Continue For
                End If
            End If
        Next
        Return rtn
    End Function

    Public Function SearchLine_V(ByVal X As Integer, _
                               ByVal UB As Integer, _
                               ByVal DB As Integer, _
                               ByVal Length_min As Integer, _
                               ByVal Length_max As Integer, _
                               ByVal bendwidth As Integer, _
                               ByVal ColorValue As Integer, _
                               ByVal LineColor As eSearchColor) _
                               As List(Of Class_VLine)
        Dim rtn As New List(Of Class_VLine)
        Dim LB As Integer = X - 0.5 * bendwidth
        Dim RB As Integer = X + 0.5 * bendwidth
        If bendwidth <= 2 Then
            LB = X
            RB = X + 1
        End If
        Dim LineStart As Integer = -1
        Dim LineEnd As Integer = -1
        Dim StepID As Integer = 0
        Try
            For Y = UB To DB
                StepID = 1
                Dim Rec As New Rectangle(LB, Y, RB - LB + 1, 1)
                Dim GV(,) As Byte = GetGrayValue_2D(Rec)
                Dim CLength As Integer
                If LineColor = eSearchColor.Black Then
                    StepID = 101
                    CLength = GetBlackWeight(GV, ColorValue)
                Else
                    StepID = 102
                    CLength = GetWhiteWeight(GV, ColorValue)
                End If
                StepID = 103
                Dim ColorRate As Double = CLength / GV.Length
                StepID = 2
                If ColorRate >= 0.8 Then ' 找到指定顏色
                    If LineStart = -1 Then '指定顏色起點
                        LineStart = Y
                        LineEnd = Y
                    Else  ' 指定顏色持續
                        LineEnd = Y
                        If Y = DB Then ' 搜尋終結
                            Dim newline = CreateVLine(X, LineStart, LineEnd)
                            If newline.Length_Pixel >= Length_min And newline.Length_Pixel <= Length_max Then
                                rtn.Add(newline)
                            End If
                        End If
                    End If
                Else ' 找到非指定顏色
                    StepID = 3
                    If LineStart <> -1 Then  ' 指定顏色截止區域
                        Dim newline = CreateVLine(X, LineStart, LineEnd)
                        If newline.Length_Pixel >= Length_min And newline.Length_Pixel <= Length_max Then
                            rtn.Add(newline)
                        End If
                        LineStart = -1
                        LineEnd = -1
                    Else '非指定顏色持續
                        Continue For
                    End If
                End If
            Next
            Return rtn
        Catch ex As Exception
            Return rtn
        End Try
    End Function    ' 搜尋垂水平線段, 其長度符合需求

    Public Function GetVLineAvgLevel(ByVal Vline As Class_VLine) As Integer
        Dim rec As New Rectangle(Vline.X, Vline.UB, 1, Vline.DB - Vline.UB)
        Dim GV() As Byte = GetGrayValue_1D(rec)
        Dim lng As Long = 0
        For i = 0 To GV.Length - 1
            lng += GV(i)
        Next
        Return lng / GV.Length
    End Function
    Public Function GetHLineAvgLevel(ByVal Hline As Class_HLine) As Integer
        Dim rec As New Rectangle(Hline.LB, Hline.Y, Hline.RB - Hline.LB, 1)
        Dim GV() As Byte = GetGrayValue_1D(rec)
        Dim lng As Long = 0
        For i = 0 To GV.Length - 1
            lng += GV(i)
        Next
        Return lng / GV.Length
    End Function



    ' 影像複製同時去除引 (新舊像圖無關連性)
    Public Function ImageCopy_IndexFree(ByVal bmp As Bitmap) As Bitmap
        Dim newbmp As New Bitmap(bmp.Width, bmp.Height)
        Dim g As Graphics = Graphics.FromImage(newbmp)
        g.DrawImage(bmp, 0, 0, bmp.Width, bmp.Height)
        Return newbmp
    End Function
    ' 取得影像放大或縮小縮圖(縮放到指定大小) 同時去除引 (新舊像圖無關連性)
    Public Function GetImage_ChangeSize(ByVal bmp As Bitmap, ByVal Width As Integer, ByVal Height As Integer) As Bitmap
        Try
            Dim newbmp As New Bitmap(Width, Height)
            Dim g As Graphics = Graphics.FromImage(newbmp)
            g.DrawImage(bmp, 0, 0, Width, Height)
            Return newbmp
        Catch ex As Exception
            MsgBox("GetImage_ChangeSize Error : " & ex.Message)
            Return Nothing
        End Try
    End Function
    ' 取得影像放大或縮小縮圖(等比例縮放) 同時去除引 (新舊像圖無關連性)  SizeRatio :  0.5, 0.6 , 1.1, 1.5 ....
    Public Function GetImage_ChangeSize(ByVal bmp As Bitmap, ByVal SizeRatio As Single) As Bitmap
        Dim Width As Integer = CInt(bmp.Width * SizeRatio)
        Dim Height As Integer = CInt(bmp.Height * SizeRatio)
        Return GetImage_ChangeSize(bmp, Width, Height)
    End Function
    ' 取得部分影像 同時去除引 (新舊像圖無關連性)
    Public Function GetImageParts(ByVal bmp As Bitmap, ByVal rec As Rectangle) As Bitmap
        Try
            Dim newbmp As New Bitmap(rec.Width, rec.Height)
            Dim recnew As New Rectangle(0, 0, newbmp.Width, newbmp.Height)  ' 代表印到新圖的區塊
            Dim g As Graphics = Graphics.FromImage(newbmp)
            'g.DrawImage(bmp, rec0, rec.X, rec.Y, rec.Width, rec.Height, GraphicsUnit.Pixel)
            g.DrawImage(bmp, recnew, rec, GraphicsUnit.Pixel)
            Return newbmp
        Catch ex As Exception
            MsgBox("GetImageParts Error : " & ex.Message)
            Return Nothing
        End Try
    End Function
#End Region
#Region "簡易繪圖"
    ' 繪製矩形
    Public Sub DrawRec(ByVal Rec As Rectangle, ByRef Sbmp As Image, ByVal DColor As Color, Optional ByVal LineWidth As Integer = 1)
        Dim Graphic As Graphics = Graphics.FromImage(Sbmp)
        Dim tmpPen As New Pen(DColor, LineWidth)
        Graphic.DrawRectangle(tmpPen, Rec)
    End Sub
    ' 繪製 Row 線條
    Public Sub DrawLine(ByVal Pt() As Point, ByRef bmp As Image, ByVal DColor As Color, Optional ByVal LineWidth As Integer = 2)
        Dim Graphic As Graphics = Graphics.FromImage(bmp)
        Dim tmpPen As New Pen(DColor, LineWidth)
        Graphic.DrawLine(tmpPen, Pt(0), Pt(1))
    End Sub
    ' 繪製文字
    Public Sub DrawString(ByVal SStr As String, ByRef bmp As Image, ByVal X As Integer, ByVal Y As Integer, ByVal TColor As Color, Optional ByVal FontSize As Integer = 40)
        'If Not DrawAllowed Then Exit Sub
        Dim Graphic As Graphics = Graphics.FromImage(bmp)
        Dim Fnt2 As New Font("Times New Roman", FontSize, FontStyle.Bold)
        Dim TBrush = New SolidBrush(TColor)
        Graphic.DrawString(SStr, Fnt2, TBrush, X, Y)
    End Sub
    ' 繪製圓圈 Xc,Yc 為中心座標 Xc, Yc 為圓中心, R 為半徑 LineWidth 為線寬
    Public Sub DrawCircle(ByVal Xc As Single, ByVal Yc As Single, ByRef bmp As Image, ByVal DColor As Color, ByVal R As Single, ByVal LineWidth As Single)
        Dim X As Single = Xc - R
        Dim Y As Single = Yc - R
        Dim Width As Single = 2 * R
        Dim Height As Single = 2 * R
        Dim Graphic As Graphics = Graphics.FromImage(bmp)
        Dim tmpPen As New Pen(DColor, LineWidth)
        Graphic.DrawEllipse(tmpPen, X, Y, Width, Height)
    End Sub
    ' 繪製實心圓 Xc,Yc 為中心座標 Xc, Yc 為圓中心, R 為半徑 LineWidth 為線寬
    Public Sub DrawSolidCircle(ByVal Xc As Single, ByVal Yc As Single, ByRef bmp As Image, ByVal DColor As Color, ByVal R As Single)
        Dim X As Single = Xc - R
        Dim Y As Single = Yc - R
        Dim Width As Single = 2 * R
        Dim Height As Single = 2 * R
        Dim Graphic As Graphics = Graphics.FromImage(bmp)
        Dim TBrush = New SolidBrush(DColor)
        Graphic.FillEllipse(TBrush, X, Y, Width, Height)
    End Sub
    ' 繪製空心橢圓
    Public Sub DrawEllipse(ByVal Rec As RectangleF, ByRef bmp As Image, ByVal DColor As Color, ByVal LineWidth As Single)
        Dim X As Single = Rec.Left
        Dim Y As Single = Rec.Top
        Dim Width As Single = Rec.Width
        Dim Height As Single = Rec.Height
        Dim Graphic As Graphics = Graphics.FromImage(bmp)
        Dim tmpPen As New Pen(DColor, LineWidth)
        Graphic.DrawEllipse(tmpPen, X, Y, Width, Height)
    End Sub
    ' 繪製實心橢圓
    Public Sub DrawSolidEllipse(ByVal Rec As RectangleF, ByRef bmp As Image, ByVal DColor As Color)
        Dim X As Single = Rec.Left
        Dim Y As Single = Rec.Top
        Dim Width As Single = Rec.Width
        Dim Height As Single = Rec.Height
        Dim Graphic As Graphics = Graphics.FromImage(bmp)
        Dim TBrush = New SolidBrush(DColor)
        Graphic.FillEllipse(TBrush, X, Y, Width, Height)
    End Sub
    ' 繪製十字 X,Y 為中心座標
    Public Sub DrawMark(ByVal Xc As Single, ByVal Yc As Single, ByRef bmp As Image, ByVal DColor As Color, ByVal Width As Single, ByVal Height As Single, ByVal LineWidth As Single)
        Dim VBar As New RectangleF(Xc - LineWidth / 2, Yc - Height / 2, LineWidth, Height)
        Dim HBar As New RectangleF(Xc - Width / 2, Yc - LineWidth / 2, Width, LineWidth)
        Dim TBrush = New SolidBrush(DColor)
        Dim Graphic As Graphics = Graphics.FromImage(bmp)
        Graphic.FillRectangle(TBrush, VBar)
        Graphic.FillRectangle(TBrush, HBar)
    End Sub
#End Region
#Region "Private 方法"
    ' 取得所有色階分布 顏色上限為UpLimit
    Private Shared Function GetAllColorBar(ByVal ColorArray() As Byte, Optional ByVal UpLimit As Integer = 255) As List(Of cls_ColorBar)
        Dim ColorList As New Dictionary(Of Integer, Integer)
        ' 第一步:建立ColorList 0~UpLimit
        For i = 0 To 255
            ColorList.Add(i, 0)
        Next
        ' 計算每一種顏色總數量
        For i = 0 To ColorArray.GetUpperBound(0)
            If ColorArray(i) <= UpLimit Then
                Dim Index As Integer = ColorArray(i)
                ColorList(Index) += 1
            End If
        Next
        Dim ColorBar = GetColorBar(ColorList)
        Return ColorBar
    End Function
    ' 依據ColorList 找出ColorBar 
    Private Shared Function GetColorBar(ByVal ColorList As Dictionary(Of Integer, Integer)) As List(Of cls_ColorBar)
        Dim ColorBars As New List(Of cls_ColorBar)
        Dim TotalLength As Integer
        For i = 0 To ColorList.Keys.Count - 1
            TotalLength += ColorList(ColorList.Keys(i))
        Next
        ' 第二步:建立ColorBar 0~255 
        Dim TCount As Integer = 0
        For i = 0 To 255
            Dim newBar As New cls_ColorBar
            With newBar
                .POS = i
                .Count = ColorList(.POS)
                .PreCount = 0
                .NxtCount = 0
                If i > 0 Then .PreCount = ColorList(.POS - 1)
                If i < 255 Then .NxtCount = ColorList(.POS + 1)
                .calculatesloptype()
                TCount += .Count
                .Percent = Math.Round(TCount / TotalLength, 5)
            End With
            ColorBars.Add(newBar)
        Next
        Return ColorBars
    End Function
    Private Shared Function SearchBaseColor(ByVal ColorBar As List(Of cls_ColorBar)) As Integer
        Dim AllMountains = CalculateMountain(ColorBar)
        Dim MountSort = From item In AllMountains Order By item.volumn Descending
        Dim MountList As New List(Of cls_mountain)
        Dim LastID As Integer = MountSort.Count - 1
        If LastID > 2 Then LastID = 2
        For i = 0 To LastID
            MountList.Add(MountSort(i))
        Next
        Dim MountSort2 = From item In MountList Order By item.peak
        Dim BaseColor As Integer
        With MountSort2(0)
            BaseColor = .peak
        End With
        Return BaseColor
    End Function
    ' 依ColorBars找出色階山脈
    Private Shared Function CalculateMountain(ByVal ColorBars As List(Of cls_ColorBar)) As List(Of cls_mountain)
        ' 建立山脈群
        ' 先找出每座山脈左右邊界
        Dim Mountain As New List(Of cls_mountain)
        Try
            Dim StepID As Integer = 0 ' 0: 找初始左山腳 1:找下坡點 2:找右山腳 3: 找上坡點(左山腳)
            Dim MtID As Integer
            For i = 0 To 255
                With ColorBars(i)
                    Select Case StepID
                        Case 0 '找左山腳
                            If .SlopType = "0+1" Or .SlopType = "+1+1" Then  ' 找到第一座山的左山腳
                                MtID = 0
                                Dim NewMountain As New cls_mountain
                                With NewMountain
                                    .Index = MtID
                                    .left = i
                                    StepID = 1 '找下坡點 
                                End With
                                Mountain.Add(NewMountain)
                            End If
                        Case 1 '找下坡點 
                            If i = 255 Then ' 已在最右端
                                With Mountain(MtID)
                                    .right = i
                                    Exit For
                                End With
                            End If
                            If .SlopType = "+1-1" Or .SlopType = "0-1" Then  ' 找到下坡點 
                                StepID = 2 '找右山腳 
                            End If
                        Case 2 '找右山腳 
                            If i = 255 Then ' 已在最右端
                                With Mountain(MtID)
                                    .right = i
                                    Exit For
                                End With
                            End If
                            If .SlopType = "-10" Then  ' 找到右山腳 
                                With Mountain(MtID)
                                    .right = i
                                End With
                                StepID = 3 '找上坡點(左山腳)  
                            End If
                            If .SlopType = "-1+1" Then  ' 找到右山腳 同時是下一座山的左山腳
                                With Mountain(MtID)
                                    .right = i
                                End With
                                MtID += 1
                                Dim NewMountain As New cls_mountain
                                With NewMountain
                                    .Index = MtID
                                    .left = i
                                    StepID = 1 '找下坡點 
                                End With
                                Mountain.Add(NewMountain)
                            End If
                        Case 3 '找上坡點(左山腳) 
                            ' 前一座山峰右下角修正
                            If .SlopType = "0-1" Then  ' 如果又找到下坡 表示前座山脈右下角仍未結束
                                With Mountain(MtID)
                                    .right = i
                                End With
                            End If
                            If .SlopType = "0+1" Then  ' 找到上坡點(左山腳) 
                                MtID += 1
                                Dim NewMountain As New cls_mountain
                                With NewMountain
                                    .Index = MtID
                                    .left = i
                                    StepID = 1 '找下坡點 
                                End With
                                Mountain.Add(NewMountain)
                            End If
                    End Select
                End With
            Next
            ' 再將每一座山脈的Color Bar 填進去
            If Mountain.Count = 0 Then
                Return Nothing
            End If
            Dim TotalCount As Integer = 0
            For i = 0 To Mountain.Count - 1
                With Mountain(i)
                    For Bar = .left To .right
                        .eachbar.Add(ColorBars(Bar))
                    Next
                    .calculatecoef()  ' 
                    TotalCount += .volumn
                End With
            Next
            ' 最後再計算volumnRate
            For i = 0 To Mountain.Count - 1
                With Mountain(i)
                    .volumnRate = .volumn / TotalCount
                End With
            Next
            Return Mountain
        Catch ex As Exception
            Application.DoEvents()
            Return Mountain
        End Try
    End Function
    Private Shared Function CalPercentage(ByVal Sensitivity As Single) As Single
        Dim Y As Single = -0.199 * Sensitivity + 99.9
        Return Y / 100
    End Function
    ' 取得黑色的數量
    Private Function GetBlackWeight(ByVal GV As Integer(), ByVal chkval As Integer) As Integer
        Dim rtn As Integer = 0
        For i As Integer = 0 To GV.GetUpperBound(0)
            If GV(i) <= chkval Then rtn += 1
        Next
        Return rtn
    End Function
    Private Function GetBlackWeight(ByVal GV(,) As Byte, ByVal chkval As Integer) As Integer
        Dim rtn As Integer = 0
        For i As Integer = 0 To GV.GetUpperBound(0)
            For j As Integer = 0 To GV.GetUpperBound(1)
                If GV(i, j) <= chkval Then rtn += 1
            Next
        Next
        Return rtn
    End Function
    ' 取得白色的數量 
    Private Function GetWhiteWeight(ByVal GV As Integer(), ByVal chkval As Integer, Optional ByVal shift As Integer = 1) As Integer
        Dim rtn As Integer = 0
        For i As Integer = 0 To GV.GetUpperBound(0) Step shift
            If GV(i) >= chkval Then rtn += 1
        Next
        Return rtn
    End Function
    Private Function GetWhiteWeight(ByVal GV(,) As Byte, ByVal chkval As Integer) As Integer
        Dim rtn As Integer = 0
        Try
            For i As Integer = 0 To GV.GetUpperBound(0)
                For j As Integer = 0 To GV.GetUpperBound(1)
                    If GV(i, j) >= chkval Then rtn += 1
                Next
            Next
            Return rtn
        Catch ex As Exception
            Return rtn
            Application.DoEvents()
        End Try
    End Function
    Public Function GetWhitePercentage(ByVal Rec As Rectangle, ByVal chkval As Integer) As Single
        Dim rtn As Single = 0
        Try
            Dim GV = GetGrayValue_1D(Rec)
            Dim FitCont As Integer = 0
            For i As Integer = 0 To GV.GetUpperBound(0)
                If GV(i) >= chkval Then FitCont += 1
            Next
            rtn = Math.Round(FitCont / GV.Length, 4)
            If rtn > 0.99 Then
                Application.DoEvents()
            End If
            Return rtn
        Catch ex As Exception
            Return rtn
            Application.DoEvents()
        End Try
    End Function
    Public Function GetBlackPercentage(ByVal Rec As Rectangle, ByVal chkval As Integer) As Single
        Dim rtn As Single = 0
        Try
            Dim GV = GetGrayValue_1D(Rec)
            Dim FitCont As Integer = 0
            For i As Integer = 0 To GV.GetUpperBound(0)
                If GV(i) <= chkval Then FitCont += 1
            Next
            rtn = Math.Round(FitCont / GV.Length, 4)
            Return rtn
        Catch ex As Exception
            Return rtn
            Application.DoEvents()
        End Try
    End Function

    ' 建立垂直線物件
    Private Function CreateVLine(ByVal X As Integer, ByVal LineStart As Integer, ByVal LineEnd As Integer) As Class_VLine
        Return New Class_VLine(X, LineStart, LineEnd)
    End Function
    ' 建立水平線物件
    Private Function CreateHLine(ByVal Y As Integer, ByVal LineStart As Integer, ByVal LineEnd As Integer) As Class_HLine
        Return New Class_HLine(Y, LineStart, LineEnd)
    End Function

#End Region

#Region "群組化分析"

    Private InstantGroupid As Integer = -1
    Private _CellSize As Integer = 5 '僅能用 3,5,7,9 單數
    Private _ChechAreaColorDist As str_Colordistribution
    Private _CellArea As Dictionary(Of Integer, cls_CellArea)
    Private _CellGroup As Dictionary(Of Integer, cls_cellGroup)
    Private _CellGroupList As List(Of cls_cellGroup)
    Private _CellGroupThreshhold As Integer = 50 ' 群組Cell門檻, cell 遭過門檻數的群組才會被列出來 , 最小值2
    Private _SepDist As Integer = 1 ' 分離距離 1~ 5
    Private _ShowAllCell As Boolean = False  ' 是否顯示所有Cell
    Private _ShowGroup As Boolean = True ' 是否顯示群組
    Private _ErrorOccure As Boolean = False  ' 鑑別錯誤是否產生
    Private _ErrorString As String = ""   ' 鑑別錯誤訊息
    Private _ProcessIsOn As Boolean = True  ' 是否鑑仍在鑑別中
    Private _ProcessFinished As Boolean = True  ' 是否鑑別完成

#Region "屬性"
    Public Property ShowAllCell As Boolean
        Get
            Return _ShowAllCell
        End Get
        Set(ByVal value As Boolean)
            _ShowAllCell = value
        End Set
    End Property
    Public Property ShowGroup As Boolean
        Get
            Return _ShowGroup
        End Get
        Set(ByVal value As Boolean)
            _ShowGroup = value
        End Set
    End Property
    Public Property CellGroupThreshhold As Integer
        Get
            Return _CellGroupThreshhold
        End Get
        Set(ByVal value As Integer)
            _CellGroupThreshhold = value
            If _CellGroupThreshhold < 2 Then _CellGroupThreshhold = 2 ' 至少要三個
        End Set
    End Property
    Public ReadOnly Property CellGroup As List(Of cls_cellGroup)
        Get
            Return _CellGroupList
        End Get
    End Property
    Public Property CellSize As Integer
        Get
            Return _CellSize
        End Get
        Set(ByVal value As Integer)
            If _CellSize Mod 2 = 0 Then Exit Property ' 偶數無法設定
            If _CellSize < 3 Then Exit Property ' 至少要三個
            _CellSize = value
        End Set
    End Property

    ' 分離距離 1~ 5 , 群組解析時, 當距離超過分離距離就當不同群組
    Public Property SepDist As Integer
        Get
            Return _SepDist
        End Get
        Set(ByVal value As Integer)
            _SepDist = value
            If value < 1 Then
                _SepDist = 1
            ElseIf value > 5 Then
                _SepDist = 5
            End If

        End Set
    End Property
    Public ReadOnly Property ProcessIsOn As Boolean
        Get
            Return _ProcessIsOn
        End Get
    End Property
    Public ReadOnly Property ErrorOccure As Boolean
        Get
            Return _ErrorOccure
        End Get
    End Property
    Public ReadOnly Property ProcessFinished As Boolean
        Get
            Return _ProcessFinished
        End Get
    End Property
    Public ReadOnly Property ErrorString As String
        Get
            Return _ErrorString
        End Get
    End Property

#End Region
#Region "自訂類別"
    '   定義Cell群組 
    Public Class cls_cellGroup
        Public GroupID As Integer = -1
        Public Cells As Dictionary(Of Point, cls_cell)
        Public Rec As Rectangle
        Public Sub New(ByVal GID As Integer)
            GroupID = GID
            Cells = New Dictionary(Of Point, cls_cell)
        End Sub
        Public Sub CalBound()
            Dim Key As Point = Cells.Keys(0)
            Dim LB As Integer = Cells(Key).Rec.Left
            Dim RB As Integer = Cells(Key).Rec.Right
            Dim UB As Integer = Cells(Key).Rec.Top
            Dim DB As Integer = Cells(Key).Rec.Bottom
            For i = 1 To Cells.Count - 1
                Dim tmpKey As Point = Cells.Keys(i)
                With Cells(tmpKey).Rec
                    If .Left < LB Then LB = .Left
                    If .Right > RB Then RB = .Right
                    If .Top < UB Then UB = .Top
                    If .Bottom > DB Then DB = .Bottom
                End With
            Next
            Rec = New Rectangle(LB, UB, RB - LB, DB - UB)
        End Sub
    End Class
    '   定義Cell
    Public Class cls_cell
        Public CPos As Point  ' Cell 中心
        Public Rec As Rectangle ' Cell 本體範圍
        Public CellPitch As Integer
        Public Cell_NbPts As List(Of Point)  ' 鄰近Cell 中心點
        Public GroupAble As Boolean = False
        Public GroupID As Integer = -1
        ' Size 只能是3,5,7
        Public Sub New(ByVal Xc As Integer, ByVal Yc As Integer, ByVal DSize As Integer, ByVal GPSepDist As Integer)
            Dim Left As Integer = Xc - DSize \ 2
            Dim Top As Integer = Yc - DSize \ 2
            CPos = New Point(Xc, Yc)
            Rec = New Rectangle(Left, Top, DSize, DSize)
            'ExCellRec = New Rectangle(Left - 1, Top - 1, DSize + 2, DSize + 2)
            CellPitch = DSize
            Cell_NbPts = New List(Of Point)
            CreatNeighborCellPoint(GPSepDist)
        End Sub
        ' 建立鄰近Cell 的座標 NbCount 表示上下左右延伸多少個Cell Pitch 為鄰近Cell (通常為2 個Pitch, 至少一個 )
        Public Sub CreatNeighborCellPoint(ByVal NbCount As Integer)
            Dim LB As Integer = CPos.X - NbCount * CellPitch
            Dim RB As Integer = CPos.X + NbCount * CellPitch
            Dim UB As Integer = CPos.Y - NbCount * CellPitch
            Dim DB As Integer = CPos.Y + NbCount * CellPitch
            If Cell_NbPts.Count > 0 Then Cell_NbPts = New List(Of Point)
            For Y As Integer = UB To DB Step CellPitch
                For X As Integer = LB To RB Step CellPitch
                    If (X = CPos.X And Y = CPos.Y) Then Continue For
                    Cell_NbPts.Add(New Point(X, Y))
                Next
            Next
        End Sub
    End Class
    ' 放置Cell的子區域
    Public Class cls_CellArea
        Public Rec As Rectangle
        Public AreaID As Integer
        Public XID As Integer
        Public YID As Integer
        Public Cells As Dictionary(Of Point, cls_cell)
        Public ColorDist As str_Colordistribution
        Public CellSearched As Boolean = False
        Public Sub New(ByVal XIndex As Integer, ByVal YIndex As Integer, ByVal Index As Integer, ByVal AreaRec As Rectangle)
            Rec = AreaRec
            XID = XIndex
            YID = YIndex
            AreaID = Index
            Cells = New Dictionary(Of Point, cls_cell)
            CellSearched = False
        End Sub
        Public Sub AddCell(ByVal Pt As cls_cell)
            Cells.Add(Pt.CPos, Pt)
        End Sub
    End Class
    Public Class cls_RecColorDist
        Public Index As Integer
        Public SearchedFinished As Boolean
        Public ColorDist As str_Colordistribution
        Public Rec As Rectangle
        Public Sub New(ByVal TIndex As Integer, ByVal AreaRec As Rectangle)
            Index = TIndex
            SearchedFinished = False
            Rec = AreaRec
            ColorDist = Nothing
        End Sub
    End Class

#End Region

#Region "Public 方法"
    Private StepID As Integer = 0
    ' 取得指定區域內的色階分布(分成XPts, YPart)
    Private MyColorDist() As cls_RecColorDist
    Public Function GetRecColorDist(ByVal rec As Rectangle) As str_Colordistribution
        If IsNothing(rec) Then Return Nothing
        Dim recs() As Rectangle = {rec}
        Dim dist As str_Colordistribution() = GetRecColorDist(recs)
        Return dist(0)
    End Function

    Public Function GetRecColorDist(ByVal rec() As Rectangle) As str_Colordistribution()
        If rec.Count = 0 Then Return Nothing
        Dim Rtn(rec.Count - 1) As str_Colordistribution
        ReDim MyColorDist(rec.Count - 1)
        For i = 0 To rec.Count - 1
            MyColorDist(i) = New cls_RecColorDist(i, rec(i))
            GetColorDistribution2(i)
            'th_GetColorDist(i)
        Next
        ' 等待算完成
        Do
            Dim SearchFinished As Boolean = True
            For i = 0 To rec.Count - 1
                If MyColorDist(i).SearchedFinished = False Then
                    SearchFinished = False
                    Exit For
                End If
            Next
            Application.DoEvents()
            If SearchFinished Then Exit Do
        Loop
        For i = 0 To rec.Count - 1
            Rtn(i) = MyColorDist(i).ColorDist
        Next
        Return Rtn

    End Function

    ' 以多執行旭分析內部Cell
    Private Sub th_GetColorDist(ByRef Index As Integer)
        Dim CB = New WaitCallback(AddressOf GetColorDistribution2)
        ThreadPool.UnsafeQueueUserWorkItem(CB, Index)
    End Sub
    '  多執行緒
    Private Sub GetColorDistribution2(ByVal Index As Integer)
        With MyColorDist(Index)
            Dim ColorByte = GetGrayValue_1D(.Rec, 2, 2)
            .ColorDist = GetColorDistribution(ColorByte)
            .SearchedFinished = True
        End With
    End Sub



    ' 取得Cell 群組
    Public Sub GetCellGroup(ByVal rec As Rectangle, Optional ByVal XPts As Integer = 5, Optional ByVal Ypts As Integer = 1)
        StepID = 0
        _CellGroup = New Dictionary(Of Integer, cls_cellGroup)
        _CellGroupList = New List(Of cls_cellGroup)
        ProcessStart() ' 程序啟動
        Try
            Dim ColorByte = GetGrayValue_1D(rec, XPts + 2, Ypts + 2)  ' 取出查區域的顏色
            _ChechAreaColorDist = GetColorDistribution(ColorByte)  ' 讀檢查區域的顏色分布
            _CellArea = GetEachArea(rec, XPts, Ypts) ' 取得子區域 ( Cell 還未分析)
            ' 找尋合格 Cell , 每一區域用多執行旭分析
            StepID = 1
            For Each id As Integer In _CellArea.Keys
                th_AnalysisCell(id)
            Next
            Do
                Application.DoEvents()
                Threading.Thread.Sleep(10)
                Application.DoEvents()
                Dim Finished As Boolean = True
                For Each id In _CellArea.Keys
                    If _CellArea(id).CellSearched = False Then
                        Finished = False
                    End If
                Next
                If Finished Then Exit Do
            Loop

            If _ShowAllCell Then
                ' 把所有 Cell 劃出來
                For Each id As Integer In _CellArea.Keys
                    If _CellArea(id).Cells.Count = 0 Then Continue For
                    For Each obj In _CellArea(id).Cells.Values
                        DrawRec(obj.Rec, _Image, Color.LightYellow, 1)
                    Next
                Next
                DrawRec(rec, _Image, Color.LightBlue, 1)
            End If

            ' Cell 群組化
            StepID = 2
            InstantGroupid = -1
            For Each Area In _CellArea.Values
                For Each cell In Area.Cells.Values
                    CheckArroundCellGrouped(cell)
                Next
            Next
            Dim GPSort = From item In _CellGroup Where item.Value.Cells.Count > _CellGroupThreshhold Order By item.Value.Cells.Keys.Count Descending

            If GPSort.Count > 0 Then
                For i = 0 To GPSort.Count - 1
                    _CellGroupList.Add(GPSort(i).Value)
                Next
            End If

            ProcessEnd()  ' 程序結束
            StepID = 3

            If Not _ShowGroup Then Exit Sub

            ' 繪圖 找出群組
            If _CellGroupList.Count > 0 Then
                For i = 0 To _CellGroupList.Count - 1
                    With _CellGroupList(i)
                        For Each itm In .Cells.Values
                            DrawRec(itm.Rec, _Image, GetDrawColor(i), 1)
                        Next
                        .CalBound()
                        DrawRec(.Rec, _Image, GetDrawColor(i), 2)
                    End With
                Next
            Else
                DrawString("None Group Seachered", _Image, 5, 5, Color.Red, )
            End If
            DrawRec(rec, _Image, Color.LightBlue, 2)

            Exit Sub
        Catch ex As Exception
            ProcessEnd(ex.Message)
        End Try

    End Sub

#End Region

#Region "Private 方法"
    ' 在傳入的區塊Rec內建立數個Ceell子區域, XParts為X方向切割數,YParts為Y方向切割數
    Private Function GetEachArea(ByVal Rec As Rectangle, Optional ByVal XParts As Integer = 1, Optional ByVal YParts As Integer = 1) As Dictionary(Of Integer, cls_CellArea)
        Dim CellArea As New Dictionary(Of Integer, cls_CellArea)

        Dim CellPitch As Integer = _CellSize
        Dim DxTemp As Single = Rec.Width / XParts
        Dim DyTemp As Single = Rec.Height / YParts
        Dim Xno As Integer = DxTemp \ CellPitch + 1
        Dim Yno As Integer = DyTemp \ CellPitch + 1
        Dim SubW As Integer = Xno * CellPitch
        Dim SubH As Integer = Yno * CellPitch
        ' 計算最後寬度與長度
        Dim LastDx As Integer = (Rec.Width - SubW * (XParts - 1))
        Dim LastDy As Integer = (Rec.Height - SubH * (YParts - 1))
        Dim LastXno As Integer = LastDx \ CellPitch + 1
        Dim LastYno As Integer = LastDy \ CellPitch + 1
        Dim LastW As Integer = LastXno * CellPitch
        Dim LastH As Integer = LastYno * CellPitch

        For Y = 0 To YParts - 1
            Dim Height = IIf(Y = YParts - 1, LastH, SubH)
            Dim Top As Integer = Rec.Top + Y * SubH
            For X = 0 To XParts - 1
                Dim Width = IIf(X = XParts - 1, LastW, SubW)
                Dim Left As Integer = Rec.Left + X * SubW
                Dim subrec As New Rectangle(Left, Top, Width, Height)
                Dim KeyID As Integer = Y * XParts + X
                CellArea.Add(KeyID, New cls_CellArea(X, Y, KeyID, subrec))
            Next
        Next

        Return CellArea

    End Function
    ' 檢查Cell周圍的鄰居,判斷要加入新增群組,或是加入既有群組或是合併群組
    Private Sub CheckArroundCellGrouped(ByRef cell As cls_cell)
        Dim celllist As New List(Of cls_cell)
        For Each pt In cell.Cell_NbPts
            For Each Area In _CellArea
                If Area.Value.Cells.Keys.Contains(pt) Then
                    celllist.Add(Area.Value.Cells(pt))
                End If
            Next
        Next
        cell.GroupAble = celllist.Count > 0
        If Not cell.GroupAble Then
            Exit Sub
        End If
        Dim IDList As New List(Of Integer)
        ' 檢查周圍Cell GroupID 找出所有已經群組化的 Cell
        If cell.GroupID >= 0 Then
            IDList.Add(cell.GroupID)
        End If
        For i = 0 To celllist.Count - 1
            If Not IDList.Contains(celllist(i).GroupID) And celllist(i).GroupID >= 0 Then
                IDList.Add(celllist(i).GroupID)
            End If
        Next
        Dim AddGPID As Integer = -1  ' 要加入的群組
        Dim RemoveGPID As New List(Of Integer) ' 要移除的群組
        Dim AddType As Integer = 0 ' 加入狀態 0 加入新群組 1 加入既有群組 2 合併群組
        If IDList.Count = 0 Then ' 都還沒有群組化
            AddType = 0
            InstantGroupid += 1
            AddGPID = InstantGroupid
        ElseIf IDList.Count = 1 Then  ' 只有一個群組存在 加入此群組
            AddType = 1
            AddGPID = IDList(0)
        Else ' 有多筆群組,要進行合併
            AddType = 2
            ' 找出數量最大的群組ID
            Dim MaxGPID As Integer = IDList(0)
            Dim MaxCellCount As Integer = _CellGroup(IDList(0)).Cells.Keys.Count
            For i = 1 To IDList.Count - 1
                If _CellGroup(IDList(i)).Cells.Keys.Count > MaxCellCount Then
                    MaxGPID = IDList(i)
                    MaxCellCount = _CellGroup(IDList(i)).Cells.Keys.Count
                End If
            Next
            AddGPID = MaxGPID
            ' 找出最後要移除的群組
            For i = 0 To IDList.Count - 1
                Dim ID As Integer = IDList(i)
                If ID <> AddGPID Then
                    RemoveGPID.Add(ID)
                End If
            Next
        End If
        Select Case AddType
            Case 0, 1 ' 加入的群組
                AddCellToGroup(AddGPID, cell)
                For Each obj In celllist
                    AddCellToGroup(AddGPID, obj)
                Next
            Case 2 ' 有多筆群組,加入最大群組,將小群組併入大群組,最後移除小群組
                AddCellToGroup(AddGPID, cell) ' 目標 Cell 加入大群組
                For Each obj In celllist ' 周圍Cell加入大群組
                    AddCellToGroup(AddGPID, obj)
                Next
                ' 將需要移除的群組移動到大群組後刪除
                For Each ID In RemoveGPID
                    For Each itm In _CellGroup(ID).Cells.Values
                        AddCellToGroup(AddGPID, itm)
                    Next
                    _CellGroup.Remove(ID)
                Next
        End Select
        Application.DoEvents()
    End Sub
    ' 將Cell 加入群組
    Private Sub AddCellToGroup(ByVal GPID As Integer, ByRef Cell As cls_cell)
        If Not _CellGroup.Keys.Contains(GPID) Then
            _CellGroup.Add(GPID, New cls_cellGroup(GPID))
        End If
        Cell.GroupID = GPID
        Cell.GroupAble = True
        With _CellGroup(GPID).Cells
            If Not .Keys.Contains(Cell.CPos) Then
                .Add(Cell.CPos, Cell)
            End If
        End With
    End Sub
    ' 以多執行旭分析內部Cell
    Private Sub th_AnalysisCell(ByVal Key As Integer)
        Dim CB = New WaitCallback(AddressOf AnalysisCell)
        ThreadPool.UnsafeQueueUserWorkItem(CB, Key)
    End Sub
    Private Sub AnalysisCell(ByVal AKey As Integer)
        'SyncLock _CellArea(Key)
        Dim Key As Integer = AKey * 1
        With _CellArea(Key)
            Dim ColorByte = GetGrayValue_1D(.Rec, 2, 2)  ' 取出查區域的顏色
            .ColorDist = GetColorDistribution(ColorByte)  ' 讀檢查區域的顏色分布
            If .ColorDist.V0_Max <= _ChechAreaColorDist.V3_down Then ' 全部黑嬤嬤, 無白點
                .CellSearched = True
                Exit Sub
            End If
            Dim Left As Integer = .Rec.Left + _CellSize \ 2
            Dim Top As Integer = .Rec.Top + _CellSize \ 2
            For Y = Top To .Rec.Bottom Step _CellSize
                For X = Left To .Rec.Right Step _CellSize
                    Dim Pt As New Point(X, Y)
                    If Key = 1 Then
                        Application.DoEvents()
                    End If
                    If IsWhite(Pt, .ColorDist) Then
                        .AddCell(New cls_cell(X, Y, _CellSize, _SepDist))
                    End If
                Next
            Next
            .CellSearched = True
        End With
        'End SyncLock

    End Sub
    ' 檢查Cell 是否是白色
    Private Function IsWhite(ByVal Pt As Point, ByVal colorval As str_Colordistribution) As Boolean
        Dim LB As Integer = Pt.X - _CellSize \ 2
        Dim RB As Integer = Pt.X + _CellSize \ 2
        Dim UB As Integer = Pt.Y - _CellSize \ 2
        Dim DB As Integer = Pt.Y + _CellSize \ 2
        Dim WCount As Integer = 0 ' 弱粒子數
        Dim WCount_1 As Integer = 0  ' 強粒子數
        Dim StrongCount As Integer = _CellSize ' (強粒子門檻)多少較強粒子判為白
        Dim WeakCount As Integer = (_CellSize ^ 2) \ 2 ' (弱粒子門檻)多少弱粒子判為白
        For Y As Integer = UB To DB
            For X As Integer = LB To RB
                Dim CVal = GetPixel(X, Y, eRgbColorType.Gray)
                Dim Intensity = GetIntensity(CVal, colorval)
                If Intensity >= 2 Then
                    WCount_1 += 1
                    If WCount_1 > StrongCount Then Return True
                End If
                If Intensity > 0 Then
                    WCount += 1
                    If WCount > WeakCount Then Return True
                End If
            Next
        Next
        Return False
    End Function
    ' 計算顏色強度
    Private Function GetIntensity(ByVal Val As Byte, ByVal Cdist As str_Colordistribution) As Integer
        With Cdist
            If Val <= .V2_bwlevel Then
                Return 0
            ElseIf Val > .V2_bwlevel And Val <= .V1_Up Then
                Return 1
            ElseIf Val > .V1_Up And Val <= .V0_Max Then
                Return 2
            Else
                Return 3
            End If
        End With
    End Function
    ' 選擇顏色
    Public Function GetDrawColor(ByVal Index As Integer) As Color
        Dim DColor() As Color = {Color.Cyan, Color.LightGreen, Color.Lime, Color.Yellow, Color.YellowGreen, Color.LightPink, Color.Beige, Color.LightCyan, Color.LightSeaGreen}
        Dim ID As Integer = Index Mod DColor.Count
        Return DColor(ID)
    End Function
    Private Sub ProcessStart()
        _ProcessIsOn = True
        _ProcessFinished = False
        _ErrorOccure = False
        _ErrorString = ""
    End Sub
    Private Sub ProcessEnd(Optional ByVal ErrorStr As String = "")
        _ProcessIsOn = False
        _ProcessFinished = True
        _ErrorOccure = ErrorStr <> ""
        _ErrorString = ErrorStr
    End Sub

#End Region

#End Region

    ' 快速複製指定顏色到影像
    Public Function CopyRecColor(ByVal bmp As Bitmap, ByVal rec As Rectangle, ByVal colorArray(,) As Color) As Bitmap
        Try
            ImgWriter.LockBMP(bmp)
            For X As Integer = 0 To rec.Width - 1
                For Y As Integer = 0 To rec.Height - 1
                    Dim tcolor = colorArray(X, Y)
                    Dim PosX As Integer = rec.X + X
                    Dim PosY As Integer = rec.Y + Y
                    ImgWriter.SetPixel(PosX, PosY, tcolor)
                Next
            Next
            ImgWriter.UnLockBMP(bmp)
            Return bmp
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    ' 二值化影像
    Public Function BinarizingImage(ByVal bmp As Bitmap, ByVal rec As Rectangle, ByVal colorlevel As Integer) As Bitmap
        Try
            Dim TrgBite(rec.Width - 1, rec.Height - 1) As Byte
            Dim OrgColor(,) As Byte = GetGrayValue_2D(rec) ' 取得圖片色階
            ImgWriter.LockBMP(bmp)
            For X As Integer = 0 To rec.Width - 1
                For Y As Integer = 0 To rec.Height - 1
                    TrgBite(X, Y) = IIf(OrgColor(X, Y) > colorlevel, 250, 5)
                    Dim PosX As Integer = rec.X + X
                    Dim PosY As Integer = rec.Y + Y
                    ImgWriter.SetPixel(PosX, PosY, TrgBite(X, Y))
                Next
            Next
            ImgWriter.UnLockBMP(bmp)
            Return bmp
        Catch ex As Exception
            MsgBox("BinarizingImage Error : " & ex.Message)
            Return Nothing
        End Try
    End Function
    ' 膨脹白就是腐蝕 黑
    Public Function Expend_W(ByVal bmp As Bitmap, ByVal rec As Rectangle, ByVal colorlevel As Integer, Optional ByVal CalTwice As Boolean = False) As Bitmap
        Return CorrosImage_B(bmp, rec, colorlevel, CalTwice)
    End Function
    ' 膨脹黑白就是腐蝕白
    Public Function Expend_B(ByVal bmp As Bitmap, ByVal rec As Rectangle, ByVal colorlevel As Integer, Optional ByVal CalTwice As Boolean = False) As Bitmap
        Return CorrosImage_W(bmp, rec, colorlevel, CalTwice)
    End Function

    ' 腐蝕 (針對白色)   膨脹 (針對黑色) 
    Public Function CorrosImage_W(ByVal bmp As Bitmap, ByVal rec As Rectangle, ByVal colorlevel As Integer, Optional ByVal CalTwice As Boolean = False) As Bitmap
        Dim WhiteVal As Byte = 200
        Dim BlackVal As Byte = 10
        Try
            Dim TrgBite(rec.Width - 1, rec.Height - 1) As Byte
            Dim NewBite(rec.Width - 1, rec.Height - 1) As Byte
            Dim OrgColor(,) As Byte = GetGrayValue_2D(rec) ' 取得圖片色階
            ImgWriter.LockBMP(bmp)
            Dim CalTime As Integer = IIf(CalTwice, 1, 0)
            For i = 0 To CalTime
                Dim CompareData(,) As Byte = IIf(i = 0, OrgColor, NewBite)

                For X As Integer = 1 To rec.Width - 2
                    For Y As Integer = 1 To rec.Height - 2
                        Dim PosX As Integer = rec.X + X
                        Dim PosY As Integer = rec.Y + Y
                        Dim IsWhite As Boolean = CompareData(X, Y) > colorlevel
                        TrgBite(X, Y) = IIf(IsWhite, WhiteVal, BlackVal)
                        If i = 0 Then NewBite(X, Y) = TrgBite(X, Y)
                        If IsWhite Then  '  檢查是否要降燥
                            Dim IsBlack As Boolean = False
                            For X2 As Integer = X - 1 To X + 1
                                For Y2 As Integer = Y - 1 To Y + 1
                                    Dim PosX2 As Integer = PosX + X2
                                    Dim PosY2 As Integer = PosY + Y2

                                    If CompareData(X2, Y2) < colorlevel Then  ' 有黑點 則轉為黑
                                        IsBlack = True
                                        TrgBite(X, Y) = BlackVal
                                        If i = 0 Then NewBite(X, Y) = TrgBite(X, Y)
                                        Exit For
                                    End If
                                Next
                                If IsBlack Then Exit For
                            Next
                        End If
                        ImgWriter.SetPixel(PosX, PosY, TrgBite(X, Y))
                    Next
                Next
            Next

            ImgWriter.UnLockBMP(bmp)
            Return bmp
        Catch ex As Exception
            MsgBox("BinarizingImage Error : " & ex.Message)
            Return Nothing
        End Try
    End Function



    ' 腐蝕 (針對黑色)  膨脹 (針對白色) 
    Public Function CorrosImage_B(ByVal bmp As Bitmap, ByVal rec As Rectangle, ByVal colorlevel As Integer, Optional ByVal CalTwice As Boolean = False) As Bitmap
        Dim WhiteVal As Byte = 200
        Dim BlackVal As Byte = 10
        Try
            Dim TrgBite(rec.Width - 1, rec.Height - 1) As Byte
            Dim NewBite(rec.Width - 1, rec.Height - 1) As Byte

            Dim OrgColor(,) As Byte = GetGrayValue_2D(rec) ' 取得圖片色階
            ImgWriter.LockBMP(bmp)
            Dim CalTime As Integer = IIf(CalTwice, 1, 0)

            NewBite = OrgColor.Clone


            For i = 0 To CalTime
                Dim CompareData(,) As Byte = IIf(i = 0, OrgColor, NewBite)
                For X As Integer = 1 To rec.Width - 2
                    For Y As Integer = 1 To rec.Height - 2
                        Dim PosX As Integer = rec.X + X
                        Dim PosY As Integer = rec.Y + Y
                        'If i = 0 Then NewBite(X, Y) = OrgColor(X, Y)
                        Dim IsBlack As Boolean = CompareData(X, Y) < colorlevel
                        TrgBite(X, Y) = IIf(IsBlack, BlackVal, WhiteVal)
                        If i = 0 Then NewBite(X, Y) = TrgBite(X, Y)

                        If IsBlack Then  '  檢查是否要降燥
                            Dim IsWhite As Boolean = False
                            For X2 As Integer = X - 1 To X + 1
                                For Y2 As Integer = Y - 1 To Y + 1
                                    Dim PosX2 As Integer = PosX + X2
                                    Dim PosY2 As Integer = PosY + Y2
                                    'If i = 0 Then NewBite(X2, Y2) = TrgBite(X2, Y2)
                                    If CompareData(X2, Y2) > colorlevel Then  ' 有白點 則轉為白
                                        IsWhite = True
                                        TrgBite(X, Y) = WhiteVal
                                        If i = 0 Then NewBite(X, Y) = TrgBite(X, Y)
                                        Exit For
                                    End If
                                Next
                                If IsWhite Then Exit For
                            Next
                        End If
                        ImgWriter.SetPixel(PosX, PosY, TrgBite(X, Y))
                    Next
                Next
            Next
            ImgWriter.UnLockBMP(bmp)
            Return bmp
        Catch ex As Exception
            MsgBox("BinarizingImage Error : " & ex.Message)
            Return Nothing
        End Try
    End Function


End Class
