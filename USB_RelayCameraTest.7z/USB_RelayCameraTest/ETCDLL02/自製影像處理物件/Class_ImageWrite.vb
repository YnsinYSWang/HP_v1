﻿' 本類別為影像處理模組, 處理模式:從影像擷取 Pixel 進行演算
' 不必使用 Mil , Holcan or OpenCV 等既有元件
' 開發: AUO 設備技術處 陳俊杰
Imports System.Drawing
Imports System.Windows.Forms
Imports System.Threading

Public Class Class_ImageWrite
    Private RGB() As Byte '影像的可存取副本資料陣列
    Private bmpData As System.Drawing.Imaging.BitmapData '影像資料
    Private ptr As IntPtr '影像資料所在的記憶體指標(位置)
    Private ImgLength As Integer '影像總共佔據的位元組數
    Private Stride As Integer '一個影像列的記憶體位元組數，對於32位元電腦必須是32bit(或4byte)的倍數
    Private Bpx As Integer '每一像素點是幾個位元組？通常為1 (Mono 8bits) 3(RGB 24bits)或4(ARGB 32bits)

    '鎖定點陣圖(Bitmap)物件的記憶體位置，建立一個可操作的為元組陣列副本
    Public Function LockBMP(ByVal bmp As Bitmap) As Boolean
        Try
            Dim rect As New Rectangle(0, 0, bmp.Width, bmp.Height) '矩形物件，定義影像範圍
            bmpData = bmp.LockBits(rect, Drawing.Imaging.ImageLockMode.ReadWrite, bmp.PixelFormat) '鎖定影像區記憶體(暫時不接受作業系統的移動)
            ptr = bmpData.Scan0 '影像區塊的記憶體指標
            Stride = bmpData.Stride '每一影像列的長度(bytes)
            Bpx = Stride \ bmp.Width '每一像素的位元組數(3或4)
            ImgLength = Stride * bmp.Height '影像總位元組數
            ReDim RGB(ImgLength - 1) '宣告影像副本資料陣列
            System.Runtime.InteropServices.Marshal.Copy(ptr, RGB, 0, ImgLength) '拷貝點陣圖資料到副本陣列
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
    '複製位元組陣列副本的處理結果到Bitmap物件，並解除其記憶體鎖定
    Public Function UnLockBMP(ByVal bmp As Bitmap) As Boolean
        Try
            System.Runtime.InteropServices.Marshal.Copy(rgb, 0, ptr, ImgLength) '拷貝副本陣列資料到點陣圖位置
            bmp.UnlockBits(bmpData) '解除鎖定
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
    '在記憶體鎖定狀態下繪製顏色點(Argb)
    Public Function SetPixel(ByVal X As Integer, ByVal Y As Integer, ByVal R As Byte, ByVal G As Byte, ByVal B As Byte, ByVal A As Integer) As Boolean
        Try
            Dim k As Integer = Y * Stride + X * Bpx '索引位置計算
            Select Case Bpx
                Case 1  ' Mono
                    Dim Gray As Double = 0.299 * R + 0.587 * G + 0.114 * B
                    RGB(k) = Gray 'blue
                Case 3 'RGB
                    RGB(k) = B 'blue
                    RGB(k + 1) = G 'green
                    RGB(k + 2) = R 'red
                Case 4 ' ARGB
                    RGB(k) = B 'blue
                    RGB(k + 1) = G 'green
                    RGB(k + 2) = R 'red
                    RGB(k + 3) = A '透明度
            End Select
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    '在記憶體鎖定狀態下繪製顏色點(Argb)
    Public Function SetPixel(ByVal X As Integer, ByVal Y As Integer, ByVal TColor As Color) As Boolean
        Dim R As Byte = TColor.R
        Dim G As Byte = TColor.G
        Dim B As Byte = TColor.B
        Dim A As Byte = TColor.A
        Try
            Dim k As Integer = Y * Stride + X * Bpx '索引位置計算
            Select Case Bpx
                Case 1  ' Mono
                    Dim Gray As Double = 0.299 * R + 0.587 * G + 0.114 * B
                    RGB(k) = Gray 'blue
                Case 3 'RGB
                    RGB(k) = B 'blue
                    RGB(k + 1) = G 'green
                    RGB(k + 2) = R 'red
                Case 4 ' ARGB
                    RGB(k) = B 'blue
                    RGB(k + 1) = G 'green
                    RGB(k + 2) = R 'red
                    RGB(k + 3) = A '透明度
            End Select
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    ' 寫入灰階值
    Public Function SetPixel(ByVal X As Integer, ByVal Y As Integer, ByVal colorlevel As Byte) As Boolean
        Try
            Dim k As Integer = Y * Stride + X * Bpx '索引位置計算
            Select Case Bpx
                Case 1  ' Mono
                    RGB(k) = colorlevel 'blue
                Case 3 'RGB
                    RGB(k) = colorlevel 'blue
                    RGB(k + 1) = colorlevel 'green
                    RGB(k + 2) = colorlevel 'red
                Case 4 ' ARGB
                    RGB(k) = colorlevel 'blue
                    RGB(k + 1) = colorlevel 'green
                    RGB(k + 2) = colorlevel 'red
                    RGB(k + 3) = 255 '透明度
            End Select
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
    Public Function SetPixel(ByVal TrgPT As Point, ByVal colorlevel As Byte) As Boolean
        Dim X As Integer = TrgPT.X
        Dim Y As Integer = TrgPT.Y
        Return SetPixel(X, Y, colorlevel)
    End Function


End Class
