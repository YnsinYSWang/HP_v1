﻿'Imports Basler.Pylon

Public Class Class_BaslerHdl

    'Private AllCameras As List(Of ICameraInfo)


    Public Sub New()
        RefreshDeviceList()
    End Sub

    Private Sub RefreshDeviceList()

        Try

            'AllCameras = CameraFinder.Enumerate
            Application.DoEvents()

        Catch ex As Exception

        End Try

    End Sub

End Class
