﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UC_AOIRecipe
    Inherits System.Windows.Forms.UserControl

    'UserControl 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txt_RecH = New System.Windows.Forms.TextBox()
        Me.lbl_RecH = New System.Windows.Forms.Label()
        Me.txt_RecW = New System.Windows.Forms.TextBox()
        Me.lbl_RecW = New System.Windows.Forms.Label()
        Me.txt_RecY = New System.Windows.Forms.TextBox()
        Me.lbl_RecY = New System.Windows.Forms.Label()
        Me.txt_RecX = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Btn_DefineArea = New System.Windows.Forms.Button()
        Me.txt_MarkH = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txt_MarkW = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Btn_Size = New System.Windows.Forms.Button()
        Me.txt_C4 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txt_C3 = New System.Windows.Forms.TextBox()
        Me.lbl_C3 = New System.Windows.Forms.Label()
        Me.txt_C2 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txt_C1 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_C0 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Btn_AnalysisColor = New System.Windows.Forms.Button()
        Me.txt_threshold = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txt_TrgColor = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txt_Rate = New System.Windows.Forms.TextBox()
        Me.TrackBar1 = New System.Windows.Forms.TrackBar()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Btn_BinarizingImage = New System.Windows.Forms.Button()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.RadBtn_Assign = New System.Windows.Forms.RadioButton()
        Me.RadBtn_Mid = New System.Windows.Forms.RadioButton()
        Me.RadBtn_Rate = New System.Windows.Forms.RadioButton()
        Me.RadBtn_Auto = New System.Windows.Forms.RadioButton()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lbl_Illustration = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Btn_SaveAsDefaultXML = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txt_Default = New System.Windows.Forms.TextBox()
        Me.btn_SaveCurrentRecipe = New System.Windows.Forms.Button()
        Me.Btn_SaveAs = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txt_RecH
        '
        Me.txt_RecH.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_RecH.Location = New System.Drawing.Point(450, 0)
        Me.txt_RecH.Margin = New System.Windows.Forms.Padding(0)
        Me.txt_RecH.Name = "txt_RecH"
        Me.txt_RecH.Size = New System.Drawing.Size(50, 22)
        Me.txt_RecH.TabIndex = 17
        '
        'lbl_RecH
        '
        Me.lbl_RecH.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbl_RecH.Location = New System.Drawing.Point(403, 0)
        Me.lbl_RecH.Name = "lbl_RecH"
        Me.lbl_RecH.Size = New System.Drawing.Size(44, 24)
        Me.lbl_RecH.TabIndex = 13
        Me.lbl_RecH.Text = "高度"
        Me.lbl_RecH.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_RecW
        '
        Me.txt_RecW.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_RecW.Location = New System.Drawing.Point(350, 0)
        Me.txt_RecW.Margin = New System.Windows.Forms.Padding(0)
        Me.txt_RecW.Name = "txt_RecW"
        Me.txt_RecW.Size = New System.Drawing.Size(50, 22)
        Me.txt_RecW.TabIndex = 16
        '
        'lbl_RecW
        '
        Me.lbl_RecW.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbl_RecW.Location = New System.Drawing.Point(303, 0)
        Me.lbl_RecW.Name = "lbl_RecW"
        Me.lbl_RecW.Size = New System.Drawing.Size(44, 24)
        Me.lbl_RecW.TabIndex = 12
        Me.lbl_RecW.Text = "寬度"
        Me.lbl_RecW.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_RecY
        '
        Me.txt_RecY.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_RecY.Location = New System.Drawing.Point(250, 0)
        Me.txt_RecY.Margin = New System.Windows.Forms.Padding(0)
        Me.txt_RecY.Name = "txt_RecY"
        Me.txt_RecY.Size = New System.Drawing.Size(50, 22)
        Me.txt_RecY.TabIndex = 15
        '
        'lbl_RecY
        '
        Me.lbl_RecY.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbl_RecY.Location = New System.Drawing.Point(203, 0)
        Me.lbl_RecY.Name = "lbl_RecY"
        Me.lbl_RecY.Size = New System.Drawing.Size(44, 24)
        Me.lbl_RecY.TabIndex = 11
        Me.lbl_RecY.Text = "上端"
        Me.lbl_RecY.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_RecX
        '
        Me.txt_RecX.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_RecX.Location = New System.Drawing.Point(150, 0)
        Me.txt_RecX.Margin = New System.Windows.Forms.Padding(0)
        Me.txt_RecX.Name = "txt_RecX"
        Me.txt_RecX.Size = New System.Drawing.Size(50, 22)
        Me.txt_RecX.TabIndex = 14
        '
        'Label4
        '
        Me.Label4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label4.Location = New System.Drawing.Point(103, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 24)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "左端"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Btn_DefineArea
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Btn_DefineArea, 2)
        Me.Btn_DefineArea.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Btn_DefineArea.Location = New System.Drawing.Point(0, 0)
        Me.Btn_DefineArea.Margin = New System.Windows.Forms.Padding(0)
        Me.Btn_DefineArea.Name = "Btn_DefineArea"
        Me.Btn_DefineArea.Size = New System.Drawing.Size(100, 24)
        Me.Btn_DefineArea.TabIndex = 18
        Me.Btn_DefineArea.Text = "檢測區域"
        Me.Btn_DefineArea.UseVisualStyleBackColor = True
        '
        'txt_MarkH
        '
        Me.txt_MarkH.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_MarkH.Location = New System.Drawing.Point(250, 24)
        Me.txt_MarkH.Margin = New System.Windows.Forms.Padding(0)
        Me.txt_MarkH.Name = "txt_MarkH"
        Me.txt_MarkH.Size = New System.Drawing.Size(50, 22)
        Me.txt_MarkH.TabIndex = 26
        '
        'Label22
        '
        Me.Label22.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label22.Location = New System.Drawing.Point(203, 24)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(44, 24)
        Me.Label22.TabIndex = 24
        Me.Label22.Text = "高度"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_MarkW
        '
        Me.txt_MarkW.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_MarkW.Location = New System.Drawing.Point(150, 24)
        Me.txt_MarkW.Margin = New System.Windows.Forms.Padding(0)
        Me.txt_MarkW.Name = "txt_MarkW"
        Me.txt_MarkW.Size = New System.Drawing.Size(50, 22)
        Me.txt_MarkW.TabIndex = 25
        '
        'Label23
        '
        Me.Label23.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label23.Location = New System.Drawing.Point(103, 24)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(44, 24)
        Me.Label23.TabIndex = 23
        Me.Label23.Text = "寬度"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Btn_Size
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Btn_Size, 2)
        Me.Btn_Size.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Btn_Size.Location = New System.Drawing.Point(0, 24)
        Me.Btn_Size.Margin = New System.Windows.Forms.Padding(0)
        Me.Btn_Size.Name = "Btn_Size"
        Me.Btn_Size.Size = New System.Drawing.Size(100, 24)
        Me.Btn_Size.TabIndex = 22
        Me.Btn_Size.Text = "尺寸定義"
        Me.Btn_Size.UseVisualStyleBackColor = True
        '
        'txt_C4
        '
        Me.txt_C4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_C4.Location = New System.Drawing.Point(550, 48)
        Me.txt_C4.Margin = New System.Windows.Forms.Padding(0)
        Me.txt_C4.Name = "txt_C4"
        Me.txt_C4.Size = New System.Drawing.Size(50, 22)
        Me.txt_C4.TabIndex = 30
        '
        'Label7
        '
        Me.Label7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label7.Location = New System.Drawing.Point(503, 48)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(44, 24)
        Me.Label7.TabIndex = 25
        Me.Label7.Text = "最高"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_C3
        '
        Me.txt_C3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_C3.Location = New System.Drawing.Point(450, 48)
        Me.txt_C3.Margin = New System.Windows.Forms.Padding(0)
        Me.txt_C3.Name = "txt_C3"
        Me.txt_C3.Size = New System.Drawing.Size(50, 22)
        Me.txt_C3.TabIndex = 29
        '
        'lbl_C3
        '
        Me.lbl_C3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbl_C3.Location = New System.Drawing.Point(403, 48)
        Me.lbl_C3.Name = "lbl_C3"
        Me.lbl_C3.Size = New System.Drawing.Size(44, 24)
        Me.lbl_C3.TabIndex = 24
        Me.lbl_C3.Text = "白色"
        Me.lbl_C3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_C2
        '
        Me.txt_C2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txt_C2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_C2.Location = New System.Drawing.Point(350, 48)
        Me.txt_C2.Margin = New System.Windows.Forms.Padding(0)
        Me.txt_C2.Name = "txt_C2"
        Me.txt_C2.Size = New System.Drawing.Size(50, 22)
        Me.txt_C2.TabIndex = 28
        '
        'Label5
        '
        Me.Label5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label5.Location = New System.Drawing.Point(303, 48)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(44, 24)
        Me.Label5.TabIndex = 23
        Me.Label5.Text = "中位數"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_C1
        '
        Me.txt_C1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_C1.Location = New System.Drawing.Point(250, 48)
        Me.txt_C1.Margin = New System.Windows.Forms.Padding(0)
        Me.txt_C1.Name = "txt_C1"
        Me.txt_C1.Size = New System.Drawing.Size(50, 22)
        Me.txt_C1.TabIndex = 27
        '
        'Label3
        '
        Me.Label3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label3.Location = New System.Drawing.Point(203, 48)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 24)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "黑色"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_C0
        '
        Me.txt_C0.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_C0.Location = New System.Drawing.Point(150, 48)
        Me.txt_C0.Margin = New System.Windows.Forms.Padding(0)
        Me.txt_C0.Name = "txt_C0"
        Me.txt_C0.Size = New System.Drawing.Size(50, 22)
        Me.txt_C0.TabIndex = 26
        '
        'Label2
        '
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label2.Location = New System.Drawing.Point(103, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 24)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "最低"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Btn_AnalysisColor
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Btn_AnalysisColor, 2)
        Me.Btn_AnalysisColor.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Btn_AnalysisColor.Location = New System.Drawing.Point(0, 48)
        Me.Btn_AnalysisColor.Margin = New System.Windows.Forms.Padding(0)
        Me.Btn_AnalysisColor.Name = "Btn_AnalysisColor"
        Me.TableLayoutPanel1.SetRowSpan(Me.Btn_AnalysisColor, 3)
        Me.Btn_AnalysisColor.Size = New System.Drawing.Size(100, 72)
        Me.Btn_AnalysisColor.TabIndex = 19
        Me.Btn_AnalysisColor.Text = "分析區域色階"
        Me.Btn_AnalysisColor.UseVisualStyleBackColor = True
        '
        'txt_threshold
        '
        Me.txt_threshold.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_threshold.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_threshold.Location = New System.Drawing.Point(450, 72)
        Me.txt_threshold.Margin = New System.Windows.Forms.Padding(0)
        Me.txt_threshold.Name = "txt_threshold"
        Me.txt_threshold.Size = New System.Drawing.Size(50, 22)
        Me.txt_threshold.TabIndex = 36
        '
        'Label9
        '
        Me.Label9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label9.Location = New System.Drawing.Point(403, 72)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(44, 24)
        Me.Label9.TabIndex = 35
        Me.Label9.Text = "判別值"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_TrgColor
        '
        Me.txt_TrgColor.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txt_TrgColor.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_TrgColor.Location = New System.Drawing.Point(350, 72)
        Me.txt_TrgColor.Margin = New System.Windows.Forms.Padding(0)
        Me.txt_TrgColor.Name = "txt_TrgColor"
        Me.txt_TrgColor.Size = New System.Drawing.Size(50, 22)
        Me.txt_TrgColor.TabIndex = 33
        '
        'Label6
        '
        Me.Label6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label6.Font = New System.Drawing.Font("PMingLiU", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label6.Location = New System.Drawing.Point(300, 72)
        Me.Label6.Margin = New System.Windows.Forms.Padding(0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(50, 24)
        Me.Label6.TabIndex = 32
        Me.Label6.Text = "%比例值"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_Rate
        '
        Me.txt_Rate.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_Rate.Location = New System.Drawing.Point(250, 72)
        Me.txt_Rate.Margin = New System.Windows.Forms.Padding(0)
        Me.txt_Rate.Name = "txt_Rate"
        Me.txt_Rate.Size = New System.Drawing.Size(50, 22)
        Me.txt_Rate.TabIndex = 31
        Me.txt_Rate.Text = "50"
        '
        'TrackBar1
        '
        Me.TrackBar1.AutoSize = False
        Me.TrackBar1.BackColor = System.Drawing.Color.MidnightBlue
        Me.TableLayoutPanel1.SetColumnSpan(Me.TrackBar1, 2)
        Me.TrackBar1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TrackBar1.Location = New System.Drawing.Point(150, 72)
        Me.TrackBar1.Margin = New System.Windows.Forms.Padding(0)
        Me.TrackBar1.Maximum = 100
        Me.TrackBar1.Name = "TrackBar1"
        Me.TrackBar1.Size = New System.Drawing.Size(100, 24)
        Me.TrackBar1.TabIndex = 23
        Me.TrackBar1.TickStyle = System.Windows.Forms.TickStyle.None
        Me.TrackBar1.Value = 50
        '
        'Label8
        '
        Me.Label8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label8.Location = New System.Drawing.Point(103, 72)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(44, 24)
        Me.Label8.TabIndex = 22
        Me.Label8.Text = "區段"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Btn_BinarizingImage
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Btn_BinarizingImage, 2)
        Me.Btn_BinarizingImage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Btn_BinarizingImage.Location = New System.Drawing.Point(0, 120)
        Me.Btn_BinarizingImage.Margin = New System.Windows.Forms.Padding(0)
        Me.Btn_BinarizingImage.Name = "Btn_BinarizingImage"
        Me.TableLayoutPanel1.SetRowSpan(Me.Btn_BinarizingImage, 2)
        Me.Btn_BinarizingImage.Size = New System.Drawing.Size(100, 48)
        Me.Btn_BinarizingImage.TabIndex = 20
        Me.Btn_BinarizingImage.Text = "檢視二值化結果"
        Me.Btn_BinarizingImage.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Panel5.BackColor = System.Drawing.Color.Transparent
        Me.TableLayoutPanel1.SetColumnSpan(Me.Panel5, 10)
        Me.Panel5.Controls.Add(Me.RadBtn_Assign)
        Me.Panel5.Controls.Add(Me.RadBtn_Mid)
        Me.Panel5.Controls.Add(Me.RadBtn_Rate)
        Me.Panel5.Controls.Add(Me.RadBtn_Auto)
        Me.Panel5.Controls.Add(Me.Label10)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel5.Location = New System.Drawing.Point(103, 99)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(494, 18)
        Me.Panel5.TabIndex = 42
        '
        'RadBtn_Assign
        '
        Me.RadBtn_Assign.AutoSize = True
        Me.RadBtn_Assign.Dock = System.Windows.Forms.DockStyle.Left
        Me.RadBtn_Assign.Location = New System.Drawing.Point(309, 0)
        Me.RadBtn_Assign.Name = "RadBtn_Assign"
        Me.RadBtn_Assign.Size = New System.Drawing.Size(71, 18)
        Me.RadBtn_Assign.TabIndex = 42
        Me.RadBtn_Assign.Text = "預設數值"
        Me.RadBtn_Assign.UseVisualStyleBackColor = True
        '
        'RadBtn_Mid
        '
        Me.RadBtn_Mid.AutoSize = True
        Me.RadBtn_Mid.Dock = System.Windows.Forms.DockStyle.Left
        Me.RadBtn_Mid.Location = New System.Drawing.Point(218, 0)
        Me.RadBtn_Mid.Name = "RadBtn_Mid"
        Me.RadBtn_Mid.Size = New System.Drawing.Size(91, 18)
        Me.RadBtn_Mid.TabIndex = 39
        Me.RadBtn_Mid.Text = "中位數(偏亮)"
        Me.RadBtn_Mid.UseVisualStyleBackColor = True
        Me.RadBtn_Mid.Visible = False
        '
        'RadBtn_Rate
        '
        Me.RadBtn_Rate.AutoSize = True
        Me.RadBtn_Rate.Dock = System.Windows.Forms.DockStyle.Left
        Me.RadBtn_Rate.Location = New System.Drawing.Point(115, 0)
        Me.RadBtn_Rate.Name = "RadBtn_Rate"
        Me.RadBtn_Rate.Size = New System.Drawing.Size(103, 18)
        Me.RadBtn_Rate.TabIndex = 38
        Me.RadBtn_Rate.Text = "定比例值(偏暗)"
        Me.RadBtn_Rate.UseVisualStyleBackColor = True
        '
        'RadBtn_Auto
        '
        Me.RadBtn_Auto.AutoSize = True
        Me.RadBtn_Auto.Checked = True
        Me.RadBtn_Auto.Dock = System.Windows.Forms.DockStyle.Left
        Me.RadBtn_Auto.Location = New System.Drawing.Point(44, 0)
        Me.RadBtn_Auto.Name = "RadBtn_Auto"
        Me.RadBtn_Auto.Size = New System.Drawing.Size(71, 18)
        Me.RadBtn_Auto.TabIndex = 40
        Me.RadBtn_Auto.TabStop = True
        Me.RadBtn_Auto.Text = "自動篩選"
        Me.RadBtn_Auto.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label10.Location = New System.Drawing.Point(0, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(44, 18)
        Me.Label10.TabIndex = 41
        Me.Label10.Text = "解析"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label1.Font = New System.Drawing.Font("DFKai-SB", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(675, 23)
        Me.Label1.TabIndex = 43
        Me.Label1.Text = "Title"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl_Illustration
        '
        Me.lbl_Illustration.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lbl_Illustration.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.lbl_Illustration.Location = New System.Drawing.Point(0, 240)
        Me.lbl_Illustration.Margin = New System.Windows.Forms.Padding(0)
        Me.lbl_Illustration.Name = "lbl_Illustration"
        Me.lbl_Illustration.Size = New System.Drawing.Size(675, 20)
        Me.lbl_Illustration.TabIndex = 44
        Me.lbl_Illustration.Text = "Illustration"
        Me.lbl_Illustration.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button4
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Button4, 2)
        Me.Button4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button4.Location = New System.Drawing.Point(200, 144)
        Me.Button4.Margin = New System.Windows.Forms.Padding(0)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(100, 24)
        Me.Button4.TabIndex = 23
        Me.Button4.Text = "膨脹-->腐蝕"
        Me.Button4.UseVisualStyleBackColor = True
        Me.Button4.Visible = False
        '
        'Button3
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Button3, 2)
        Me.Button3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button3.Location = New System.Drawing.Point(200, 120)
        Me.Button3.Margin = New System.Windows.Forms.Padding(0)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(100, 24)
        Me.Button3.TabIndex = 22
        Me.Button3.Text = "腐蝕--> 膨脹"
        Me.Button3.UseVisualStyleBackColor = True
        Me.Button3.Visible = False
        '
        'Button2
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Button2, 2)
        Me.Button2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button2.Location = New System.Drawing.Point(100, 144)
        Me.Button2.Margin = New System.Windows.Forms.Padding(0)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(100, 24)
        Me.Button2.TabIndex = 21
        Me.Button2.Text = "膨脹(白)"
        Me.Button2.UseVisualStyleBackColor = True
        Me.Button2.Visible = False
        '
        'Button1
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Button1, 2)
        Me.Button1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button1.Location = New System.Drawing.Point(100, 120)
        Me.Button1.Margin = New System.Windows.Forms.Padding(0)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(100, 24)
        Me.Button1.TabIndex = 20
        Me.Button1.Text = "腐蝕(白)"
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TableLayoutPanel1.ColumnCount = 14
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Btn_SaveAsDefaultXML, 4, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Btn_BinarizingImage, 0, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Button1, 2, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Btn_AnalysisColor, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.txt_C0, 3, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label8, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TrackBar1, 3, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.txt_Rate, 5, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 4, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.txt_C1, 5, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 6, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.txt_TrgColor, 7, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 6, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label23, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label22, 4, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.txt_MarkH, 5, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.txt_MarkW, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Btn_DefineArea, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.txt_RecX, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.lbl_RecY, 4, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.txt_RecY, 5, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.lbl_RecW, 6, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.txt_RecW, 7, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.lbl_RecH, 8, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.txt_RecH, 9, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel5, 2, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Btn_Size, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.txt_threshold, 9, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label9, 8, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.lbl_C3, 8, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.txt_C3, 9, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label7, 10, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.txt_C4, 11, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.txt_C2, 7, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label11, 10, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.txt_Default, 11, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.btn_SaveCurrentRecipe, 0, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Btn_SaveAs, 2, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.Button2, 2, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Button3, 4, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Button4, 4, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Button5, 6, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Button6, 6, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 9, 5)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 23)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 9
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(675, 217)
        Me.TableLayoutPanel1.TabIndex = 46
        '
        'Btn_SaveAsDefaultXML
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Btn_SaveAsDefaultXML, 2)
        Me.Btn_SaveAsDefaultXML.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Btn_SaveAsDefaultXML.Location = New System.Drawing.Point(200, 168)
        Me.Btn_SaveAsDefaultXML.Margin = New System.Windows.Forms.Padding(0)
        Me.Btn_SaveAsDefaultXML.Name = "Btn_SaveAsDefaultXML"
        Me.TableLayoutPanel1.SetRowSpan(Me.Btn_SaveAsDefaultXML, 2)
        Me.Btn_SaveAsDefaultXML.Size = New System.Drawing.Size(100, 49)
        Me.Btn_SaveAsDefaultXML.TabIndex = 50
        Me.Btn_SaveAsDefaultXML.Text = "存成預設檔案"
        Me.Btn_SaveAsDefaultXML.UseVisualStyleBackColor = True
        Me.Btn_SaveAsDefaultXML.Visible = False
        '
        'Label11
        '
        Me.Label11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label11.Location = New System.Drawing.Point(503, 72)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(44, 24)
        Me.Label11.TabIndex = 44
        Me.Label11.Text = "預設值"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txt_Default
        '
        Me.txt_Default.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txt_Default.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_Default.Location = New System.Drawing.Point(550, 72)
        Me.txt_Default.Margin = New System.Windows.Forms.Padding(0)
        Me.txt_Default.Name = "txt_Default"
        Me.txt_Default.Size = New System.Drawing.Size(50, 22)
        Me.txt_Default.TabIndex = 45
        Me.txt_Default.Text = "100"
        '
        'btn_SaveCurrentRecipe
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.btn_SaveCurrentRecipe, 2)
        Me.btn_SaveCurrentRecipe.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btn_SaveCurrentRecipe.Location = New System.Drawing.Point(0, 168)
        Me.btn_SaveCurrentRecipe.Margin = New System.Windows.Forms.Padding(0)
        Me.btn_SaveCurrentRecipe.Name = "btn_SaveCurrentRecipe"
        Me.TableLayoutPanel1.SetRowSpan(Me.btn_SaveCurrentRecipe, 2)
        Me.btn_SaveCurrentRecipe.Size = New System.Drawing.Size(100, 49)
        Me.btn_SaveCurrentRecipe.TabIndex = 43
        Me.btn_SaveCurrentRecipe.Text = "儲存變更"
        Me.btn_SaveCurrentRecipe.UseVisualStyleBackColor = True
        Me.btn_SaveCurrentRecipe.Visible = False
        '
        'Btn_SaveAs
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Btn_SaveAs, 2)
        Me.Btn_SaveAs.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Btn_SaveAs.Location = New System.Drawing.Point(100, 168)
        Me.Btn_SaveAs.Margin = New System.Windows.Forms.Padding(0)
        Me.Btn_SaveAs.Name = "Btn_SaveAs"
        Me.TableLayoutPanel1.SetRowSpan(Me.Btn_SaveAs, 2)
        Me.Btn_SaveAs.Size = New System.Drawing.Size(100, 49)
        Me.Btn_SaveAs.TabIndex = 46
        Me.Btn_SaveAs.Text = "另存新檔"
        Me.Btn_SaveAs.UseVisualStyleBackColor = True
        Me.Btn_SaveAs.Visible = False
        '
        'Button5
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Button5, 2)
        Me.Button5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button5.Location = New System.Drawing.Point(300, 120)
        Me.Button5.Margin = New System.Windows.Forms.Padding(0)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(100, 24)
        Me.Button5.TabIndex = 48
        Me.Button5.Text = "二次腐蝕"
        Me.Button5.UseVisualStyleBackColor = True
        Me.Button5.Visible = False
        '
        'Button6
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Button6, 2)
        Me.Button6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button6.Location = New System.Drawing.Point(300, 144)
        Me.Button6.Margin = New System.Windows.Forms.Padding(0)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(100, 24)
        Me.Button6.TabIndex = 47
        Me.Button6.Text = "二次膨脹"
        Me.Button6.UseVisualStyleBackColor = True
        Me.Button6.Visible = False
        '
        'Panel1
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Panel1, 4)
        Me.Panel1.Controls.Add(Me.CheckBox1)
        Me.Panel1.Location = New System.Drawing.Point(453, 123)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(194, 18)
        Me.Panel1.TabIndex = 49
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.CheckBox1.Location = New System.Drawing.Point(0, 0)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(156, 18)
        Me.CheckBox1.TabIndex = 0
        Me.CheckBox1.Text = "顯示其他二值化分析功能"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'UC_AOIRecipe
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.lbl_Illustration)
        Me.Controls.Add(Me.Label1)
        Me.Name = "UC_AOIRecipe"
        Me.Size = New System.Drawing.Size(675, 260)
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents txt_RecH As System.Windows.Forms.TextBox
    Friend WithEvents lbl_RecH As System.Windows.Forms.Label
    Friend WithEvents txt_RecW As System.Windows.Forms.TextBox
    Friend WithEvents lbl_RecW As System.Windows.Forms.Label
    Friend WithEvents txt_RecY As System.Windows.Forms.TextBox
    Friend WithEvents lbl_RecY As System.Windows.Forms.Label
    Friend WithEvents txt_RecX As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Btn_DefineArea As System.Windows.Forms.Button
    Friend WithEvents txt_MarkH As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txt_MarkW As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Btn_Size As System.Windows.Forms.Button
    Friend WithEvents txt_C4 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txt_C3 As System.Windows.Forms.TextBox
    Friend WithEvents lbl_C3 As System.Windows.Forms.Label
    Friend WithEvents txt_C2 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txt_C1 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txt_C0 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Btn_AnalysisColor As System.Windows.Forms.Button
    Friend WithEvents txt_threshold As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txt_TrgColor As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txt_Rate As System.Windows.Forms.TextBox
    Friend WithEvents TrackBar1 As System.Windows.Forms.TrackBar
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Btn_BinarizingImage As System.Windows.Forms.Button
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents RadBtn_Auto As System.Windows.Forms.RadioButton
    Friend WithEvents RadBtn_Mid As System.Windows.Forms.RadioButton
    Friend WithEvents RadBtn_Rate As System.Windows.Forms.RadioButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lbl_Illustration As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents RadBtn_Assign As System.Windows.Forms.RadioButton
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents btn_SaveCurrentRecipe As System.Windows.Forms.Button
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txt_Default As System.Windows.Forms.TextBox
    Friend WithEvents Btn_SaveAs As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents Btn_SaveAsDefaultXML As System.Windows.Forms.Button

End Class
