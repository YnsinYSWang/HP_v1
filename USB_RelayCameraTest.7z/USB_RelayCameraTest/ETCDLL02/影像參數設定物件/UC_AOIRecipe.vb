﻿Imports System.Xml.Serialization
Imports System.Xml
Imports System.IO
Imports ETCDLL02.EtcAOIRecipe
Imports ETCDLL02.EtcFunction
Imports ETCDLL02.Class_ImageDeal
Imports ETCDLL02.EtcPublicObject

Public Class UC_AOIRecipe

    Public Event GetCheckAreaEvent(ByRef Sender As System.Object) ' 取得檢測區域是建
    Public Event GetMarkSizeEvent(ByRef Sender As System.Object) ' 取得Mark尺寸事件
    Public Event GetColorDistribution(ByRef Sender As System.Object, ByVal rec As Rectangle)  ' 取得色階分布事件
    Public Event GetBinarizingImage(ByRef Sender As System.Object, ByVal Threshold As Integer, ByVal rec As Rectangle, ByVal DealType As eAnalysisType)  ' 二值化事件
    Private _Recipe As New cls_AOIRecipe
    Public Property ObjName As String = "AOISetup"
    Private RecipeFileFolder As String = My.Application.Info.DirectoryPath & "\AOIRecipe"
    Private RecipeFileName As String
    Private RecipeFileTotalName As String   ' 預設的Recipe XML 檔案名稱
    Private CurrentXMLTotalName As String  ' 目前的Recipe XML 檔案名稱

    Public WriteOnly Property ObjectTitle As String
        Set(ByVal value As String)
            Label1.Text = value
        End Set
    End Property

    Public ReadOnly Property XMLRecipeFileTotalName As String
        Get
            Return RecipeFileTotalName
        End Get
    End Property
    Public ReadOnly Property XMLRecipeFolder As String
        Get
            Return RecipeFileFolder
        End Get
    End Property
    Public ReadOnly Property XMLRecipeFileName As String
        Get
            Return RecipeFileName
        End Get
    End Property

    Public ReadOnly Property Recipe As cls_AOIRecipe
        Get
            Return _Recipe
        End Get
    End Property

    Public Sub New(ByVal Name As String, ByVal Folder As String)
        ' 此為設計工具所需的呼叫。
        InitializeComponent()
        ' 在 InitializeComponent() 呼叫之後加入任何初始設定。
        ObjName = Name
        Dim NewFolder As String = Folder.Trim
        RecipeFileFolder = NewFolder
        RecipeFileName = ObjName & ".xml"
        Dim lastch As String = NewFolder.Substring(NewFolder.Length - 1, 1)
        If lastch = "\" Then RecipeFileFolder = NewFolder.Substring(0, NewFolder.Length - 1)
        RecipeFileTotalName = RecipeFileFolder & "\" & RecipeFileName
        CurrentXMLTotalName = RecipeFileTotalName ' 指定目前 XML 檔案全名
        If FolderExist(RecipeFileFolder) = False Then CreatDirectory(RecipeFileFolder)
    End Sub
    Private Sub UC_RecipeSetup_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        GetDefaultRecipleXML()  ' 從預設的XML檔案
    End Sub

    ' 自動從視窗中取得設定 --> 計算門檻  
    Private Sub AutoUpdateRecipeFromWindow()
        RefreshRecipeFromWindows()
        RefreshThreshold()
    End Sub
    ' 更新門檻值顯示視窗, 包含重算門檻 並寫入 _Recipe的門檻設定
    Public Sub RefreshThreshold()
        ' 先載入設定
        RefreshRecipeFromWindows()
        ' 先建立色階結構
        Dim ColorDist As New str_Colordistribution
        ColorDist.V4_min = Val(txt_C0.Text)
        ColorDist.V3_down = Val(txt_C1.Text)
        ColorDist.V2_bwlevel = Val(txt_C2.Text)
        ColorDist.中位數 = Val(txt_C2.Text)
        ColorDist.V1_Up = Val(txt_C3.Text)
        ColorDist.V0_Max = Val(txt_C4.Text)
        ' 計算門檻
        Dim Rtn As cls_ReturnValue = GetThreshold(ColorDist, _Recipe)
        If Rtn.ErrorOccure Then
            MsgBox(Rtn.ErrorString)
            lbl_Illustration.Text = Rtn.ErrorString
        End If
        lbl_Illustration.Text = Rtn.Illustration & " Threshold = " & Rtn.ReturnValue(0) & ", Rate = " & Rtn.ReturnValue(1)
        txt_threshold.Text = Rtn.ReturnValue(0)
        _Recipe.AssignedThreshold = Rtn.ReturnValue(0)
    End Sub
    Private Sub RefreshRecipeFromWindows()  ' 從視窗設 更新_Recipe 設定值
        _Recipe = GetRecipeFromWindows()
    End Sub




#Region "XML Recipe檔案讀取與寫入"
#Region "XML Recipe檔案讀取"
    '  從指定XML檔案讀入 Recipe
    Public Sub UpdateXMLRecipleToWindow(ByVal XMLFile As String)
        Try
            If FileExist(XMLFile) = False Then
                Exit Sub
            End If
            Dim serializer As New XmlSerializer(GetType(cls_AOIRecipe))
            Dim fs As New FileStream(XMLFile, FileMode.Open)
            Dim NewRecipe As cls_AOIRecipe = CType(serializer.Deserialize(fs), cls_AOIRecipe)
            UpDateRecipeWindows(NewRecipe)
            CurrentXMLTotalName = XMLFile
            fs.Close()
            AutoUpdateRecipeFromWindow()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub
    ' 取得預設的XML
    Private Sub GetDefaultRecipleXML()
        Try
            If FileExist(RecipeFileTotalName) = False Then
                Exit Sub
            End If
            UpdateXMLRecipleToWindow(RecipeFileTotalName)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub
#End Region
#Region "XML Recipe檔案寫入"
    ' 將設定存到指定檔  會先新更Recipe
    Private Sub SaveSetupToXML(ByVal TFilaName As String)
        Try
            AutoUpdateRecipeFromWindow()
            Dim serializer As New XmlSerializer(GetType(cls_AOIRecipe))
            Dim writer As New StreamWriter(TFilaName)
            serializer.Serialize(writer, _Recipe)
            writer.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub
    ' 目前設定另存XML檔案
    Public Sub SaveRecipeAs()
        Try
            Dim TTFileName As String = MySaveFileDialog("xml", RecipeFileFolder, , "XML File Name Select")
            If TTFileName = "" Then Exit Sub
            SaveSetupToXML(TTFileName)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub
    ' 將Recipe 存成預設XML檔案
    Private Sub SaveDefaultRecipleXML()
        SaveSetupToXML(RecipeFileTotalName)
    End Sub
    ' 將Recipe 存到目前的XML檔案 會新更Recipe
    Private Sub SaveCurrentRecipleToXML()
        If CurrentXMLTotalName.Trim <> "" Then SaveSetupToXML(CurrentXMLTotalName)
    End Sub
#End Region
    ' 更新Recipe 設定到視窗
    Private Sub UpDateRecipeWindows(ByVal TRecipe As cls_AOIRecipe)
        With TRecipe
            txt_RecX.Text = .ChkArea_X
            txt_RecY.Text = .ChkArea_Y
            txt_RecW.Text = .ChkArea_W
            txt_RecH.Text = .ChkArea_H
            txt_MarkW.Text = .Mark_W
            txt_MarkH.Text = .Mark_H
            txt_threshold.Text = .AssignedThreshold
            txt_Default.Text = .DefaultThreshold
            TrackBar1.Value = .RateValue
            txt_Rate.Text = .RateValue
            RadBtn_Assign.Checked = .ThresholdType = 3
            RadBtn_Auto.Checked = .ThresholdType = 2
            RadBtn_Mid.Checked = .ThresholdType = 1
            RadBtn_Rate.Checked = .ThresholdType = 0
        End With
    End Sub
    ' 從視窗取得Recipe 設定
    Private Function GetRecipeFromWindows() As cls_AOIRecipe
        Dim Rtn As New cls_AOIRecipe
        With Rtn
            .ChkArea_X = Val(txt_RecX.Text)
            .ChkArea_Y = Val(txt_RecY.Text)
            .ChkArea_W = Val(txt_RecW.Text)
            .ChkArea_H = Val(txt_RecH.Text)
            .Mark_W = Val(txt_MarkW.Text)
            .Mark_H = Val(txt_MarkH.Text)
            .AssignedThreshold = Val(txt_threshold.Text)
            .DefaultThreshold = Val(txt_Default.Text)
            .RateValue = TrackBar1.Value
            If RadBtn_Assign.Checked Then .ThresholdType = eThresholdType.指定值
            If RadBtn_Auto.Checked Then .ThresholdType = eThresholdType.自動模式
            If RadBtn_Mid.Checked Then .ThresholdType = eThresholdType.中位數
            If RadBtn_Rate.Checked Then .ThresholdType = eThresholdType.自訂比例
        End With
        Return Rtn
    End Function
#End Region

    Private Sub Btn_DefineArea_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_DefineArea.Click
        RaiseEvent GetCheckAreaEvent(Me)  ' 取得檢測區域是建
    End Sub
    ' 多載1 : 外界傳回來檢查區域
    Public Sub UpDateCheckArea(ByVal rec As Rectangle)
        txt_RecX.Text = rec.X
        txt_RecY.Text = rec.Y
        txt_RecW.Text = rec.Width
        txt_RecH.Text = rec.Height
        SaveCurrentRecipleToXML() '  將Recipe 存到目前的XML檔案 會新更Recipe
    End Sub
    ' 多載2 : 外界傳回來檢查區域
    Public Sub UpDateCheckArea(ByVal X As Integer, ByVal Y As Integer, ByVal Width As Integer, ByVal Height As Integer)
        Dim rec As New Rectangle(X, Y, Width, Height)
        UpDateCheckArea(rec)
    End Sub

    Private Sub Btn_Size_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Size.Click
        RaiseEvent GetMarkSizeEvent(Me) ' 取得Mark尺寸事件
    End Sub
    ' 多載1 : 外界傳回來Mark Size
    Public Sub UpDateMarkSize(ByVal Width As Integer, ByVal Height As Integer)
        txt_MarkW.Text = Width
        txt_MarkH.Text = Height
        SaveCurrentRecipleToXML()
    End Sub
    ' 多載2 : 外界傳回來Mark Size
    Public Sub UpDateMarkSize(ByVal rec As Rectangle)
        UpDateMarkSize(rec.Width, rec.Height)
    End Sub
    Private Sub Btn_AnalysisColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_AnalysisColor.Click
        RaiseEvent GetColorDistribution(Me, GetRectangle)  ' 取得色階分布事件()
    End Sub
    ' 外界傳回來彩色分布
    Public Sub UpDateColorDistribute(ByVal ColorDist As str_Colordistribution)
        Dim AllData(4) As Byte
        With ColorDist
            txt_C0.Text = .V4_min
            txt_C1.Text = .V3_down
            txt_C2.Text = .中位數
            txt_C3.Text = .V1_Up
            txt_C4.Text = .V0_Max
        End With
        RefreshColorValue(TrackBar1.Value)
        SaveCurrentRecipleToXML() '  將Recipe 存到目前的XML檔案 會新更Recipe
    End Sub
    ' Rate : 0~100 由比例計算門檻值
    Public Sub RefreshColorValue(ByVal Rate As Double)
        Dim CRate As Double = Rate / 100
        Dim V0 As Double = Val(txt_C0.Text)
        Dim V1 As Double = Val(txt_C4.Text)
        Dim Value As Double = (V1 - V0) * CRate + V0
        txt_TrgColor.Text = CInt(Value)
    End Sub
    ' 取得方塊
    Private Function GetRectangle() As Rectangle
        Dim X As Integer = Val(txt_RecX.Text)
        Dim Y As Integer = Val(txt_RecY.Text)
        Dim W As Integer = Val(txt_RecW.Text)
        Dim H As Integer = Val(txt_RecH.Text)
        Dim rec As New Rectangle(X, Y, W, H)
        Return rec
    End Function
    ' 拉Scroll
    Private Sub TrackBar1_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TrackBar1.Scroll
        Dim Rate As Integer = TrackBar1.Value
        txt_Rate.Text = Rate
        _Recipe.RateValue = Rate
        RefreshColorValue(Rate)   ' Rate : 0~100
        RefreshThreshold() '   更新門檻值顯示視窗
        SaveCurrentRecipleToXML() '  將Recipe 存到目前的XML檔案 會新更Recipe
    End Sub

    ' RadioBotton Select Change
    Private Sub RadBtn_Rate_Click(ByVal sender As Object, ByVal e As System.EventArgs) _
        Handles RadBtn_Rate.Click, RadBtn_Mid.Click, RadBtn_Auto.Click, RadBtn_Assign.Click
        SaveCurrentRecipleToXML() '  將Recipe 存到目前的XML檔案 會新更Recipe
    End Sub
    Private Sub txt_Rate_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txt_Rate.KeyUp
        'If e.KeyCode = Keys.Enter Then
        Dim Rate As Integer = Val(txt_Rate.Text)
        If Rate > TrackBar1.Maximum Or Rate < TrackBar1.Minimum Then
            MsgBox("輸入數值超出範圍")
            txt_Rate.Text = TrackBar1.Value
            Exit Sub
        End If
        TrackBar1.Value = Rate
        SaveCurrentRecipleToXML() '  將Recipe 存到目前的XML檔案 會新更Recipe
        'End If
    End Sub

    ' 二值化分析
    Private Sub Btn_BinarizingImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_BinarizingImage.Click
        RefreshThreshold() ' 更新門檻值
        Dim Threshold As Integer = Val(txt_threshold.Text) ' 取得門檻值
        Dim rec = GetRectangle()
        RaiseEvent GetBinarizingImage(Me, Threshold, rec, eAnalysisType.二值化處理)
    End Sub
    ' 腐蝕處理
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        RefreshThreshold() ' 更新門檻值
        Dim Threshold As Integer = Val(txt_threshold.Text) ' 取得門檻值
        Dim rec = GetRectangle()
        RaiseEvent GetBinarizingImage(Me, Threshold, rec, eAnalysisType.白色腐蝕處理)
    End Sub
    ' 膨脹處理
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        RefreshThreshold() ' 更新門檻值
        Dim Threshold As Integer = Val(txt_threshold.Text) ' 取得門檻值
        Dim rec = GetRectangle()
        RaiseEvent GetBinarizingImage(Me, Threshold, rec, eAnalysisType.白色膨脹處理)
    End Sub
    ' 腐蝕再膨脹
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        RefreshThreshold() ' 更新門檻值
        Dim Threshold As Integer = Val(txt_threshold.Text) ' 取得門檻值
        Dim rec = GetRectangle()
        RaiseEvent GetBinarizingImage(Me, Threshold, rec, eAnalysisType.白色腐蝕再膨脹)
    End Sub
    ' 膨脹再腐蝕
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        RefreshThreshold() ' 更新門檻值
        Dim Threshold As Integer = Val(txt_threshold.Text) ' 取得門檻值
        Dim rec = GetRectangle()
        RaiseEvent GetBinarizingImage(Me, Threshold, rec, eAnalysisType.白色膨脹再腐蝕)
    End Sub
    ' 二次腐蝕
    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        RefreshThreshold() ' 更新門檻值
        Dim Threshold As Integer = Val(txt_threshold.Text) ' 取得門檻值
        Dim rec = GetRectangle()
        RaiseEvent GetBinarizingImage(Me, Threshold, rec, eAnalysisType.二次白色腐蝕處理)
    End Sub
    ' 二次膨脹
    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        RefreshThreshold() ' 更新門檻值
        Dim Threshold As Integer = Val(txt_threshold.Text) ' 取得門檻值
        Dim rec = GetRectangle()
        RaiseEvent GetBinarizingImage(Me, Threshold, rec, eAnalysisType.二次白色膨脹處理)
    End Sub


    ' Save Current Recipe 
    Private Sub btn_SaveCurrentRecipe_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_SaveCurrentRecipe.Click
        SaveCurrentRecipleToXML()
    End Sub
    ' Save Recipe as New XML
    Private Sub Btn_SaveAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_SaveAs.Click
        SaveRecipeAs()
    End Sub
    ' Save Recipe as Default XML
    Private Sub Btn_SaveAsDefaultXML_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_SaveAsDefaultXML.Click
        SaveDefaultRecipleXML()
    End Sub
    ' txt_Default 建按下
    Private Sub txt_Default_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txt_Default.KeyUp
        SaveCurrentRecipleToXML()
    End Sub

    ' 是否顯示其他二值化分析功能
    Private Sub CheckBox1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox1.Click
        Dim Visible As Boolean = CheckBox1.Checked
        Button1.Visible = Visible
        Button2.Visible = Visible
        Button3.Visible = Visible
        Button4.Visible = Visible
        Button5.Visible = Visible
        Button6.Visible = Visible
    End Sub

    Private Sub txt_Rate_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Rate.TextChanged

    End Sub
End Class
