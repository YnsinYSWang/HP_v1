﻿Imports ETCDLL02.EtcFunction

Public Class UC_MsgWindow

    Private _TitleStr As String = "Message Windows"
    Private _TitleStrColor As Color = Color.Navy
    Private _TitleBackColor As Color = Color.LightCyan
    Private _LogStrColor As Color = Color.Navy

    Public Property LogStrColor() As Color
        Get
            Return _LogStrColor
        End Get
        Set(ByVal value As Color)
            _LogStrColor = value
            LBox_Log.ForeColor = value
        End Set
    End Property

    Public Property TitleStr() As String
        Get
            Return _TitleStr
        End Get
        Set(ByVal value As String)
            _TitleStr = value
            Label1.Text = _TitleStr
        End Set
    End Property
    Public Property TitleStrColor() As Color
        Get
            Return _TitleStrColor
        End Get
        Set(ByVal value As Color)
            _TitleStrColor = value
            Label1.ForeColor = value
        End Set
    End Property
    Public Property TitleBackColor As Color
        Get
            Return _TitleBackColor
        End Get
        Set(ByVal value As Color)
            _TitleBackColor = value
            Label1.BackColor = value
        End Set
    End Property
    Public Property MaxLogCount As Integer = 20

    Public Sub AddLog(ByVal SStr As String)
        LBox_Log.Items.Add(SStr)
        If LBox_Log.Items.Count > MaxLogCount Then
            LBox_Log.Items.RemoveAt(0)
        End If
        LBox_Log.SelectedIndex = LBox_Log.Items.Count - 1
        lb_LastLog.Text = SStr
        ToolTip1.SetToolTip(LBox_Log, SStr)
    End Sub

    Private Sub UC_MsgWindow_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        LBox_Log.Items.Clear()
    End Sub

    Private Sub ClearLog()
        LBox_Log.Items.Clear()
    End Sub

    Private Sub ClearMessageToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearMessageToolStripMenuItem.Click
        ClearLog()
    End Sub


    Private Sub SaveMessageAsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveMessageAsToolStripMenuItem.Click
        SaveListData()
    End Sub

    Public Sub SaveListData()
        If LBox_Log.Items.Count = 0 Then
            Exit Sub
        End If
        Dim FileName As String = MyOpenFileDialog("txt")
        If FileName = "" Then Exit Sub
        Try
            Dim SaveStr As String = ""
            For i As Integer = 0 To LBox_Log.Items.Count - 1
                'Dim SepCh As String = IIf(i = LBox_Log.Items.Count - 1, "", vbCrLf)
                SaveStr &= LBox_Log.Items(i).ToString & vbCrLf
            Next
            My.Computer.FileSystem.WriteAllText(FileName, SaveStr, True)
        Catch ex As Exception
            MsgBox("ListDataSave Error : " & ex.Message)
        End Try
    End Sub

End Class
