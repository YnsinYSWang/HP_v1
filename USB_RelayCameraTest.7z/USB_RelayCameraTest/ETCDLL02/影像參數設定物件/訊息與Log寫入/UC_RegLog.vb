﻿Imports ETCDLL02.EtcFunction

Public Class UC_RegLog

    Private GeMsg As New UC_MsgWindow
    Private ALMsg As New UC_MsgWindow
    Private ERMsg As New UC_MsgWindow

    Private _DftLogPath As String = My.Application.Info.DirectoryPath & "\Log_"   ' Recipe 儲存目錄
    Private _DefaultLogFileName As String = "ETCLog"  '預設Log 檔名
    Private _MaxLogCount As Integer = 50
    Private _GeneralMsgVisible As Boolean
    Private _AlarmMsgVisible As Boolean
    Private _ErrorMsgVisible As Boolean
    Private _ArrangementType As eArrangement = eArrangement.Verticle

    ' 訊息格式
    Public Enum eMsgType As Integer
        GeneralMsg = 0 ' 一般訊息
        AlarmMsd ' 警報訊息
        ErrorMsg ' 錯誤訊息
    End Enum
    ' 排列格式
    Public Enum eArrangement As Integer
        Verticle = 0 ' 垂直
        Horizontal ' 水平
    End Enum

#Region "屬性"

    Public Property LogFileNameAppandDay As Boolean = True ' Log 檔案是否要加上日期 (如果是, 每天都會變更 Log 檔名
    Public Property LogDateAppandTime As Boolean = True ' Log 字串是否要加上日期時間
    ' Log顯示視窗最多顯示筆數, 預設值50
    Public Property MaxLogCount As Integer
        Get
            Return _MaxLogCount
        End Get
        Set(ByVal value As Integer)
            _MaxLogCount = value
            GeMsg.MaxLogCount = value
            ALMsg.MaxLogCount = value
            ERMsg.MaxLogCount = value
        End Set
    End Property
    Public Property LogFileName(Optional ByVal LogType As eMsgType = eMsgType.GeneralMsg) As String  ' 取得/設定 Log 檔案名稱
        Get ' 取得 Log 檔案名稱 例如 "ETCLog_20200703.log"
            Dim subname As String = IIf(Not LogFileNameAppandDay, "", "_" & Now.ToString("yyyyMMdd"))
            If LogType = eMsgType.AlarmMsd Then subname &= "_AL"
            If LogType = eMsgType.ErrorMsg Then subname &= "_ER"
            Return _DefaultLogFileName & subname & ".log"
        End Get
        Set(ByVal value As String)   ' 設定  Log 檔案名稱 例如 "AuoLog"
            _DefaultLogFileName = value
        End Set
    End Property
    ' 取得Log 檔案名稱加路徑
    Public ReadOnly Property LogFileTotalName(Optional ByVal LogType As eMsgType = eMsgType.GeneralMsg) As String
        Get
            Return DefaultLogPath & "\" & LogFileName(LogType)
        End Get
    End Property
    Public ReadOnly Property DefaultLogPath As String ' 儲存Log 的資料夾
        Get
            Return _DftLogPath & "\Log"
        End Get
    End Property
    Public Property GeneralMsgVisible As Boolean    ' 是否顯示一般訊息視窗
        Get
            Return _GeneralMsgVisible
        End Get
        Set(ByVal value As Boolean)
            If value <> _GeneralMsgVisible Then
                _GeneralMsgVisible = value
                RefreshShowWindows()
            End If
        End Set
    End Property
    Public Property AlarmMsgVisible As Boolean    ' 是否顯示一般訊息視窗
        Get
            Return _AlarmMsgVisible
        End Get
        Set(ByVal value As Boolean)
            If value <> _AlarmMsgVisible Then
                _AlarmMsgVisible = value
                RefreshShowWindows()
            End If
        End Set
    End Property
    Public Property ErrorMsgVisible As Boolean    ' 是否顯示一般訊息視窗
        Get
            Return _ErrorMsgVisible
        End Get
        Set(ByVal value As Boolean)
            If value <> _ErrorMsgVisible Then
                _ErrorMsgVisible = value
                RefreshShowWindows()
            End If
        End Set
    End Property
    Public Property ArrangementType As eArrangement ' 個視窗排列方式
        Get
            Return _ArrangementType
        End Get
        Set(ByVal value As eArrangement)
            If _ArrangementType <> value Then
                _ArrangementType = value
                RefreshShowWindows()
            End If
        End Set
    End Property

#End Region


    Public Sub New()

        ' 此為設計工具所需的呼叫。
        InitializeComponent()

        ' 在 InitializeComponent() 呼叫之後加入任何初始設定。

    End Sub


    '  ObjectName 最好給為一的名字否則很容易彼此覆寫
    Public Sub New(ByVal ObjectName As String, Optional ByVal ShowGeneralMsg As Boolean = True, _
                                  Optional ByVal ShowAlarmMsd As Boolean = True, Optional ByVal ShowErrorMsg As Boolean = True)

        ' 此為設計工具所需的呼叫。
        InitializeComponent()

        ' 在 InitializeComponent() 呼叫之後加入任何初始設定。
        _DefaultLogFileName = My.Settings.DefaultLogFileName
        _DftLogPath &= ObjectName
        _GeneralMsgVisible = ShowGeneralMsg
        _AlarmMsgVisible = ShowAlarmMsd
        _ErrorMsgVisible = ShowErrorMsg
    End Sub

    ' 更新顯示視窗 水平
    Private Sub Arragement_H()
        Dim Gap As Integer = 2
        If Me.Width < 5 Or Me.Height < 5 Then Exit Sub
        Dim ShowCount As Integer = 0
        GeMsg.Visible = _GeneralMsgVisible
        ALMsg.Visible = _AlarmMsgVisible
        ERMsg.Visible = _ErrorMsgVisible
        If _GeneralMsgVisible Then ShowCount += 1
        If _AlarmMsgVisible Then ShowCount += 1
        If _ErrorMsgVisible Then ShowCount += 1
        If ShowCount = 0 Then
            Exit Sub
        End If
        Dim GapCount As Integer = ShowCount + 1
        Dim EatcWidth As Integer = (Me.Width - GapCount * Gap) / ShowCount
        Dim EatcHeight As Integer = (Me.Height - StatusStrip1.Height - 2 * Gap)
        'GeMsg.Height = EatcHeight
        'GeMsg.Width = Me.Width - 2 * Gap
        'ALMsg.Width = GeMsg.Width
        'ERMsg.Width = GeMsg.Width
        Dim Left As Integer = Gap
        With GeMsg
            If .Visible Then
                .Height = EatcHeight
                .Width = EatcWidth
                .Left = Left
                .Top = Gap
                .BringToFront()
                Left = .Left + .Width + Gap
            End If
        End With
        With ALMsg
            If .Visible Then
                .Height = EatcHeight
                .Width = EatcWidth
                .Left = Left
                .Top = Gap
                .BringToFront()
                Left = .Left + .Width + Gap
            End If
        End With
        With ERMsg
            If .Visible Then
                .Height = EatcHeight
                .Width = EatcWidth
                .Left = Left
                .Top = Gap
                .BringToFront()
                Left = .Left + .Width + Gap
            End If
        End With
    End Sub

    ' 更新顯示視窗 垂直
    Private Sub Arragement_V()
        Dim Gap As Integer = 2
        If Me.Width < 5 Or Me.Height < 5 Then Exit Sub
        Dim ShowCount As Integer = 0
        GeMsg.Visible = _GeneralMsgVisible
        ALMsg.Visible = _AlarmMsgVisible
        ERMsg.Visible = _ErrorMsgVisible
        If _GeneralMsgVisible Then ShowCount += 1
        If _AlarmMsgVisible Then ShowCount += 1
        If _ErrorMsgVisible Then ShowCount += 1
        If ShowCount = 0 Then
            Exit Sub
        End If
        Dim GapCount As Integer = ShowCount + 1
        Dim EatcHeight As Integer = (Me.Height - StatusStrip1.Height - GapCount * Gap) / ShowCount
        GeMsg.Width = Me.Width - 2 * Gap
        ALMsg.Width = GeMsg.Width
        ERMsg.Width = GeMsg.Width
        Dim Top As Integer = Gap
        With ERMsg
            If .Visible Then
                .Left = Gap
                .Top = Top
                .Height = EatcHeight
                .BringToFront()
                Top = .Top + .Height + Gap
            End If
        End With
        With ALMsg
            If .Visible Then
                .Left = Gap
                .Top = Top
                .Height = EatcHeight
                .BringToFront()
                Top = .Top + .Height + Gap
            End If
        End With
        With GeMsg
            If .Visible Then
                .Left = Gap
                .Top = Top
                .Height = EatcHeight
                .BringToFront()
                Top = .Top + .Height + Gap
            End If
        End With
    End Sub
    ' 更新顯示視窗 
    Private Sub RefreshShowWindows()
        If _ArrangementType = eArrangement.Verticle Then
            Arragement_V()
        Else
            Arragement_H()
        End If
    End Sub

    ' 寫 Log 到檔案
    Public Sub WriteLog(ByVal LogStr As String, ByVal LogType As eMsgType)
        If LogStr.Contains(vbCrLf) = False Then LogStr &= vbCrLf
        Dim TotalLogName As String = LogFileTotalName(LogType)
        If Not FolderExist(DefaultLogPath) Then CreatDirectory(DefaultLogPath)
        Dim HeadStr As String = IIf(Not LogDateAppandTime, "", Now.ToString("HH:mm:ss") & ">>")
        Dim WrtStr As String = HeadStr & LogStr
        My.Computer.FileSystem.WriteAllText(TotalLogName, WrtStr, True)
    End Sub
    ' 顯示Log
    Public Sub ShowLog(ByVal LogStr As String, ByVal LogType As eMsgType)
        Dim HeadStr As String = IIf(Not LogDateAppandTime, "", Now.ToString("HH:mm:ss") & ">>")
        Dim WrtStr As String = HeadStr & LogStr
        ToolStripStatusLabel1.Text = WrtStr

        Select Case LogType
            Case eMsgType.GeneralMsg
                GeMsg.AddLog(WrtStr)
                ToolStripStatusLabel1.ForeColor = GeMsg.LogStrColor
            Case eMsgType.AlarmMsd
                ALMsg.AddLog(WrtStr)
                ToolStripStatusLabel1.ForeColor = ALMsg.LogStrColor
            Case eMsgType.ErrorMsg
                ERMsg.AddLog(WrtStr)
                ToolStripStatusLabel1.ForeColor = ERMsg.LogStrColor
        End Select
    End Sub

    Private Sub UC_RegLog_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        With GeMsg
            .TitleStr = "General Message"
            .TitleBackColor = Color.Cyan
            .TitleStrColor = Color.Navy
            .LogStrColor = Color.Navy
        End With
        With ALMsg
            .TitleStrColor = Color.White
            .TitleBackColor = Color.DarkOrange
            .LogStrColor = Color.DarkOrange
            .TitleStr = "Alarm Message"
        End With
        With ERMsg
            .TitleStr = "Error Message"
            .TitleStrColor = Color.Yellow
            .TitleBackColor = Color.Red
            .LogStrColor = Color.Red
        End With
        Me.Controls.Add(GeMsg)
        Me.Controls.Add(ALMsg)
        Me.Controls.Add(ERMsg)
    End Sub

    Private Sub UC_RegLog_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        RefreshShowWindows()
    End Sub

End Class
