﻿Imports System.Xml.Serialization
Imports System.Xml
Imports System.IO

Imports ETCDLL02.EtcPublicObject
Imports ETCDLL02.Class_ImageDeal
Imports ETCDLL02.EtcFunction

Public Class EtcAOIRecipe

    Public Enum ePatternColor As Integer
        Black = 0
        White
    End Enum
    Public Enum ePatternEnv As Integer
        Isolated = 0  ' 與周圍隔絕
        Linked ' 與
    End Enum

    ' 這是要存到XML的類別, 裡面包含學習的Recipe 設定 與學習到的結果 LearnedData
    Public Class cls_MyPatternMatch
        Public Recipe As cls_LearningRecipe
        Public LearnData As cls_LearningData
    End Class

    Public Class cls_LearningRecipe
        ' -----以下資料將存入 XML 檔案  ---------
        Inherits cls_AOIRecipe
        Public LearningArea_X As Integer  ' 檢查區域的 X 座標
        Public LearningArea_Y As Integer  ' 檢查區域的 Y 座標
        Public LearningArea_W As Integer  ' 檢查區域寬
        Public LearningArea_H As Integer  ' 檢查區域高
        Public PatternColor As ePatternColor  ' Pattern 顏色
    End Class

    ' 紀錄學習結果 包含Pattern 的圖型 , 特徵 以及 色階分布
    Public Class cls_LearningData
        Public PatternWidth As Integer  ' Pattern 寬度
        Public Patternheight As Integer  ' Pattern 高度
        ' HLine最長水平線  此線不能與小範圍搜索區域接觸, 會失真, 不一定是真實長度, 若長度為0 代表所有的線都與小範圍搜索區域接觸
        ' VLine最長垂直線 此線不能與小範圍搜索區域接觸, 會失真, 不一定是真實長度, 若長度為0 代表所有的線都與小範圍搜索區域接觸
        ' 如果 HLine 與 VLine 都是零 可能是角落特徵
        Public LB_Exist As Boolean ' 左邊界是否存在 存在待標邊外是隔絕的, 不存在代表是外為區域的延伸
        Public LB_Length As Integer ' 從左側蒐尋過來的邊界長度(最長線段)
        Public LB_X As Integer ' 從左側蒐尋過來的邊界 X 座標
        Public LB_Y0 As Integer ' 從左側蒐尋過來的邊界 Y0 座標
        Public LB_Y1 As Integer ' 從左側蒐尋過來的邊界 Y1 座標
        Public RB_Exist As Boolean ' 右邊界是否存在 存在待標邊外是隔絕的
        Public RB_Length As Integer ' 從右側蒐尋過來的邊界長度(最長線段)
        Public RB_X As Integer ' 從右側蒐尋過來的邊界 X 座標
        Public RB_Y0 As Integer ' 從右側蒐尋過來的邊界 Y0 座標
        Public RB_Y1 As Integer ' 從右側蒐尋過來的邊界 Y1 座標
        Public UB_Exist As Boolean ' 上邊界是否存在 存在待標邊外是隔絕的
        Public UB_Length As Integer ' 從上側蒐尋過來的邊界長度(最長線段)
        Public UB_Y As Integer ' 從上側蒐尋過來的邊界 Y 座標
        Public UB_X0 As Integer ' 從上側蒐尋過來的邊界 X0 座標
        Public UB_X1 As Integer ' 從上側蒐尋過來的邊界 X1 座標
        Public DB_Exist As Boolean ' 下邊界是否存在 存在待標邊外是隔絕的
        Public DB_Length As Integer ' 從下側蒐尋過來的邊界長度(最長線段)
        Public DB_Y As Integer ' 從下側蒐尋過來的邊界 Y 座標
        Public DB_X0 As Integer ' 從下側蒐尋過來的邊界 X0 座標
        Public DB_X1 As Integer ' 從下側蒐尋過來的邊界 X1 座標
        Public ColorDist As List(Of Single())   ' 最重要的顏色分布圖
        Public ImageByte() As Byte  ' 學習到的 Pattern 圖檔 , 為了存到XML只能用Byte 陣列格式
        ' 取得圖片必須將 ImageByte()  Byte 陣列 轉程圖檔傳出去
        Public Function GetBMP() As Bitmap
            Dim ms As New System.IO.MemoryStream(ImageByte)
            Dim bmp As Bitmap = Bitmap.FromStream(ms)
            Return bmp
        End Function
        ' 取設定圖, 為了存到XML 必須將BMP轉成Byte 陣列   ImageByte() 
        Public Sub SetBMP(ByVal bmp As Bitmap)
            Dim ms As New System.IO.MemoryStream
            bmp.Save(ms, Imaging.ImageFormat.Png)
            ImageByte = ms.GetBuffer
            bmp.Dispose()
        End Sub
        Public Function IsIsolated() As Boolean
            If Not LB_Exist Then Return False
            If Not RB_Exist Then Return False
            If Not UB_Exist Then Return False
            If Not DB_Exist Then Return False
            Return True
        End Function
    End Class


    Public Class cls_AOIRecipe
        Public ChkArea_X As Integer  ' 檢查區域的 X 座標
        Public ChkArea_Y As Integer  ' 檢查區域的 Y 座標
        Public ChkArea_W As Integer  ' 檢查區域寬
        Public ChkArea_H As Integer  ' 檢查區域高
        Public Mark_W As Integer  ' 物件寬
        Public Mark_H As Integer  ' 物件高
        Public ThresholdType As eThresholdType  ' 解析方式 0 : 自訂比例 1 中位數 2 自動模式 3. 指定值
        Public RateValue As Double  ' 紀錄比例值
        Public AssignedThreshold As Integer ' 指定值
        Public DefaultThreshold As Integer ' 預設值

        Public Function Copy(ByVal Source As cls_AOIRecipe) As cls_AOIRecipe
            Dim rtn As New cls_AOIRecipe
            rtn.ChkArea_X = Source.ChkArea_X
            rtn.ChkArea_Y = Source.ChkArea_Y
            rtn.ChkArea_W = Source.ChkArea_W
            rtn.ChkArea_H = Source.ChkArea_H
            rtn.Mark_W = Source.Mark_W
            rtn.Mark_H = Source.Mark_H
            rtn.ThresholdType = Source.ThresholdType
            rtn.RateValue = Source.RateValue
            rtn.AssignedThreshold = Source.AssignedThreshold
            rtn.DefaultThreshold = Source.DefaultThreshold
            Return rtn
        End Function
        Public Function Copy() As cls_AOIRecipe
            Dim rtn As New cls_AOIRecipe
            rtn.ChkArea_X = ChkArea_X
            rtn.ChkArea_Y = ChkArea_Y
            rtn.ChkArea_W = ChkArea_W
            rtn.ChkArea_H = ChkArea_H
            rtn.Mark_W = Mark_W
            rtn.Mark_H = Mark_H
            rtn.ThresholdType = ThresholdType
            rtn.RateValue = RateValue
            rtn.AssignedThreshold = AssignedThreshold
            rtn.DefaultThreshold = DefaultThreshold
            Return rtn
        End Function

    End Class

    Public Enum eThresholdType As Integer
        自訂比例 = 0
        中位數
        自動模式
        指定值
    End Enum

    Public Enum eAnalysisType
        二值化處理 = 0
        白色腐蝕處理
        白色膨脹處理
        白色腐蝕再膨脹
        白色膨脹再腐蝕
        黑色腐蝕處理
        黑色膨脹處理
        黑色腐蝕再膨脹
        黑色膨脹再腐蝕
        二次白色腐蝕處理
        二次白色膨脹處理
    End Enum

    Public Shared Function GetThreshold(ByVal ColorDist As str_Colordistribution, ByVal Recipe As cls_AOIRecipe) As cls_ReturnValue
        Dim rtnval As Integer  ' 回傳色階值
        Dim Rate As Double ' 最後採用的比例
        Dim rtn As New cls_ReturnValue
        Dim Max As Double = ColorDist.V0_Max
        Dim White As Double = ColorDist.V1_Up
        Dim Black As Double = ColorDist.V3_down
        Dim Min As Double = ColorDist.V4_min
        Dim Mid As Double = ColorDist.中位數



        rtn.Illustration = ""
        Select Case Recipe.ThresholdType
            Case eThresholdType.自訂比例
                rtn.Illustration = "指定比例值"
                Rate = Recipe.RateValue
                rtnval = (Max - Min) * (Rate / 100) + Min ' 回傳色階值
            Case eThresholdType.中位數
                rtn.Illustration = "指定中位數"
                rtnval = Mid
                Rate = CalColorRate(rtnval, Min, Max)
            Case eThresholdType.自動模式
                rtn.Illustration = "自動篩選"
                If White < 120 Or Mid < 100 Then  ' 過暗採用特殊比例
                    rtn.Illustration &= "過暗降低比例值"
                    Rate = 40  ' 最後採用的比例
                    rtnval = CalColorValue(Rate, Min, Max)   ' Rate : 0~100
                ElseIf White < 150 Then  ' 偏暗 採用 指定比例
                    rtn.Illustration &= "偏暗降低比例值"
                    Rate = 50 ' .RateValue  ' 回傳色階值
                    rtnval = CalColorValue(Rate, Min, Max)   ' Rate : 0~100
                ElseIf Mid > White Then  ' 中位數還大於 白色 過曝
                    rtn.Illustration &= "過曝拉高色階"
                    rtnval = (Mid + Max) / 2 ' 回傳色階值
                    Rate = CalColorRate(rtnval, Min, Max)
                ElseIf Mid >= 180 Then  ' 過亮
                    rtn.Illustration &= "過亮拉高比例值"
                    Rate = 80  ' 最後採用的比例
                    rtnval = CalColorValue(Rate, Min, Max)
                Else  ' 正常偏亮
                    rtn.Illustration &= "正常偏亮中位數"
                    rtnval = Mid
                    Rate = CalColorRate(rtnval, Min, Max)  ' 最後採用的比例
                End If
            Case eThresholdType.指定值
                rtn.Illustration = "指定值"
                rtnval = Recipe.DefaultThreshold
                Rate = CalColorRate(rtnval, Min, Max)  ' 100 * (rtnval - Min) / (Max - Min)  ' 最後採用的比例
        End Select
        Rate = Math.Round(Rate, 1)
        rtn.ReturnValue = New Object() {rtnval, Rate}
        Return rtn
    End Function
    Private Shared Function CalColorRate(ByVal Value As Integer, ByVal Min As Integer, ByVal Max As Integer) As Integer ' 計算中位數比例
        Dim MidVal As Double = Value * 1
        Dim MinVal As Double = Min * 1
        Dim MaxVal As Double = Max * 1
        If MaxVal = MinVal Then Return 0
        Dim rtn As Double = 100 * (MidVal - MinVal) / (MaxVal - MinVal) ' 中位數換算比例
        Return CInt(rtn)
    End Function
    ' Rate : 0~100 由比例計算門檻值
    Public Shared Function CalColorValue(ByVal Rate As Double, ByVal Min As Integer, ByVal Max As Integer) As Double
        Dim CRate As Double = Rate / 100
        Dim Value As Double = (Max - Min) * CRate + Min
        Return Value
    End Function
    ' 取得AOIRecipe的XML
    Public Shared Function GetAOIRecipeXML(ByVal FileName As String) As cls_AOIRecipe
        Try
            Dim rtn As cls_AOIRecipe
            If FileExist(FileName) = False Then
                Throw New Exception("指定檔案不存在, 請先進行設定")
            End If
            Dim serializer As New XmlSerializer(GetType(cls_AOIRecipe))
            Dim fs As New FileStream(FileName, FileMode.Open)
            rtn = CType(serializer.Deserialize(fs), cls_AOIRecipe)
            fs.Close()
            Return rtn
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
            Return Nothing
        End Try
    End Function
    ' 設定AOIRecipe的XML
    Public Shared Sub SetAOIRecipeXML(ByVal Recipe As cls_AOIRecipe, ByVal FileName As String)
        Try
            Dim serializer As New XmlSerializer(GetType(cls_AOIRecipe))
            Dim writer As New StreamWriter(FileName)
            serializer.Serialize(writer, Recipe)
            writer.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

End Class
