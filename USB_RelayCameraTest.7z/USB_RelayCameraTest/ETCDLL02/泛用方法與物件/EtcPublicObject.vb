﻿
'........................................................................................................................
'........................................................................................................................
' .............................  AUO ETC  常用到的公用物件 .....................................
' ............................   含公用變數, 類別 與函數       ......................................
' ............................  程式碼開發人 陳俊杰 Jethro 8606 3210 ..................
' ............................  改版日期 20200726   ...................................................
'........................................................................................................................
'........................................................................................................................

Imports ETCDLL02.EtcFunction

Public Class EtcPublicObject

    ' 回傳值
    Public Class cls_ReturnValue
        Public Property IsOn As Boolean = False ' 是否啟動中
        Public Property IsFinish As Boolean = True  ' 是否完成
        Public Property ErrorOccure As Boolean = False ' 是否發生坐錯誤
        Public Property ErrorString As String = "" ' 錯誤字串
        Public Property Illustration As String = ""  ' 說明
        Public Property Note As String = "" ' 註解
        Public Property InitialValue As Object = Nothing ' 初始值
        Public Property ReturnValue As Object = Nothing ' 回傳值
        Public Property StartTime As Date ' 起始時間
        Public Property EndTime As Date ' 結束時間
        Public Property TimeUsed As String = "" '總共耗時
        Public ReadOnly Property AllUsedTime As Date ' 到結束使用時間
            Get
                Return CalTimeDifference(StartTime, EndTime)
            End Get
        End Property
        Public ReadOnly Property InstntUsedTime As Date ' 到目前為止使用時間
            Get
                Return CalTimeDifference(StartTime, Now)
            End Get
        End Property
        Public Sub New()
            SetStart()
        End Sub
        Public Sub SetStart()
            IsOn = True
            IsFinish = Not IsOn
            ErrorOccure = False
            ErrorString = ""
            Illustration = ""
            Note = ""
            InitialValue = Nothing
            ReturnValue = Nothing
            StartTime = Now
            EndTime = StartTime
            TimeUsed = ""
        End Sub
        Public Sub SetFinish(Optional ByVal ErrStr As String = "")
            IsOn = False
            IsFinish = Not IsOn
            EndTime = Now
            ErrorOccure = Not (ErrStr = "")
            ErrorString = ""
            EndTime = Now
            TimeUsed = CalTimeDifference(StartTime, EndTime)
        End Sub

    End Class

    ' 流程控制物件
    Public Class cls_FlowFactor
        Public ReadOnly FlowEndID As Integer = 999
        Public Name As String
        Public StepID As Integer
        Public NextID As Integer
        Public IsOn As Boolean
        Public Finished As Boolean
        Public ErrorOccure As Boolean
        Public ErrorString As String
        Public InputObject As Object  ' 傳入之參數
        Public InputObject2 As Object  ' 傳入之第二參數
        Public ReturnObject As Object  ' 傳出的結果
        Public StatusData As Object
        Public HoldTime As Date
        Public DelayTime As Date
        Public DelayTimeNext As Single
        Public Illustration As String
        'Public SyncMove As Boolean '軸運動流程專用，指示是否多軸同時運動
        Delegate Sub Process()  ' 宣告Process為委派副程式型別
        Private RunSub As Process ' 變數: 存放指定的副程式
        Public Sub InvokeMethod(ByVal method As Process) '調用(委派)副程式,並將此函數存放於RunSub變數
            RunSub = method
        End Sub
        Public Sub RunProcess()  ' 執行委派副程式
            RunSub.Invoke()
        End Sub
        Public Sub New(ByVal flowName As String)
            Name = flowName
            StepID = 0
            NextID = 0
            IsOn = False
            Finished = False
            ErrorOccure = False
            ErrorString = ""
            InputObject = Nothing
            InputObject2 = Nothing
            ReturnObject = Nothing
            StatusData = Nothing
            Illustration = ""
            'SyncMove = False
            'PhID = -1
        End Sub
        Public Sub NewStart(Optional ByVal Action As Boolean = True)  ' 流程啟動
            StepID = 0
            NextID = 0
            IsOn = Action
            Finished = False
            ErrorOccure = False
            ErrorString = ""
            InputObject = Nothing
            InputObject2 = Nothing
            ReturnObject = Nothing
            StatusData = Nothing
            'PhID = -1
            Illustration = "Process New Start"
        End Sub
        Public Sub CancelFlow()
            Me.SetProcessFinish("Process been Cancled")
        End Sub
        Public Sub SetProcessFinish(Optional ByVal ErrString As String = "")
            If ErrString = "" Then
                IsOn = False
                Finished = True
                ErrorOccure = False
                ErrorString = ""
                InputObject = Nothing
                StepID = 0
                Illustration = "Process Finished"
                'SyncMove = False
            Else
                IsOn = False
                Finished = True
                ErrorOccure = True
                ErrorString = ErrString
                InputObject = Nothing
                StepID = 0
                Illustration = "Process Error :" & ErrString
                'SyncMove = False
            End If
        End Sub
    End Class


End Class
