﻿Imports System.IO

Public Class EtcFunction

    ' 開啟單一檔案
    Public Shared Function MyOpenFileDialog(ByVal SubName As String, Optional ByVal DefaultFolder As String = "", _
                                                                   Optional ByVal DftName As String = "") As String
        Dim openFileDialog1 As New OpenFileDialog
        If DefaultFolder <> "" Then
            openFileDialog1.InitialDirectory = DefaultFolder
            If DftName <> "" Then
                openFileDialog1.FileName = DftName
            End If
        End If
        openFileDialog1.Filter = SubName & " files (*." & SubName & ")|*." & SubName & "|All files (*.*)|*.*"
        openFileDialog1.FilterIndex = 0
        openFileDialog1.RestoreDirectory = True
        If openFileDialog1.ShowDialog() <> System.Windows.Forms.DialogResult.OK Then
            Return ""
        Else
            Return openFileDialog1.FileName
        End If
    End Function

    ' 開啟多檔案
    Public Shared Function MyOpenFilesDialog(ByVal SubName As String, Optional ByVal DefaultFolder As String = "", _
                                                               Optional ByVal DftName As String = "") As String()
        Dim openFileDialog1 As New OpenFileDialog
        openFileDialog1.Multiselect = True
        If DefaultFolder <> "" Then
            openFileDialog1.InitialDirectory = DefaultFolder
            If DftName <> "" Then
                openFileDialog1.FileName = DftName
            End If
        End If
        openFileDialog1.Filter = SubName & " files (*." & SubName & ")|*." & SubName & "|All files (*.*)|*.*"
        'openFileDialog1.FilterIndex = 0
        openFileDialog1.RestoreDirectory = True
        If openFileDialog1.ShowDialog() <> System.Windows.Forms.DialogResult.OK Then
            Return Nothing
        Else
            Return openFileDialog1.FileNames
        End If
    End Function

    ' my Save File FileDialog
    Public Shared Function MySaveFileDialog(ByVal SubName As String, Optional ByVal DefaultFolder As String = "", _
                                                               Optional ByVal FileName As String = "", Optional ByVal Title As String = " Save File Dialog") As String
        Dim SaveFileDialog1 As New SaveFileDialog
        If DefaultFolder <> "" Then
            SaveFileDialog1.InitialDirectory = DefaultFolder
        End If
        If FileName <> "" Then
            Dim SepCh As String = "\"
            If SaveFileDialog1.InitialDirectory.Substring(SaveFileDialog1.InitialDirectory.Length - 1, 1) = "\" Then
                SepCh = ""
            End If
            SaveFileDialog1.FileName = FileName
            'SaveFileDialog1.FileName = SaveFileDialog1.InitialDirectory & SepCh & FileName
        End If
        SaveFileDialog1.Title = Title
        SaveFileDialog1.Filter = SubName & " files (*." & SubName & ")|*." & SubName '& "|All files (*.*)|*.*"
        SaveFileDialog1.FilterIndex = 0
        SaveFileDialog1.RestoreDirectory = True
        If SaveFileDialog1.ShowDialog() <> System.Windows.Forms.DialogResult.OK Then
            Return ""
        Else
            Return SaveFileDialog1.FileName
        End If
    End Function

    ' 選擇資料夾
    Private Shared Function MyFolderDialog(Optional ByVal Dft_Folder As String = "") As String
        Dim rtn As String = ""
        Dim FolderBrowser As New FolderBrowserDialog
        If Dft_Folder.Trim <> "" Then
            FolderBrowser.SelectedPath = Dft_Folder
        End If
        If FolderBrowser.ShowDialog = DialogResult.Cancel Then
            Return rtn
        End If
        rtn = FolderBrowser.SelectedPath  ' & "\"
        Return rtn
    End Function

    ' 建立資料夾 會一層一層建下去
    Public Shared Sub CreatDirectory(ByVal Directory As String)
        Dim folderList As New List(Of String)
        Dim currentfolder As String = ""
        Try
            For i As Integer = 0 To Directory.Length - 1
                Dim CCh As String = Directory.Substring(i, 1)
                If CCh = "\" Then
                    folderList.Add(currentfolder)
                    currentfolder &= CCh
                Else
                    currentfolder &= CCh
                    If i = Directory.Length - 1 Then
                        folderList.Add(currentfolder)
                        Exit For
                    End If
                End If
            Next
            For i As Integer = 0 To folderList.Count - 1
                Dim folder As String = folderList(i).Trim
                If Not My.Computer.FileSystem.DirectoryExists(folder) Then ' 目錄不存在
                    If folder.Substring(folder.Length - 1, 1) = ":" Then '根目錄竟然不存在
                        Throw New Exception("Driver " & folder & " do not exist")
                    End If
                    My.Computer.FileSystem.CreateDirectory(folder)
                End If
            Next
        Catch ex As Exception
            Dim ErrMsg As String = "Directory Create Error: " & ex.Message
            MsgBox(ErrMsg)
            Throw New Exception(ErrMsg)
        End Try
    End Sub
    ' 檔案是否存在
    Public Shared Function FileExist(ByVal FileName As String) As Boolean
        Try
            If FileName.Trim = "" Then Return False
            Return My.Computer.FileSystem.FileExists(FileName)
        Catch ex As Exception
            Return False
        End Try
    End Function
    ' 路徑是否存在
    Public Shared Function FolderExist(ByVal FolderName As String) As Boolean
        Try
            If FolderName.Trim = "" Then Return False
            Return My.Computer.FileSystem.DirectoryExists(FolderName)
        Catch ex As Exception
            Return False
        End Try
    End Function
    ' 組合路徑名稱與檔名得到檔案全名
    Public Shared Function GetTotalFileName(ByVal FolderName As String, ByVal FileName As String) As String
        Dim tmpFolder As String = FolderName.Trim
        Dim SePch As String = "\"
        If tmpFolder.Substring(tmpFolder.Length - 1, 1) = "\" Then SePch = ""
        Return FolderName & SePch & FileName
    End Function
    ' 取得檔案內所有字串
    Public Shared Function GetFileAllText(ByVal FileName As String) As String
        Try
            Return My.Computer.FileSystem.ReadAllText(FileName)
        Catch ex As Exception
            Return ""
        End Try
    End Function
    ' 取得應用程式執行路徑
    Public Shared Function GetApplicationPath() As String
        Return My.Application.Info.DirectoryPath
    End Function
    ' 取得資料夾內所有檔案名稱 , SubName 可以為單一字串 如 "'xml" 也可為陣列 如 {"'xml", "txt"}
    ' Get All Filenames in assigned folder  
    Public Shared Function GetFileNmaesFromFolder(ByVal Folder As String, Optional ByVal SubName As Object = Nothing) As ArrayList
        Dim RtnArr As New ArrayList
        Try
            Dim ListName() As String = Nothing
            If SubName Is Nothing Then
                ListName = My.Computer.FileSystem.GetFiles(Folder, FileIO.SearchOption.SearchTopLevelOnly).ToArray
            Else
                Dim TypeStr As String = SubName.GetType.Name
                Dim SubNameStr() As String
                Select Case TypeStr
                    Case "String"
                        Dim tmpStr() As String = {SubName}
                        SubNameStr = tmpStr
                    Case "String[]"
                        SubNameStr = SubName
                    Case Else
                        Throw New Exception("SubName Type Error!")
                End Select
                ListName = My.Computer.FileSystem.GetFiles(Folder, FileIO.SearchOption.SearchTopLevelOnly, SubNameStr).ToArray
            End If
            If ListName.Length = 0 Then
                Return RtnArr
            End If
            For i As Integer = 0 To ListName.GetUpperBound(0)
                Dim TmpName As String = My.Computer.FileSystem.GetName(ListName(i))
                RtnArr.Add(TmpName)
            Next
            RtnArr.Sort()
            Return RtnArr
        Catch ex As Exception
            MsgBox(ex.Message.Trim)
            RtnArr.Clear()
            Return RtnArr
        End Try
    End Function

#Region "Write Log Handle"
    Public Shared dftLoagPath As String = GetApplicationPath() & "\Log\"
    Public Shared dftLogFileName As String = "LogData"
    Public Shared Sub WriteLog(ByVal SString As String, Optional ByVal Path As String = "", Optional ByVal FileName As String = "")
        Try
            Dim trgPath As String = Path
            Dim trgName As String = FileName
            If Path = "" Then trgPath = dftLoagPath
            If FileName = "" Then trgName = dftLogFileName & Now.ToString("yyyyMMdd") & ".ini"
            If FolderExist(trgPath) = False Then CreatDirectory(trgPath)
            Dim TTNmae As String = GetTotalFileName(trgPath, trgName)
            Dim WStr As String = Now.ToString("hh:mm:ss") & ">>" & SString & vbCrLf
            My.Computer.FileSystem.WriteAllText(TTNmae, WStr, True)
        Catch ex As Exception
            Application.DoEvents()
        End Try
    End Sub
#End Region
    ' 較單純一般環境參數讀取處理, 與註冊參數讀取處理 無差異 , 只是存放路徑不一樣
#Region "Environment Handle"
    Public Shared ReadOnly EnvironmentFolder As String = GetApplicationPath() & "\Environment\" ' 程式執行環境設定儲存的資料夾
    ' 設定紀錄資料  KeyName 就好像 登錄編輯區的子鍵一樣, SrtVal 則為設定值
    Public Shared Sub SetEnvironmentValue(ByVal SetVal As String, ByVal KeyName As String)
        ' 先找出設定檔 
        If Not FolderExist(EnvironmentFolder) Then ' 預設環境資料夾不存在要先建立
            CreatDirectory(EnvironmentFolder)
        End If
        Dim FileName As String = KeyName & ".log"
        Dim TotalFile As String = EnvironmentFolder & "\" & FileName
        ' 將 Folder 路徑寫到檔案中
        My.Computer.FileSystem.WriteAllText(TotalFile, SetVal, False)
    End Sub
    ' 取得紀錄資料  KeyName 就好像 登錄編輯區的子鍵一樣
    Public Shared Function GetEnvironmentValue(ByVal KeyName As String) As String
        ' 先找出設定檔 
        If Not FolderExist(EnvironmentFolder) Then ' 預設環境資料夾不存在要先建立
            CreatDirectory(EnvironmentFolder)
        End If
        Dim FileName As String = KeyName & ".log"
        Dim TotalFile As String = EnvironmentFolder & "\" & FileName
        If Not My.Computer.FileSystem.FileExists(TotalFile) Then ' 如果檔案不存在則傳回空字串
            Return ""
        Else
            Return My.Computer.FileSystem.ReadAllText(TotalFile)
        End If
    End Function
#Region "範例"
    ' 範例1 讀取 Double 
    Public Function Get_MyDoubleExample() As Double
        Dim KeyName As String = "MyDoubleExample"       ' 讀與取一定要用同一個 KeyName
        Dim DftVal As Double = 0.95
        Dim TmpStr As String = GetEnvironmentValue(KeyName)
        If TmpStr = "" Then
            Return DftVal
        Else
            Return Val(TmpStr)
        End If
    End Function
    ' 範例1 寫入 Double 
    Public Shared Sub Set_MyDoubleExample(ByVal Value As Double)
        Dim KeyName As String = "MyDoubleExample"   ' 讀與取一定要用同一個 KeyName
        Dim SetStr As String = Value.ToString
        SetEnvironmentValue(SetStr, KeyName)
    End Sub
    ' 範例2
    Public Shared Sub Set_FineTuneOnlyY(ByVal Value As Boolean)
        Dim KeyName As String = "FineTuneOnlyY"
        Dim SetStr As String = IIf(Value, "1", "0")
        SetEnvironmentValue(SetStr, KeyName)
    End Sub
    Public Shared Function Get_FineTuneOnlyY() As Boolean
        Dim KeyName As String = "FineTuneOnlyY"
        Dim DftVal As Boolean = False
        Dim TmpStr As String = GetEnvironmentValue(KeyName)
        If TmpStr = "" Then
            Return DftVal
        End If
        Dim rtn As Boolean = Val(TmpStr) = 1
        Return rtn
    End Function
    ' 範例3
    Public Shared Sub Set_LastLogOnUser(ByVal Value As String)
        Dim KeyName As String = "LastLogOnUser"
        Dim SetStr As String = Value.ToString
        SetEnvironmentValue(SetStr, KeyName)
    End Sub
    Public Shared Function Get_LastLogOnUser() As String
        Dim KeyName As String = "LastLogOnUser"
        Dim DftVal As String = ""
        Dim TmpStr As String = GetEnvironmentValue(KeyName)
        If TmpStr = "" Then
            Return DftVal
        End If
        Return TmpStr
    End Function
#End Region ' End of 範例
#End Region
    ' 較單純一般註冊參數讀取處理 與環境參數讀取處理 無差異 , 只是存放路徑不一樣
#Region "Register Handle"
    Public Shared RegisterFolder As String = GetApplicationPath() & "\Regist\"  ' 程式執行環境設定儲存的資料夾
    ' 取得紀錄資料  KeyName 就好像 登錄編輯區的子鍵一樣
    Public Shared Function GetRegistValue(ByVal KeyName As String) As String
        ' 先找出設定檔 
        If Not FolderExist(RegisterFolder) Then ' 預設環境資料夾不存在要先建立
            CreatDirectory(RegisterFolder)
        End If
        Dim FileName As String = KeyName & ".log"
        Dim TotalFile As String = RegisterFolder & "\" & FileName
        If Not My.Computer.FileSystem.FileExists(TotalFile) Then ' 如果檔案不存在則傳回空字串
            Return ""
        Else
            Return My.Computer.FileSystem.ReadAllText(TotalFile)
        End If
    End Function
    ' 設定紀錄資料  KeyName 就好像 登錄編輯區的子鍵一樣, SrtVal 則為設定值
    Public Shared Sub SetRegistValue(ByVal SetVal As String, ByVal KeyName As String)
        ' 先找出設定檔 
        If Not FolderExist(RegisterFolder) Then ' 預設環境資料夾不存在要先建立
            CreatDirectory(RegisterFolder)
        End If
        Dim FileName As String = KeyName & ".log"
        Dim TotalFile As String = RegisterFolder & "\" & FileName
        ' 將 Folder 路徑寫到檔案中
        My.Computer.FileSystem.WriteAllText(TotalFile, SetVal, False)
    End Sub

#Region "範例"
    ' 範例1 
    Public Shared Sub Set_CurrentRegisterName(ByVal Value As String)
        Dim KeyName As String = "CurrentRegisterName"
        Dim SetStr As String = Value.ToString
        SetRegistValue(SetStr, KeyName)
    End Sub
    Public Shared Function Get_CurrentRegisterName() As String
        Dim KeyName As String = "CurrentRegisterName"
        Dim DftVal As String = ""
        Dim TmpStr As String = GetRegistValue(KeyName)
        If TmpStr = "" Then
            Return DftVal
        End If
        Return TmpStr
    End Function
#End Region  ' End of 範例

#End Region

    '複製資料夾內所有檔案
    Public Shared Function CopyDerictory(ByVal SrcPath As String, ByVal TargetPath As String) As Boolean
        Try
            My.Computer.FileSystem.CopyDirectory(SrcPath, TargetPath, True)
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    '取得指定路徑內的資料夾名稱(只返回資料夾名稱，檔案名稱不回傳)
    Public Shared Function GetOnlyFolderNmaes(ByVal Folder As String) As ArrayList
        Dim RtnArr As New ArrayList
        Try
            Dim FindDirectories As DirectoryInfo = New DirectoryInfo(Folder)
            For Each GetDirectories_name As DirectoryInfo In FindDirectories.GetDirectories
                RtnArr.Add(GetDirectories_name)
            Next
            Return RtnArr
        Catch ex As Exception
            MsgBox(ex.Message.Trim)
            RtnArr.Clear()
            Return RtnArr
        End Try
    End Function


    '**********   20200703 Add By Jethro *********************
    ' 影像複製同時去除索引 (新舊像圖無關連性)
    Public Shared Function ImageCopy_IndexFree(ByVal bmp As Bitmap) As Bitmap
        Dim newbmp As New Bitmap(bmp.Width, bmp.Height)
        Dim g As Graphics = Graphics.FromImage(newbmp)
        g.DrawImage(bmp, 0, 0, bmp.Width, bmp.Height)
        Return newbmp
    End Function
    Public Shared Function ImageCopy_IndexFree(ByVal filename As String) As Bitmap
        Dim bmp As New Bitmap(filename)
        Dim newbmp As New Bitmap(bmp.Width, bmp.Height)
        Using bmp
            Dim g As Graphics = Graphics.FromImage(newbmp)
            g.DrawImage(bmp, 0, 0, bmp.Width, bmp.Height)
        End Using
        bmp = Nothing
        Return newbmp
    End Function

    ' 影像縮圖(縮到指定大小) 同時去除索引 (新舊像圖無關連性)
    Public Shared Function ImageShrinking(ByVal bmp As Bitmap, ByVal Width As Integer, ByVal Height As Integer) As Bitmap
        Dim newbmp As New Bitmap(Width, Height)
        Dim g As Graphics = Graphics.FromImage(newbmp)
        g.DrawImage(bmp, 0, 0, Width, Height)
        Return newbmp
    End Function

    ' 取得部分影像 同時去除索引 (新舊像圖無關連性)
    Public Shared Function GetImageParts(ByVal bmp As Bitmap, ByVal rec As Rectangle) As Bitmap
        Dim newbmp As New Bitmap(rec.Width, rec.Height)
        Dim recnew As New Rectangle(0, 0, newbmp.Width, newbmp.Height)  ' 代表印到新圖的區塊
        Dim g As Graphics = Graphics.FromImage(newbmp)
        'g.DrawImage(bmp, rec0, rec.X, rec.Y, rec.Width, rec.Height, GraphicsUnit.Pixel)
        g.DrawImage(bmp, recnew, rec, GraphicsUnit.Pixel)
        Return newbmp
    End Function



    ' 計算 時間差 然後傳出字串 方便計算耗時
    Public Shared Function CalTimeDifference(ByVal StartT As Date, ByVal EndT As Date) As String
        Dim TickDiff As Long = Math.Abs(EndT.Ticks - StartT.Ticks)   ' 1000000000 = 
        ' 1 milisec = 10^4 ticks
        ' 1 Sec = 1000 milisec = 10^7  Ticks
        ' 1 min = 60 sec = 60 * 10 ^7 Ticks
        ' 1 Hr = 60 min = 60 *60 sec = 60*60 * 1000 milisec = 60*60*10^7 Ticks
        Dim Hr As Integer = TickDiff \ (3600 * 10 ^ 7)
        TickDiff = TickDiff - Hr * (3600 * 10 ^ 7)
        Dim Min As Integer = TickDiff \ (60 * 10 ^ 7)
        TickDiff = TickDiff - Min * (60 * 10 ^ 7)
        Dim Sec As Long = TickDiff \ 10 ^ 7
        TickDiff = TickDiff - Sec * (10 ^ 7)
        Dim ms As Long = TickDiff \ 10 ^ 4
        Dim RtnStrHr As String = IIf(Hr = 0, "", Hr & " Hr ")
        Dim RtnStrMin As String = IIf(Min = 0, "", Min & " Min ")
        Dim RtnStrSec As String = IIf(Sec = 0, "", Sec & " s ")
        Dim RtnStrMs As String = ms & " ms"
        Return RtnStrHr & RtnStrMin & RtnStrSec & RtnStrMs
    End Function


    Public Shared Function CheckFileIsImage(ByVal Filename As String) As Boolean
        Dim ImgSubNames() As String = {"bmp", "jpg"}
        Dim Index As Integer = Filename.LastIndexOf(".")
        If Index < 0 Then Return False
        Try
            Dim subName As String = Filename.Substring(Index + 1).ToLower.Trim
            Return ImgSubNames.Contains(subName)
        Catch ex As Exception
            Return False
        End Try
    End Function

End Class


