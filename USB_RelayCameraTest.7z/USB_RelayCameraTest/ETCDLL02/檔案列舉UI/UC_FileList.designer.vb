﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UC_FileList
    Inherits System.Windows.Forms.UserControl

    'UserControl1 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(UC_FileList))
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.lbl_illustration = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txt_Path = New System.Windows.Forms.TextBox()
        Me.btn_Refresh = New System.Windows.Forms.Button()
        Me.btn_Path = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.txt_FileName = New System.Windows.Forms.TextBox()
        Me.cmb_ListType = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel_FileList = New System.Windows.Forms.Panel()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.lbl_percentage = New System.Windows.Forms.Label()
        Me.ImgList_L = New System.Windows.Forms.ImageList(Me.components)
        Me.ImgList_S = New System.Windows.Forms.ImageList(Me.components)
        Me.ImgSource_L = New System.Windows.Forms.ImageList(Me.components)
        Me.ImgSource_S = New System.Windows.Forms.ImageList(Me.components)
        Me.StatusStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel_FileList.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lbl_illustration})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 553)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(370, 22)
        Me.StatusStrip1.TabIndex = 0
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'lbl_illustration
        '
        Me.lbl_illustration.Name = "lbl_illustration"
        Me.lbl_illustration.Size = New System.Drawing.Size(59, 17)
        Me.lbl_illustration.Text = "Status txt"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txt_Path)
        Me.Panel1.Controls.Add(Me.btn_Refresh)
        Me.Panel1.Controls.Add(Me.btn_Path)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(370, 24)
        Me.Panel1.TabIndex = 1
        '
        'txt_Path
        '
        Me.txt_Path.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_Path.Location = New System.Drawing.Point(29, 0)
        Me.txt_Path.Name = "txt_Path"
        Me.txt_Path.Size = New System.Drawing.Size(310, 22)
        Me.txt_Path.TabIndex = 2
        '
        'btn_Refresh
        '
        Me.btn_Refresh.BackgroundImage = CType(resources.GetObject("btn_Refresh.BackgroundImage"), System.Drawing.Image)
        Me.btn_Refresh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_Refresh.Dock = System.Windows.Forms.DockStyle.Right
        Me.btn_Refresh.Location = New System.Drawing.Point(339, 0)
        Me.btn_Refresh.Name = "btn_Refresh"
        Me.btn_Refresh.Size = New System.Drawing.Size(31, 24)
        Me.btn_Refresh.TabIndex = 1
        Me.btn_Refresh.UseVisualStyleBackColor = True
        '
        'btn_Path
        '
        Me.btn_Path.BackgroundImage = CType(resources.GetObject("btn_Path.BackgroundImage"), System.Drawing.Image)
        Me.btn_Path.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_Path.Dock = System.Windows.Forms.DockStyle.Left
        Me.btn_Path.Location = New System.Drawing.Point(0, 0)
        Me.btn_Path.Name = "btn_Path"
        Me.btn_Path.Size = New System.Drawing.Size(29, 24)
        Me.btn_Path.TabIndex = 0
        Me.btn_Path.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Control
        Me.Panel2.Controls.Add(Me.txt_FileName)
        Me.Panel2.Controls.Add(Me.cmb_ListType)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 24)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(370, 24)
        Me.Panel2.TabIndex = 2
        '
        'txt_FileName
        '
        Me.txt_FileName.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txt_FileName.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txt_FileName.Location = New System.Drawing.Point(42, 0)
        Me.txt_FileName.Name = "txt_FileName"
        Me.txt_FileName.Size = New System.Drawing.Size(254, 23)
        Me.txt_FileName.TabIndex = 3
        '
        'cmb_ListType
        '
        Me.cmb_ListType.Dock = System.Windows.Forms.DockStyle.Right
        Me.cmb_ListType.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.cmb_ListType.FormattingEnabled = True
        Me.cmb_ListType.Location = New System.Drawing.Point(296, 0)
        Me.cmb_ListType.Name = "cmb_ListType"
        Me.cmb_ListType.Size = New System.Drawing.Size(74, 21)
        Me.cmb_ListType.TabIndex = 15
        '
        'Label1
        '
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Label1.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 24)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Name"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel_FileList
        '
        Me.Panel_FileList.Controls.Add(Me.ListView1)
        Me.Panel_FileList.Controls.Add(Me.Panel3)
        Me.Panel_FileList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel_FileList.Location = New System.Drawing.Point(0, 48)
        Me.Panel_FileList.Name = "Panel_FileList"
        Me.Panel_FileList.Size = New System.Drawing.Size(370, 505)
        Me.Panel_FileList.TabIndex = 3
        '
        'ListView1
        '
        Me.ListView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListView1.Location = New System.Drawing.Point(0, 0)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(370, 487)
        Me.ListView1.TabIndex = 1
        Me.ListView1.UseCompatibleStateImageBehavior = False
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.ProgressBar1)
        Me.Panel3.Controls.Add(Me.lbl_percentage)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.Location = New System.Drawing.Point(0, 487)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(370, 18)
        Me.Panel3.TabIndex = 2
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ProgressBar1.Location = New System.Drawing.Point(0, 0)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(333, 18)
        Me.ProgressBar1.TabIndex = 1
        '
        'lbl_percentage
        '
        Me.lbl_percentage.Dock = System.Windows.Forms.DockStyle.Right
        Me.lbl_percentage.Location = New System.Drawing.Point(333, 0)
        Me.lbl_percentage.Name = "lbl_percentage"
        Me.lbl_percentage.Size = New System.Drawing.Size(37, 18)
        Me.lbl_percentage.TabIndex = 0
        Me.lbl_percentage.Text = "100%"
        Me.lbl_percentage.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'ImgList_L
        '
        Me.ImgList_L.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImgList_L.ImageSize = New System.Drawing.Size(64, 64)
        Me.ImgList_L.TransparentColor = System.Drawing.Color.Transparent
        '
        'ImgList_S
        '
        Me.ImgList_S.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImgList_S.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImgList_S.TransparentColor = System.Drawing.Color.Transparent
        '
        'ImgSource_L
        '
        Me.ImgSource_L.ImageStream = CType(resources.GetObject("ImgSource_L.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgSource_L.TransparentColor = System.Drawing.Color.Transparent
        Me.ImgSource_L.Images.SetKeyName(0, "laptop.ico")
        '
        'ImgSource_S
        '
        Me.ImgSource_S.ImageStream = CType(resources.GetObject("ImgSource_S.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImgSource_S.TransparentColor = System.Drawing.Color.Transparent
        Me.ImgSource_S.Images.SetKeyName(0, "my_computer.ico")
        '
        'UC_FileList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Panel_FileList)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Name = "UC_FileList"
        Me.Size = New System.Drawing.Size(370, 575)
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel_FileList.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents lbl_illustration As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txt_Path As System.Windows.Forms.TextBox
    Friend WithEvents btn_Refresh As System.Windows.Forms.Button
    Friend WithEvents btn_Path As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt_FileName As System.Windows.Forms.TextBox
    Friend WithEvents cmb_ListType As System.Windows.Forms.ComboBox
    Friend WithEvents Panel_FileList As System.Windows.Forms.Panel
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents lbl_percentage As System.Windows.Forms.Label
    Friend WithEvents ImgList_L As System.Windows.Forms.ImageList
    Friend WithEvents ImgList_S As System.Windows.Forms.ImageList
    Friend WithEvents ImgSource_L As System.Windows.Forms.ImageList
    Friend WithEvents ImgSource_S As System.Windows.Forms.ImageList

End Class
