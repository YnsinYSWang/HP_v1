﻿Imports System.Windows.Media.Imaging

Public Class Class_FileClass

    Private Shared imagesubnames() As String = {"bmp", "jpg"}  ' 影像檔副檔名

    Private Shared Function FileIsImage(ByVal filename As String) As Boolean
        Try
            Dim id As Integer = filename.LastIndexOf(".")
            Dim subname As String = filename.Substring(id + 1).Trim.ToLower
            Return imagesubnames.Contains(subname)
        Catch ex As Exception
            Return False
        End Try
    End Function


    Public Class cls_FileData
        Public Folder As String
        Public Name As String
        Public TotalName As String
        Public FileLength As Long  ' 檔案大小
        Public CreateTime As Date  ' 檔案建立時間
        Public LastWriteTime As Date  ' 檔案最後變更時間
        Public pixelwidth As Integer = 0
        Public pixelheight As Integer = 0

        Public ReadOnly Property sizeString As String
            Get
                If pixelwidth = 0 Then Return ""
                Return pixelwidth & " x " & pixelheight
            End Get
        End Property


        Private Function GetTotalName(ByVal Sfolder As String, ByVal sName As String) As String
            Dim tfolder As String = Sfolder.Trim
            Dim SepCh As String = "\"
            If tfolder.Substring(tfolder.Length - 1, 1) = "\" Then
                SepCh = ""
            End If
            Return tfolder & SepCh & sName
        End Function
        Public Sub New(ByVal sTotalName As String)
            FileLength = 0
            If sTotalName.Trim = "" Then
                Folder = ""
                Name = ""
                TotalName = ""
                Exit Sub
            End If
            Name = My.Computer.FileSystem.GetName(sTotalName)
            Dim index As Integer = sTotalName.LastIndexOf("\")
            Folder = sTotalName.Substring(0, index)
            TotalName = sTotalName
            If My.Computer.FileSystem.FileExists(TotalName) Then
                Dim Info = My.Computer.FileSystem.GetFileInfo(TotalName)
                FileLength = Info.Length
                CreateTime = Info.CreationTime
                LastWriteTime = Info.LastWriteTime
                If FileIsImage(TotalName) Then
                    Dim rtnsize As Size = FastGetImageSize(TotalName)
                    pixelwidth = rtnsize.Width
                    pixelheight = rtnsize.Height
                End If
            End If
        End Sub
        Public Sub New(ByVal sFolder As String, ByVal sName As String)
            FileLength = 0
            Folder = sFolder
            Name = sName
            TotalName = GetTotalName(Folder, Name)
            If My.Computer.FileSystem.FileExists(TotalName) Then
                Dim Info = My.Computer.FileSystem.GetFileInfo(TotalName)
                FileLength = Info.Length
                CreateTime = Info.CreationTime
                LastWriteTime = Info.LastWriteTime
                If FileIsImage(TotalName) Then
                    Dim rtnsize As Size = FastGetImageSize(TotalName)
                    pixelwidth = rtnsize.Width
                    pixelheight = rtnsize.Height
                End If
            End If
        End Sub
        Public Sub New()
            FileLength = 0
            Folder = ""
            Name = ""
            TotalName = ""
        End Sub
    End Class

    ' 針對圖形檔處理資料
    Public Class cls_ImgData
        Public ImageName As cls_FileData
        Public ImageSize As Size
        Public Sub New(ByVal SourceName As String)
            ImageName = New cls_FileData(SourceName)
            Using SImage As Bitmap = New Bitmap(SourceName)
                ImageSize = SImage.Size
            End Using
        End Sub
        Public Sub New(ByVal SourceFileData As cls_FileData)
            ImageName = SourceFileData
            Using SImage As Bitmap = New Bitmap(ImageName.TotalName)
                ImageSize = SImage.Size
            End Using
        End Sub
        ' 取得檔案圖型 (去索引)
        Public Function GetImage() As Bitmap
            Try
                Dim filename As String = ImageName.TotalName
                If Not My.Computer.FileSystem.FileExists(filename) Then
                    Throw New Exception(filename & " does not exist")
                End If
                Return ImageCopy_IndexFree(New Bitmap(filename))
            Catch ex As Exception
                MsgBox("GetImage Error : " & ex.Message)
                Return New Bitmap(1, 1)
            End Try
        End Function

    End Class

    ' 用於顯示一般檔案或影像擋
    Public Class cls_FileList
        Public Items As List(Of cls_FileData)
        Public SmallImageList As ImageList
        Public LargeImageList As ImageList
        Public SmallSize As Size
        Public LargeSize As Size
        Public Sub SetSmallSize(ByVal SSize As Size)
            SmallSize = SSize
            SmallImageList.ImageSize = SSize
        End Sub
        Public Sub SetLargelSize(ByVal SSize As Size)
            LargeSize = SSize
            LargeImageList.ImageSize = SSize
        End Sub
    End Class


    '  專門用於顯示影像檔
    Public Class cls_ImgList
        Public Items As List(Of cls_ImgData)
        Public SmallImageList As ImageList
        Public LargeImageList As ImageList
        Public SmallSize As Size
        Public LargeSize As Size
        Public Sub SetSmallSize(ByVal SSize As Size)
            SmallSize = SSize
            SmallImageList.ImageSize = SSize
        End Sub
        Public Sub SetLargelSize(ByVal SSize As Size)
            LargeSize = SSize
            LargeImageList.ImageSize = SSize
        End Sub
        Public Sub AddImage(ByVal FileName As String)
            Items.Add(New cls_ImgData(FileName))
            Dim Index As Integer = Items.Count - 1
            Using SourceImage As Image = New Bitmap(Items(Index).ImageName.TotalName)
                Dim SizeH As Integer = 100
                Dim SizeW As Integer = SizeH * SourceImage.Width / SourceImage.Height
                Dim tmpImg As Bitmap = ImageShrinking(SourceImage, SizeW, SizeH)
                LargeImageList.Images.Add(tmpImg)
                SmallImageList.Images.Add(tmpImg)
            End Using
        End Sub
        Public Sub AddImage(ByVal FileData As cls_FileData)
            Dim newfilename As String = FileData.TotalName
            AddImage(newfilename)
        End Sub
        Public Sub New()
            SmallImageList = New ImageList
            LargeImageList = New ImageList
            Items = New List(Of cls_ImgData)
            SetInitialSize()
        End Sub
        Private Sub SetInitialSize()
            SmallSize = New Size(20, 20)
            LargeSize = New Size(50, 50)
            SmallImageList.ImageSize = SmallSize
            LargeImageList.ImageSize = LargeSize
        End Sub
    End Class


    ' 快速讀取檔案大小 ' 一般是讀取檔案後再取出, 因為必須將整個圖檔先行載入，圖檔越大就越久，記憶體也吃的兇
    ' 比較好的作法應該是直接讀取檔案的檔頭，圖檔的大小資訊再圖檔的檔頭就有了 '
    ' 不需要將整個圖檔載入就可以得知，效率也會因此有所增進
    '比較簡單的作法就是直接使用WPF的功能，若是Window Form程式的話我們可以額外將
    'PresentationCore.dll、System.Xaml、與WindowsBase.dll加入參考。
    ' 然後 Imports System.Windows.Media.Imaging
    Private Shared Function FastGetImageSize(ByVal filename As String) As Size
        Dim D0 As Long = Now.Ticks
        Dim D1 As Long
        Dim D2 As Long
        Dim T1 As Double
        Dim T2 As Double
        Try
            Dim decoder = BitmapDecoder.Create(New Uri(filename), BitmapCreateOptions.None, BitmapCacheOption.Default)
            Dim Frame = decoder.Frames.FirstOrDefault()
            Dim Rtn As Size = New Size(Frame.PixelWidth, Frame.PixelHeight)
            D1 = Now.Ticks
            T1 = 1000 * (D1 - D0) / 10 ^ 7
            Return Rtn
        Catch ex As Exception
            D2 = Now.Ticks
            T2 = 1000 * (D2 - D0) / 10 ^ 7
            Return New Size(0, 0)
            Application.DoEvents()
        End Try

    End Function

#Region "方法 : 從既有影像中取圖之函數"
    ' 影像複製同時去除索引 (新舊像圖無關連性)
    Public Shared Function ImageCopy_IndexFree(ByVal bmp As Bitmap) As Bitmap
        Dim newbmp As New Bitmap(bmp.Width, bmp.Height)
        Dim g As Graphics = Graphics.FromImage(newbmp)
        g.DrawImage(bmp, 0, 0, bmp.Width, bmp.Height)
        Return newbmp
    End Function
    ' 影像縮圖(縮到指定大小) 同時去除引 (新舊像圖無關連性)
    Public Shared Function ImageShrinking(ByVal bmp As Bitmap, ByVal Width As Integer, ByVal Height As Integer) As Bitmap
        Dim newbmp As New Bitmap(Width, Height)
        Dim g As Graphics = Graphics.FromImage(newbmp)
        g.DrawImage(bmp, 0, 0, Width, Height)
        Return newbmp
    End Function

    ' 取得部分影像 同時去除引 (新舊像圖無關連性)
    Public Function GetImageParts(ByVal bmp As Bitmap, ByVal rec As Rectangle) As Bitmap
        Dim newbmp As New Bitmap(rec.Width, rec.Height)
        Dim recnew As New Rectangle(0, 0, newbmp.Width, newbmp.Height)  ' 代表印到新圖的區塊
        Dim g As Graphics = Graphics.FromImage(newbmp)
        'g.DrawImage(bmp, rec0, rec.X, rec.Y, rec.Width, rec.Height, GraphicsUnit.Pixel)
        g.DrawImage(bmp, recnew, rec, GraphicsUnit.Pixel)
        Return newbmp
    End Function

#End Region

End Class
