﻿Imports ETCDLL02.Class_FileClass

Public Class UC_FileList

    Private _ListDirectory As String = "C:\Temp\"
    Private _CurrentFileName As String = ""
    Private LargSize As Integer = 100  ' 縮圖大尺寸
    Private SmallSize As Integer = 24 ' 縮圖小尺寸
    Private _SubNames As List(Of String)   ' Ex * ; xml ; bmp ; jpg ; txt ...
    Private Refreshed As Boolean = False
    Private FileList As List(Of cls_FileData)
    Private _EnvInitialized As Boolean = False
    Public Event ListViewSelectChange(ByVal Path As String, ByVal Name As String, ByVal TotalName As String)

#Region "建構函數"
    Public Sub New()

        ' 此為設計工具所需的呼叫。
        InitializeComponent()

        ' 在 InitializeComponent() 呼叫之後加入任何初始設定。
        _SubNames = New List(Of String)
        _SubNames.Add("*.*")
    End Sub
    Public Sub New(ByVal FileSubName As String)

        ' 此為設計工具所需的呼叫。
        InitializeComponent()

        ' 在 InitializeComponent() 呼叫之後加入任何初始設定。
        UpdateSubName(FileSubName)
    End Sub
    Public Sub New(ByVal FileSubName() As String)

        ' 此為設計工具所需的呼叫。
        InitializeComponent()

        ' 在 InitializeComponent() 呼叫之後加入任何初始設定。
        UpdateSubNames(FileSubName)
    End Sub

    Public Sub UpdateSubName(ByVal SubName As String)
        Dim tmpStr As String = GetSubName(SubName)
        _SubNames = New List(Of String)
        _SubNames.Add(tmpStr)
    End Sub
    Public Sub UpdateSubNames(ByVal SubNames() As String)
        _SubNames = New List(Of String)
        For i = 0 To SubNames.Count - 1
            Dim tmpxtr As String = SubNames(i).Trim
            _SubNames.Add(GetSubName(tmpxtr))
        Next
    End Sub
    Private Function GetSubName(Optional ByVal SStr As String = "") As String
        Dim SubString As String = ""
        If SStr = "" Then Return "*.*"
        Dim LastIndex As Integer = SStr.LastIndexOf(".")
        If LastIndex < 0 Then  ' . 不存在
            SubString = SStr.Trim.ToLower
        Else
            SubString = SStr.Substring(LastIndex + 1).Trim.ToLower
        End If
        Return "*." & SubString
    End Function

    Private Sub UC_FileList_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        _EnvInitialized = False
        InitialComboBox()
        txt_Path.Text = My.Settings.DefaultFolder
        _EnvInitialized = True
    End Sub

#End Region

#Region "屬性"

    Public Function ObjectIsNothing(ByVal Obj As Object) As Boolean
        Dim rtn As Boolean = False
        Try
            If IsNothing(Obj) Then Return True
            If Obj = Nothing Then Return True
            If Obj Is Nothing Then Return True
            Return False
        Catch ex As Exception
            Return True
        End Try
    End Function
    Public ReadOnly Property SubNames As String()
        Get
            If ObjectIsNothing(_SubNames) Then Return Nothing
            Return _SubNames.ToArray
        End Get
    End Property
    Public Property CurrentFileName As String
        Get
            Return _CurrentFileName
        End Get
        Set(ByVal value As String)
            _CurrentFileName = value
            txt_FileName.Text = value
        End Set
    End Property
 
    Public Property ListDirectory() As String
        Get
            Return _ListDirectory
        End Get
        Set(ByVal value As String)
            If _ListDirectory <> value Then
                _ListDirectory = value
                SetDftFolder(value, False)
            End If
        End Set
    End Property

#End Region

    Private Sub InitialComboBox()
        Dim Sname As String() = [Enum].GetNames(GetType(View))
        cmb_ListType.Items.Clear()
        For i = 0 To Sname.Count - 1
            cmb_ListType.Items.Add(Sname(i))
        Next
        Dim Index As Integer = My.Settings.ComboIndex
        If Index < 0 Or Index > cmb_ListType.Items.Count - 1 Then
            Index = 0
        End If
        cmb_ListType.SelectedIndex = Index
    End Sub

    Public Sub ChangeViewType(ByVal Type As View)
        If Refreshed Then ListView1.View = Type
    End Sub

    '更新檔案與大小 ICON
    Public Sub RefreshListView(ByVal Folder As String, Optional ByVal Type As View = View.Tile)
        Dim LargeImageList As New ImageList
        Dim SmallImageList As New ImageList
        SmallImageList.ImageSize = New Size(SmallSize, SmallSize)
        LargeImageList.ImageSize = New Size(LargSize, LargSize)
        Try
            Refreshed = False
            ProgressBar1.Value = 0
            ' Set the view to show details.
            ListView1.View = View.Details
            ' Allow the user to edit item text.
            ListView1.LabelEdit = True
            ' Allow the user to rearrange columns.
            ListView1.AllowColumnReorder = True
            ' Display check boxes.
            ListView1.CheckBoxes = False
            ' Select the item and subitems when selection is made.
            ListView1.FullRowSelect = True
            ' Display grid lines.
            ListView1.GridLines = True
            ' Sort the items in the list in ascending order.
            ListView1.Sorting = SortOrder.Ascending
            ListView1.Items.Clear()
            ListView1.Columns.Clear()
            ListView1.Columns.Add("Name", 200, HorizontalAlignment.Left)
            ListView1.Columns.Add("Length", 70, HorizontalAlignment.Left)
            ListView1.Columns.Add("CreatTime", 70, HorizontalAlignment.Left)
            ListView1.Columns.Add("LaseWriteTime", 70, HorizontalAlignment.Left)
            ListView1.Columns.Add("Size", 80, HorizontalAlignment.Left)
            Dim ListViewItems As New List(Of ListViewItem)
            ' 列出檔案名稱
            Dim SubName() As String = _SubNames.ToArray ' {"*.bmp", "*.jpg"}
            FileList = GetFileList(Folder, SubName)
            If FileList.Count = 0 Then
                Exit Sub
            End If
            ' 建立ImgList
            For i = 0 To FileList.Count - 1
                Dim rate As Double
                If FileList.Count > 1 Then
                    rate = CInt(100 * i / (FileList.Count - 1))
                Else
                    rate = 100
                End If
                If rate < 0 Then rate = 0
                Dim img As Bitmap = GetFileIconImage(FileList(i).TotalName)
                LargeImageList.Images.Add(img)
                SmallImageList.Images.Add(img)
                Application.DoEvents()
                ProgressBar1.Value = rate
                lbl_percentage.Text = rate & " % "
            Next
            StatusStrip1.Text = FileList.Count & " files"
            ' 建立 ListViewItems
            For i = 0 To FileList.Count - 1
                With FileList(i)
                    Dim Newitem As New ListViewItem(.Name, i)
                    Newitem.SubItems.Add(.FileLength)
                    Newitem.SubItems.Add(.CreateTime)
                    Newitem.SubItems.Add(.LastWriteTime)
                    Newitem.SubItems.Add(.sizeString)
                    ListViewItems.Add(Newitem)
                End With
            Next
            ' 顯示Items
            ListView1.Items.AddRange(ListViewItems.ToArray)
            ListView1.LargeImageList = LargeImageList
            ListView1.SmallImageList = SmallImageList
            ListView1.View = Type
            Refreshed = True
        Catch ex As Exception
            MsgBox("FileList Error : " & ex.Message)
        End Try

    End Sub

    ' 從檔名取得縮圖 : 如果是圖檔, 則傳回圖檔縮圖, 否則就傳回預設圖檔
    Private Function GetFileIconImage(ByVal FileName As String) As Bitmap
        Dim Rtn As Bitmap = ImgSource_L.Images(0)
        Dim Index As Integer = FileName.LastIndexOf(".")
        If Index < 0 Then Return Rtn
        Dim SubName As String = FileName.Substring(Index + 1).ToLower
        Try
            Select Case SubName
                Case "bmp", "jpg"
                    Using SourceImage As Image = New Bitmap(FileName)
                        Dim SizeH As Integer = LargSize
                        Dim SizeW As Integer = SizeH * SourceImage.Width / SourceImage.Height
                        If SizeW > LargSize Then
                            SizeW = LargSize
                            SizeH = SizeW * SourceImage.Height / SourceImage.Width
                        End If
                        Rtn = ImageShrinking(SourceImage, SizeW, SizeH)
                    End Using
                    Return Rtn
                Case Else
                    Return Rtn
            End Select
        Catch ex As Exception
            Return Rtn
        End Try
    End Function

    Private Function GetFileList(ByVal Folder As String, ByVal SubName() As String) As List(Of cls_FileData)
        Dim rtn As New List(Of cls_FileData)
        If My.Computer.FileSystem.DirectoryExists(Folder) = False Then
            MsgBox(Folder & " doesn't exist, please change folder to continue")
            Return rtn
        End If
        '_ListDirectory = Folder
        Dim ListFiles() As String = My.Computer.FileSystem.GetFiles(Folder, FileIO.SearchOption.SearchTopLevelOnly, SubName).ToArray
        If ListFiles.Count = 0 Then
            Return rtn
        End If
        For i = 0 To ListFiles.Count - 1
            'Dim newfile As New cls_FileData(ListFiles(i))
            rtn.Add(New cls_FileData(ListFiles(i)))
        Next
        Return rtn
    End Function

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        Static LastIndex As Integer = -1
        If ListView1.SelectedItems.Count > 0 Then
            Dim Name As String = ListView1.SelectedItems(0).Text
            Dim Index As Integer = 0
            For i = 0 To FileList.Count - 1
                With FileList(i)
                    If Name = .Name Then
                        Index = i
                        Exit For
                    End If
                End With
            Next
            For Each itm In ListView1.Items
                If itm.BackColor <> Color.Transparent Then itm.BackColor = Color.Transparent
            Next
            ListView1.SelectedItems(0).BackColor = Color.Lime
            If Index >= 0 Then
                With FileList(Index)
                    txt_FileName.Text = .Name
                    _CurrentFileName = .Name
                    RaiseEvent ListViewSelectChange(.Folder, .Name, .TotalName)
                End With
            End If
        End If
    End Sub

    Private Sub btn_Path_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Path.Click
        Dim Folder As String = SelectBrowSer(txt_Path.Text)
        If Folder = "" Then Exit Sub
        SetDftFolder(Folder, True)
        RefreshFileList()
    End Sub

    ' 選擇資料夾
    Private Function SelectBrowSer(Optional ByVal Dft_BrowSer As String = "") As String
        Dim rtn As String = ""
        Dim FolderBrowser As New FolderBrowserDialog
        If Dft_BrowSer.Trim <> "" Then
            FolderBrowser.SelectedPath = Dft_BrowSer
        End If
        If FolderBrowser.ShowDialog = DialogResult.Cancel Then
            Return rtn
        End If
        rtn = FolderBrowser.SelectedPath  ' & "\"
        Return rtn
    End Function

    ' 將DftFolder 寫到  _DefaultFolder -->  TxtBox_PixelSize.Text -->   My.Settings.DftFolder 
    Public Sub SetDftFolder(ByVal value As String, Optional ByVal SaveToSettings As Boolean = True)
        _ListDirectory = value
        txt_Path.Text = value
        If SaveToSettings Then
            My.Settings.DefaultFolder = value
            My.Settings.Save()
        End If
    End Sub


    ' Refresh File List
    Private Sub btn_Refresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Refresh.Click
        RefreshFileList()
    End Sub

    Private Sub cmb_ListType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_ListType.SelectedIndexChanged
        ChangeViewType(cmb_ListType.SelectedIndex)
        If _EnvInitialized Then
            My.Settings.ComboIndex = cmb_ListType.SelectedIndex
            My.Settings.Save()
        End If
    End Sub

#Region "公開方法"

    ' Refresh File List
    Public Sub RefreshFileList()
        If My.Computer.FileSystem.DirectoryExists(txt_Path.Text) Then
            RefreshListView(txt_Path.Text, cmb_ListType.SelectedIndex)
        End If
    End Sub


#End Region

End Class
