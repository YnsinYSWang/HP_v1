﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;

namespace AForgUSBCamCTL
{
    public class GigeCam : CameraInterface
    {
        #region ------------------私有欄位------------------------

        private int _CamNo = 0;
        private bool _bCreateCamStatus = false;
        private bool _bReadyGrabe = false;
        private bool _bStartGrab = false;
        private bool _LiveStatus = false;
        private bool _IsFindCam = false;        
        const int cnNumberOfSeqBuffers = 1;
        string camFilePath;

        #endregion

        public uEye.Camera camera = new uEye.Camera();
        public event EventErrorMessage eventError;
        public event EventGrabeFram eventGrabeImage;
        public GigeCam()
        {
            camFilePath = System.Environment.CurrentDirectory + "//camerafile//";
            if (!System.IO.Directory.Exists(camFilePath))
                System.IO.Directory.CreateDirectory(camFilePath);
        }

        #region ------------------屬性------------------------
        public string CamPID
        {
            get
            {
                return _CamNo.ToString();
            }
        }


        public bool CamStatus
        {
            get
            {
                return _bReadyGrabe;
            }
        }
        public bool GrabStatus
        {
            get
            {         
                return _bStartGrab;
            }
        }

        public bool LiveStatus
        {
            get
            {
                return _LiveStatus;
            }
        }

        public bool IsFindCam
        {
            get
            {
                return _IsFindCam;
            }
        }

        public bool IsGrabFirstImage
        {
            get
            {
                return _bGrabFirstImage;
            }
        }
        #endregion

        private bool _bGrabFirstImage = false;

        private void OnEventGrabe(int iCamNo, Bitmap bmpSrc)
        {
            if (eventGrabeImage != null)
            {
                eventGrabeImage.Invoke(iCamNo, bmpSrc);
            }
        }

        private void OnErrorEvent(int iCamNo, string strMsg)
        {
            if (eventError != null)
            {
                eventError.Invoke(iCamNo, strMsg);
            }
        }

        public bool initCam(int CamNo, string PID, Size ImgSize , bool bSameNo = false, bool bConfigExp = false)
        {
            _CamNo = CamNo;
            _bCreateCamStatus = false;
            _bReadyGrabe = false;
            bool state = false;
            uEye.Defines.Status statusRet = 0;
            statusRet = initCamera(camera, CamNo + 1);
            if (statusRet != uEye.Defines.Status.SUCCESS)
            {
                state = false;
                _IsFindCam = false;
            }
            else
            {
                _bCreateCamStatus = true;
                state = true;
                _IsFindCam = true;
            }

            return state;
        }

        public void Start()
        {
            if (_bCreateCamStatus == false)
            {
                return;
            }
            try
            {
                camera.Acquisition.Capture();
                System.Threading.SpinWait.SpinUntil(() => false, 50);
                _bReadyGrabe = true;
            }
            catch (Exception ex)
            {
                _bReadyGrabe = false;
                int camID;
                camera.Device.GetCameraID(out camID);
                OnErrorEvent(camID, ex.Message);
            }
        }
        public void Stop()
        {
            _bReadyGrabe = false;
            try
            {
                camera.Acquisition.Stop();
                System.Threading.SpinWait.SpinUntil(() => false, 50);
            }
            catch (Exception ex)
            {
                OnErrorEvent(_CamNo, ex.Message);
            }
        }
        public void StartGrabe()
        {
            bool started;
            camera.Acquisition.HasStarted(out started);
            if (started != true)
            {
                camera.Acquisition.Capture();
            }
            _bStartGrab = true;
            _LiveStatus = false;
        }
        public void StopGrabe()
        {
            _bStartGrab = false;
        }

        private uEye.Defines.Status initCamera(uEye.Camera m_Camera, int id)
        {
            uEye.Defines.Status statusRet = 0;

            // Open Camera
            statusRet = m_Camera.Init(id);
            if (statusRet != uEye.Defines.Status.Success)
            {
                return statusRet;
            }
            string camfile = camFilePath + "Cam" + id + ".ini";
            if (System.IO.File.Exists(camfile))
                statusRet = m_Camera.Parameter.Load(camfile);
            else
            {
                statusRet = m_Camera.Parameter.Load();
                statusRet = m_Camera.Parameter.Save(camfile);
            }

            if (statusRet != uEye.Defines.Status.Success)
            {
                return statusRet;
            }

            // Allocate Memory
            statusRet = AllocImageMems(m_Camera);
            if (statusRet != uEye.Defines.Status.Success)
            {
                return statusRet;
            }

            statusRet = InitSequence(m_Camera);
            if (statusRet != uEye.Defines.Status.Success)
            {
                return statusRet;
            }

            // Start Live Video
            statusRet = m_Camera.Acquisition.Freeze();
            if (statusRet != uEye.Defines.Status.Success)
            {
                return statusRet;
            }

            // Connect Event
            m_Camera.EventFrame += onFrameEvent;
            m_Camera.EventDeviceRemove += onCameraLost;
            m_Camera.EventDeviceReconnect += onCameraReconnet;
            return statusRet;
        }

        private uEye.Defines.Status AllocImageMems(uEye.Camera m_Camera)
        {
            uEye.Defines.Status statusRet = uEye.Defines.Status.SUCCESS;

            for (int i = 0; i < cnNumberOfSeqBuffers; i++)
            {
                statusRet = m_Camera.Memory.Allocate();

                if (statusRet != uEye.Defines.Status.SUCCESS)
                {
                    FreeImageMems(m_Camera);
                }
            }

            return statusRet;
        }

        private uEye.Defines.Status FreeImageMems(uEye.Camera m_Camera)
        {
            int[] idList;
            uEye.Defines.Status statusRet = m_Camera.Memory.GetList(out idList);

            if (uEye.Defines.Status.SUCCESS == statusRet)
            {
                foreach (int nMemID in idList)
                {
                    do
                    {
                        statusRet = m_Camera.Memory.Free(nMemID);

                        if (uEye.Defines.Status.SEQ_BUFFER_IS_LOCKED == statusRet)
                        {
                            Thread.Sleep(1);
                            continue;
                        }

                        break;
                    }
                    while (true);
                }
            }

            return statusRet;
        }

        private uEye.Defines.Status InitSequence(uEye.Camera m_Camera)
        {
            int[] idList;
            uEye.Defines.Status statusRet = m_Camera.Memory.GetList(out idList);

            if (uEye.Defines.Status.SUCCESS == statusRet)
            {
                statusRet = m_Camera.Memory.Sequence.Add(idList);

                if (uEye.Defines.Status.SUCCESS != statusRet)
                {
                    ClearSequence(m_Camera);
                }
            }

            return statusRet;
        }

        private uEye.Defines.Status ClearSequence(uEye.Camera m_Camera)
        {
            return m_Camera.Memory.Sequence.Clear();
        }

        bool iGrabFlag = false;
        private void onFrameEvent(object sender, EventArgs e)
        {
            _bGrabFirstImage = true;
            _LiveStatus = true;
            if (_bStartGrab == false) { return; }
            if (iGrabFlag == true) { return; }

            uEye.Camera camera = sender as uEye.Camera;
            iGrabFlag = true;
            try
            {
                if (camera.IsOpened)
                {
                    Int32 s32MemID;
                    uEye.Defines.Status statusRet = camera.Memory.GetLast(out s32MemID);

                    if ((uEye.Defines.Status.SUCCESS == statusRet) && (0 < s32MemID))
                    {
                        if (uEye.Defines.Status.SUCCESS == camera.Memory.Lock(s32MemID))
                        {

                            Bitmap bmp;
                            camera.Memory.CopyToBitmap(s32MemID, out bmp);
                            OnEventGrabe(_CamNo, bmp);
                            bmp.Dispose();
                            camera.Memory.Unlock(s32MemID);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _LiveStatus = false;
                int camID;
                camera.Device.GetCameraID(out camID);
                int CamIndex = camID - 1;
                OnErrorEvent(_CamNo, ex.Message);
            }
            finally
            {
                iGrabFlag = false;
            }

        }

        private void onCameraLost(object sender, EventArgs e)
        {
            uEye.Camera Camera = sender as uEye.Camera;
            int camID;
            Camera.Device.GetCameraID(out camID);
            OnErrorEvent(_CamNo, "Camera ID：" + camID +" Loss");
        }
        private void onCameraReconnet(object sender, EventArgs e)
        {
            uEye.Camera Camera = sender as uEye.Camera;
            int camID;
            Camera.Device.GetCameraID(out camID);
            OnErrorEvent(_CamNo, "Camera ID：" + camID + " Reconnect");
        }
    }

}
