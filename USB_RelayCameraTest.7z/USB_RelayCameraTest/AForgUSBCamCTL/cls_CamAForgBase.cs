﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AForge.Video.DirectShow;
using AForge.Video;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace AForgUSBCamCTL
{
    public class cls_CamAForgBase : CameraInterface
    {
        #region ------------------定義事件------------------------
        //public event Action<int, Bitmap> GrabeEvent;
        //public event Action<int, string> ErrorMessage;

        public event EventErrorMessage eventError;
        public event EventGrabeFram eventGrabeImage;

        #endregion


        #region ------------------私有欄位------------------------

        private VideoCaptureDevice SelectCam = null;
        private string _PID;
        private int _CamNo;
        private Size _ImgSize;
        private bool _bCreateCamStatus = false;
        private bool _bReadyGrabe = false;
        private bool _bStartGrab = false;
        private bool _IsFindCam = false;
        private bool _IsGrabFirstImage = false;
        private bool _LiveStatus = false;
        private List<int> _ltExistCamNo = new List<int>();
        #endregion


        #region ------------------屬性------------------------
        public string CamPID
        {
            get
            {
                return _PID;
            }
        }


        public bool CamStatus
        {
            get
            {
                return _bReadyGrabe;
            }
        }
        public bool GrabStatus
        {
            get
            {
                return _bStartGrab;
            }
        }

        public bool LiveStatus
        {
            get
            {
                return _LiveStatus;
            }
        }

        public bool IsFindCam
        {
            get
            {
                return _IsFindCam;
            }
        }

        public bool IsGrabFirstImage
        {
            get
            {
                return _IsGrabFirstImage;
            }
        }
        #endregion

        public cls_CamAForgBase()
        {
        }

        private void OnEventGrabe(int iCamNo, Bitmap bmpSrc)
        {
            if (eventGrabeImage != null)
            {
                eventGrabeImage.Invoke(iCamNo, bmpSrc);
            }
        }

        private void OnErrorEvent(int iCamNo, string strMsg)
        {
            if (eventError != null)
            {
                eventError.Invoke(iCamNo, strMsg);
            }
        }

        //private AForge.Controls.VideoSourcePlayer m_VideosSourcePlayer1 = null;
        public bool initCam(int CamNo, string PID, Size ImgSize, bool bSameNo = false, bool bConfigExp = false)
        {
            _bCreateCamStatus = false;
            _PID = PID;
            _CamNo = CamNo;
            _ImgSize = ImgSize;
            try
            {
                if (SelectCam != null)
                {
                    if (SelectCam.IsRunning == true)
                    {
                        //Console.WriteLine(string.Format("[{0}]Cam Stop.", _CamNo));
                        SelectCam.Stop();
                        System.Threading.Thread.Sleep(500);
                        SelectCam = null;
                        //System.Threading.SpinWait.SpinUntil(() => false, 500);
                    }
					//               try
					//               {

					//	m_VideosSourcePlayer1.Stop();
					//	m_VideosSourcePlayer1.NewFrame -= new AForge.Controls.VideoSourcePlayer.NewFrameHandler(Grabe_ImaFram);
					//	m_VideosSourcePlayer1 = null;
					//	m_VideosSourcePlayer1.Dispose();
					//}
					//               catch
					//               {

					//               }

					SelectCam.NewFrame -= Grabe_ImaFram;
					SelectCam = null;
				}

                FilterInfoCollection AllCamDev;

                AllCamDev = new FilterInfoCollection(FilterCategory.VideoInputDevice);
                if (AllCamDev.Count == 0) { throw new Exception("Not Find Cam."); }

                int iSelectIndex = FindPIDNumber(AllCamDev, _PID, bSameNo, _CamNo);
                if (iSelectIndex < 0) { throw new Exception("Not Find Select Cam."); }
                if (iSelectIndex > AllCamDev.Count - 1) { throw new Exception("Cam Select Index Over Count."); }

                SelectCam = new VideoCaptureDevice(AllCamDev[iSelectIndex].MonikerString);
                //m_VideosSourcePlayer1 = new AForge.Controls.VideoSourcePlayer();
                //m_VideosSourcePlayer1.VideoSource = SelectCam;
                //m_VideosSourcePlayer1.NewFrame = Grabe_ImaFram;

                Stopwatch swTimeout = new Stopwatch();
                bool rtn = false;
                swTimeout.Restart();
                while (!rtn)
                {
                    rtn = SelectCam.SetCameraProperty(CameraControlProperty.Exposure, -1, CameraControlFlags.Manual);
                    //System.Threading.SpinWait.SpinUntil(() => false, 200);
                    System.Threading.Thread.Sleep(200);
                    Console.WriteLine(string.Format("Cam[{0}] {1}", _CamNo, rtn == true ? "寫入參數成功!" : "寫入參數失敗!"));
                    if (swTimeout.ElapsedMilliseconds > 2000)
                    {
                        swTimeout.Stop();
                        Console.WriteLine(string.Format("[WARM] Set Cam Parameter Timeout."));
                        break;
                    }
                }

                rtn = false;
                CameraControlFlags NowCamExpMode = CameraControlFlags.None;
                int iNowExpValue = 0;
                swTimeout.Restart();
                while (!rtn)
                {
                    rtn = SelectCam.GetCameraProperty(CameraControlProperty.Exposure, out iNowExpValue, out NowCamExpMode);
                    //System.Threading.SpinWait.SpinUntil(() => false, 200);
                    System.Threading.Thread.Sleep(200);
                    Console.WriteLine(string.Format("Cam[{0}] {1}  Mode:{2}  Exposure:{3}", _CamNo, rtn == true ? "讀取參數成功!" : "讀取參數失敗!", NowCamExpMode, iNowExpValue));
                    if (swTimeout.ElapsedMilliseconds > 2000)
                    {
                        swTimeout.Stop();
                        Console.WriteLine(string.Format("[WARM] Get Cam Parameter Timeout."));
                        break;
                    }
                }

                rtn = false;
                swTimeout.Restart();
                while (!rtn)
                {
                    rtn = SelectCam.SetVideoProperty(VideoProcAmpProperty.Gain, 6, VideoProcAmpFlags.Manual);
                    //System.Threading.SpinWait.SpinUntil(() => false, 200);
                    System.Threading.Thread.Sleep(200);

                    Console.WriteLine(string.Format("Cam[{0}] {1}", _CamNo, rtn == true ? "寫入參數成功!" : "寫入參數失敗!"));
                    if (swTimeout.ElapsedMilliseconds > 2000)
                    {
                        swTimeout.Stop();
                        Console.WriteLine(string.Format("[WARM] Get Cam Parameter Timeout."));
                        break;
                    }
                }

                rtn = false;
                VideoProcAmpFlags NowCamGainMode = VideoProcAmpFlags.None;
                int iGainValue = 0;
                swTimeout.Restart();
                while (!rtn)
                {
                    rtn = SelectCam.GetVideoProperty(VideoProcAmpProperty.Gain, out iGainValue, out NowCamGainMode);
                    //System.Threading.SpinWait.SpinUntil(() => false, 200);
                    System.Threading.Thread.Sleep(200);
                    Console.WriteLine(string.Format("Cam[{0}] {1}  Mode:{2}  Gain:{3}", _CamNo, rtn == true ? "讀取參數成功!" : "讀取參數失敗!", NowCamGainMode, iGainValue));
                    if (swTimeout.ElapsedMilliseconds > 2000)
                    {
                        swTimeout.Stop();
                        Console.WriteLine(string.Format("[WARM] Get Cam Parameter Timeout."));
                        break;
                    }
                }

                foreach (VideoCapabilities tmpCapabilitie in SelectCam.VideoCapabilities)
                {
                    if (tmpCapabilitie.FrameSize == _ImgSize)
                    {
                        SelectCam.VideoResolution = tmpCapabilitie;
                        //SelectCam.DesiredFrameRate = tmpCapabilitie.FrameRate;
                        //SelectCam.DesiredFrameSize = tmpCapabilitie.FrameSize;
                        break;
                    }
                }

				//Console.WriteLine(string.Format("[{0}]Cam Status [{1}].", CamNo, SelectCam.IsRunning));
				SelectCam.NewFrame += Grabe_ImaFram;

				//m_VideosSourcePlayer1.NewFrame +=new AForge.Controls.VideoSourcePlayer.NewFrameHandler( Grabe_ImaFram);

				_bCreateCamStatus = true;
                _bReadyGrabe = false;
                _IsFindCam = true;
                return true;
            }
            catch (Exception ex)
            {
                _IsFindCam = false;
                OnErrorEvent(_CamNo, ex.Message);
                return false;
            }
        }

        public void Start()
        {
            if (_bCreateCamStatus == false)
            {
                return;
            }
            try
            {
				SelectCam.Start();
				//m_VideosSourcePlayer1.Start();
				System.Threading.SpinWait.SpinUntil(() => false, 200);
                _bReadyGrabe = true;
            }
            catch (Exception ex)
            {
                _bReadyGrabe = false;
                OnErrorEvent(_CamNo, ex.Message);
            }
        }

        public void Stop()
        {
            _bReadyGrabe = false;
            try
            {
                SelectCam.Stop();
                System.Threading.SpinWait.SpinUntil(() => false, 200);
                _IsGrabFirstImage = false;
            }
            catch (Exception ex)
            {
                OnErrorEvent(_CamNo, ex.Message);
            }
        }

        public void StartGrabe()
        {
            _bStartGrab = true;
            _LiveStatus = false;
        }

        public void StopGrabe()
        {
            _bStartGrab = false;
        }

        bool iGrabFlag = false;
		int iFailCnt = 0;
		private void Grabe_ImaFram(object sender, NewFrameEventArgs eventArgs)
		{
			_IsGrabFirstImage = true;
			_LiveStatus = true;
			//Console.WriteLine(string.Format("{0} [{1}]Cam Status[{2}].",DateTime .Now.ToString("HH:mm:ss:fff"), _CamNo, _LiveStatus));
			if (_bStartGrab == false) { return; }
			if (iGrabFlag == true) { return; }
			iGrabFlag = true;
			try
			{
				Bitmap bmp = (Bitmap)eventArgs.Frame;
				OnEventGrabe(_CamNo, bmp);
				bmp.Dispose();
			}
			catch (Exception ex)
			{
				_LiveStatus = false;
				OnErrorEvent(_CamNo, ex.Message);
			}
			finally
			{
				iGrabFlag = false;
			}
		}
		//private void Grabe_ImaFram(object sender, ref System.Drawing.Bitmap image)
  //      {
  //          _IsGrabFirstImage = true;
  //          _LiveStatus = true;
  //          //Console.WriteLine(string.Format("{0} [{1}]Cam Status[{2}].",DateTime .Now.ToString("HH:mm:ss:fff"), _CamNo, _LiveStatus));
  //          if (_bStartGrab == false) { return; }
  //          if (iGrabFlag == true) { return; }
  //          iGrabFlag = true;
  //          try
  //          {
  //              Bitmap bmp = image;
  //              OnEventGrabe(_CamNo, bmp);
  //              bmp.Dispose();
  //          }
  //          catch (Exception ex)
  //          {
  //              _LiveStatus = false;
  //              OnErrorEvent(_CamNo, ex.Message);
  //          }
  //          finally
  //          {
  //              iGrabFlag = false;
  //          }
  //      }

        private int FindPIDNumber(FilterInfoCollection AllDev, string inPid, bool bSameNo = false, int iNo = 0)
        {
            string strPID = inPid.ToUpper();
            int iOutIndex = -1;
            int iTotalDevCount = AllDev.Count;
            if (iTotalDevCount < 1) { return iOutIndex; }
            if (!bSameNo)
            {
                for (int iIndex = 0; iIndex < iTotalDevCount; iIndex++)
                {
                    string tmpTransBig = AllDev[iIndex].MonikerString.ToUpper();
                    int iFind = tmpTransBig.IndexOf(strPID);
                    if (iFind > -1)
                    {
                        iOutIndex = iIndex;
                        break;
                    }
                }
            }
            else
            {
                if (iNo == 0)
                {
                    for (int iIndex = 0; iIndex < iTotalDevCount; iIndex++)
                    {
                        string tmpTransBig = AllDev[iIndex].MonikerString.ToUpper();
                        int iFind = tmpTransBig.IndexOf(strPID);
                        if (iFind > -1)
                        {
                            iOutIndex = iIndex;
                            break;
                        }
                    }
                }
                else
                {
                    for (int iIndex = iTotalDevCount - 1; iIndex >= 0; iIndex--)
                    {
                        string tmpTransBig = AllDev[iIndex].MonikerString.ToUpper();
                        int iFind = tmpTransBig.IndexOf(strPID);
                        if (iFind > -1)
                        {
                            iOutIndex = iIndex;
                            break;
                        }
                    }
                }
            }

            return iOutIndex;
        }

        private byte[] _CamOldByte01 = new byte[9000];
        private byte[] _CamOldByte02 = new byte[9000];
        private byte[] _CamOldByte03 = new byte[9000];
        private byte[] _CamOldByte04 = new byte[9000];
        private byte[] _CamOldByte05 = new byte[9000];
        private bool CompareImageData(Bitmap img)
        {
            int iImgW = img.Width;
            int iImgH = img.Height;
            int iH3 = iImgH / 3;
            int iHS3 = iH3 / 3;
            int iW3 = iImgW / 3;
            int iWS3 = iW3 / 3;
            byte[] tmpbyte01 = new byte[9000];
            byte[] tmpbyte02 = new byte[9000];
            byte[] tmpbyte03 = new byte[9000];
            byte[] tmpbyte04 = new byte[9000];
            byte[] tmpbyte05 = new byte[9000];

            BitmapData bmpData = img.LockBits(new Rectangle(0, 0, iImgW, iImgH), ImageLockMode.ReadWrite, img.PixelFormat);
            IntPtr pStart = bmpData.Scan0;
            int iImageTotalWith = bmpData.Stride;
            byte[] tmpMbByteData = new byte[300];
            int iIndex0 = 0;
            for (int iIndex = 0; iIndex < 30; iIndex++)
            {
                int iFront = iHS3 * iImageTotalWith;
                int iBackSection = iIndex * iImageTotalWith;
                Marshal.Copy(pStart + (iFront + (iWS3 * 3) + iBackSection), tmpMbByteData, 0, 300);
                Buffer.BlockCopy(tmpMbByteData, 0, tmpbyte01, iIndex0, 300);
                Marshal.Copy(pStart + (iFront + ((iW3 + iWS3) * 3) + iBackSection), tmpMbByteData, 0, 300);
                Buffer.BlockCopy(tmpMbByteData, 0, tmpbyte02, iIndex0, 300);
                iIndex0 += 300;
            }

            iIndex0 = 0;
            for (int iIndex = 0; iIndex < 30; iIndex++)
            {
                int iFront = (iH3 + iHS3) * iImageTotalWith;
                int iBackSection = iIndex * iImageTotalWith;
                Marshal.Copy(pStart + (iFront + ((iW3 + iWS3) * 3) + iBackSection), tmpMbByteData, 0, 300);
                Buffer.BlockCopy(tmpMbByteData, 0, tmpbyte03, iIndex0, 300);
                iIndex0 += 300;
            }

            iIndex0 = 0;
            for (int iIndex = 0; iIndex < 30; iIndex++)
            {
                int iFront = ((iH3 * 2) + iHS3) * iImageTotalWith;
                int iBackSection = iIndex * iImageTotalWith;
                Marshal.Copy(pStart + (iFront + (iWS3 * 3) + iBackSection), tmpMbByteData, 0, 300);
                Buffer.BlockCopy(tmpMbByteData, 0, tmpbyte04, iIndex0, 90);
                Marshal.Copy(pStart + (iFront + ((iW3 + iWS3) * 3) + iBackSection), tmpMbByteData, 0, 300);
                Buffer.BlockCopy(tmpMbByteData, 0, tmpbyte05, iIndex0, 300);
                iIndex0 += 300;
            }

            img.UnlockBits(bmpData);
            if (CheckAllValueZero(ref tmpbyte01, ref tmpbyte02, ref tmpbyte03, ref tmpbyte04, ref tmpbyte05))
            {
                return false;
            }

            int iOldCnt = 9000;
            bool CompareRECT01 = false;
            bool CompareRECT02 = false;
            bool CompareRECT03 = false;
            bool CompareRECT04 = false;
            bool CompareRECT05 = false;
            bool bImageDifferent = false;
            for (int iFIndex = 0; iFIndex < iOldCnt; iFIndex++)
            {
                if (!(tmpbyte01[iFIndex] == _CamOldByte01[iFIndex])) { CompareRECT01 = false; }
                if (!(tmpbyte02[iFIndex] == _CamOldByte02[iFIndex])) { CompareRECT02 = false; }
                if (!(tmpbyte03[iFIndex] == _CamOldByte03[iFIndex])) { CompareRECT03 = false; }
                if (!(tmpbyte04[iFIndex] == _CamOldByte04[iFIndex])) { CompareRECT04 = false; }
                if (!(tmpbyte05[iFIndex] == _CamOldByte05[iFIndex])) { CompareRECT05 = false; }
                if (CompareRECT01 || CompareRECT02 || CompareRECT03 || CompareRECT04 || CompareRECT05)
                {
                    bImageDifferent = true;
                    break;
                }
            }

            if (bImageDifferent)
            {
                Buffer.BlockCopy(tmpbyte01, 0, _CamOldByte01, 0, 9000);
                Buffer.BlockCopy(tmpbyte02, 0, _CamOldByte02, 0, 9000);
                Buffer.BlockCopy(tmpbyte03, 0, _CamOldByte03, 0, 9000);
                Buffer.BlockCopy(tmpbyte04, 0, _CamOldByte04, 0, 9000);
                Buffer.BlockCopy(tmpbyte05, 0, _CamOldByte05, 0, 9000);
            }
            return !bImageDifferent;
        }
        private bool CheckAllValueZero(ref byte[] Array01, ref byte[] Array02, ref byte[] Array03, ref byte[] Array04, ref byte[] Array05)
        {
            bool[] CheckAllZ_Rtn = new bool[5];
            CheckAllZ_Rtn[0] = Array.TrueForAll(Array01, elementV => elementV == 0 ? true : false);
            CheckAllZ_Rtn[1] = Array.TrueForAll(Array02, elementV => elementV == 0 ? true : false);
            CheckAllZ_Rtn[2] = Array.TrueForAll(Array03, elementV => elementV == 0 ? true : false);
            CheckAllZ_Rtn[3] = Array.TrueForAll(Array04, elementV => elementV == 0 ? true : false);
            CheckAllZ_Rtn[4] = Array.TrueForAll(Array05, elementV => elementV == 0 ? true : false);
            return Array.TrueForAll(CheckAllZ_Rtn, elementV => elementV);
        }

    }
}
