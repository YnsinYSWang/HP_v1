﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace AForgUSBCamCTL
{
    public delegate void EventErrorMessage(int CamNo, string Msg);
    public delegate void EventGrabeFram(int CamNo, Bitmap SrcImage);
    public interface CameraInterface
    {

        event EventErrorMessage eventError;

        event EventGrabeFram eventGrabeImage;

        bool initCam(int CamNo, string PID, Size ImgSize, bool bSameNo = false, bool bConfigExp = false);

        void Start();
        void Stop();
        void StartGrabe();
        void StopGrabe();
        #region ------------------屬性------------------------
        string CamPID
        {
            get;

        }


        bool CamStatus
        {
            get;
        }
        bool GrabStatus
        {
            get;
        }

        bool LiveStatus
        {
            get;

        }
        bool IsFindCam
        {
            get;

        }
        bool IsGrabFirstImage
        {
            get;
        }
        #endregion
    }
}
